﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MVINSP_LINESCAN
{
    static class Program
    {
        /// <summary>
        /// 해당 응용 프로그램의 주 진입점입니다.
        /// </summary>
        [STAThread]
        static void Main()
        {
            try
            {
                //System.Runtime.InteropServices.SEHException sEHException = System.Runtime.InteropServices.SEHException; '외부 구성 요소에서 예외를 Throw했습니다.';

                //System.Runtime.InteropServices.SEHException: '외부 구성 요소에서 예외를 Throw했습니다.';
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new frmInspMain());
            }
            catch
            {   
                //throw;
            }
        }
    }
}
