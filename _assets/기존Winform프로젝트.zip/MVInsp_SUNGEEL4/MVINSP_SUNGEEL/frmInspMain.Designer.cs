﻿namespace MVINSP_LINESCAN
{
    partial class frmInspMain
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInspMain));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel9 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButtonOneShot = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonStop = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel5 = new System.Windows.Forms.ToolStripLabel();
            this.tsbZoomOut = new System.Windows.Forms.ToolStripButton();
            this.tstxtZoomRatio = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.tsbZoomIn = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel10 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButtonAutoInspStart2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonOneShot2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonStop2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel7 = new System.Windows.Forms.ToolStripLabel();
            this.tsbZoomOut2 = new System.Windows.Forms.ToolStripButton();
            this.tstxtZoomRatio2 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripLabel8 = new System.Windows.Forms.ToolStripLabel();
            this.tsbZoomIn2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel6 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel11 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButtonAutoInspStart = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel12 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButtonAutoInspStart3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonOneShot3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonStop3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel13 = new System.Windows.Forms.ToolStripLabel();
            this.tsbZoomOut3 = new System.Windows.Forms.ToolStripButton();
            this.tstxtZoomRatio3 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripLabel14 = new System.Windows.Forms.ToolStripLabel();
            this.tsbZoomIn3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel15 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel16 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel17 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButtonAutoInspStart4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonOneShot4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonStop4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel18 = new System.Windows.Forms.ToolStripLabel();
            this.tsbZoomOut4 = new System.Windows.Forms.ToolStripButton();
            this.tstxtZoomRatio4 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripLabel19 = new System.Windows.Forms.ToolStripLabel();
            this.tsbZoomIn4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel20 = new System.Windows.Forms.ToolStripLabel();
            this.tabControlMain = new System.Windows.Forms.TabControl();
            this.tabInspection = new System.Windows.Forms.TabPage();
            this.txtMsg2 = new System.Windows.Forms.TextBox();
            this.txtZOffset = new System.Windows.Forms.TextBox();
            this.txtYOffset = new System.Windows.Forms.TextBox();
            this.txtXOffset = new System.Windows.Forms.TextBox();
            this.btnZOffset = new System.Windows.Forms.Button();
            this.txtMsg1 = new System.Windows.Forms.TextBox();
            this.btnYOffset = new System.Windows.Forms.Button();
            this.btnApply2 = new System.Windows.Forms.Button();
            this.btnXOffset = new System.Windows.Forms.Button();
            this.btnApply1 = new System.Windows.Forms.Button();
            this.btnSCARA4Connect = new System.Windows.Forms.Button();
            this.btnSCARA2Connect = new System.Windows.Forms.Button();
            this.btnSCARA3Connect = new System.Windows.Forms.Button();
            this.btnRN4 = new System.Windows.Forms.Button();
            this.btnRN2 = new System.Windows.Forms.Button();
            this.btnRN3 = new System.Windows.Forms.Button();
            this.btnRN1 = new System.Windows.Forms.Button();
            this.btnSO4 = new System.Windows.Forms.Button();
            this.btnSO2 = new System.Windows.Forms.Button();
            this.btnSO3 = new System.Windows.Forms.Button();
            this.btnSO1 = new System.Windows.Forms.Button();
            this.btnRSERR4 = new System.Windows.Forms.Button();
            this.btnRSERR2 = new System.Windows.Forms.Button();
            this.btnRSERR3 = new System.Windows.Forms.Button();
            this.btnRSERR1 = new System.Windows.Forms.Button();
            this.btnSCARA1Connect = new System.Windows.Forms.Button();
            this.lstResults = new System.Windows.Forms.ListBox();
            this.btnClearFrameCount = new System.Windows.Forms.Button();
            this.lblMatchingResult4 = new System.Windows.Forms.Label();
            this.lblMatchingResult2 = new System.Windows.Forms.Label();
            this.lblMatchingResult3 = new System.Windows.Forms.Label();
            this.lblMatchingResult = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblTotalTime4 = new System.Windows.Forms.Label();
            this.lblTotalTime2 = new System.Windows.Forms.Label();
            this.lblTotalTime3 = new System.Windows.Forms.Label();
            this.lblTotalTime = new System.Windows.Forms.Label();
            this.lblFrameCount4 = new System.Windows.Forms.Label();
            this.lblFrameCount2 = new System.Windows.Forms.Label();
            this.lblFrameCount3 = new System.Windows.Forms.Label();
            this.lblFrameCount = new System.Windows.Forms.Label();
            this.lblProcessingTime4 = new System.Windows.Forms.Label();
            this.lblProcessingTime2 = new System.Windows.Forms.Label();
            this.lblProcessingTime3 = new System.Windows.Forms.Label();
            this.lblProcessingTime = new System.Windows.Forms.Label();
            this.btnSampleInspect = new System.Windows.Forms.Button();
            this.tabCameraConfig = new System.Windows.Forms.TabPage();
            this.gridCalibration4 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridCalibration2 = new System.Windows.Forms.DataGridView();
            this.gridCalibrationNo2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridCalibrationUse2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.gridCalibrationPixelX2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridCalibrationPixelY2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridCalibrationWorldX2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridCalibrationWorldY2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridCalibration3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridCalibration = new System.Windows.Forms.DataGridView();
            this.gridCalibrationNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridCalibrationUse = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.gridCalibrationPixelX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridCalibrationPixelY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridCalibrationWorldX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridCalibrationWorldY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.imageListForDeviceList = new System.Windows.Forms.ImageList(this.components);
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsslblAbsPosition = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslblRelatedPosition = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslblAbsPosition2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.timerScroll = new System.Windows.Forms.Timer(this.components);
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label135 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label132 = new System.Windows.Forms.Label();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.toolStrip.SuspendLayout();
            this.tabControlMain.SuspendLayout();
            this.tabInspection.SuspendLayout();
            this.tabCameraConfig.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridCalibration4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridCalibration2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridCalibration3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridCalibration)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip
            // 
            this.toolStrip.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel2,
            this.toolStripLabel9,
            this.toolStripButtonOneShot,
            this.toolStripButtonStop,
            this.toolStripLabel5,
            this.tsbZoomOut,
            this.tstxtZoomRatio,
            this.toolStripLabel1,
            this.tsbZoomIn,
            this.toolStripLabel4,
            this.toolStripSeparator2,
            this.toolStripLabel10,
            this.toolStripLabel3,
            this.toolStripButtonAutoInspStart2,
            this.toolStripButtonOneShot2,
            this.toolStripButtonStop2,
            this.toolStripLabel7,
            this.tsbZoomOut2,
            this.tstxtZoomRatio2,
            this.toolStripLabel8,
            this.tsbZoomIn2,
            this.toolStripLabel6,
            this.toolStripSeparator1,
            this.toolStripLabel11,
            this.toolStripButtonAutoInspStart,
            this.toolStripLabel12,
            this.toolStripButtonAutoInspStart3,
            this.toolStripButtonOneShot3,
            this.toolStripButtonStop3,
            this.toolStripLabel13,
            this.tsbZoomOut3,
            this.tstxtZoomRatio3,
            this.toolStripLabel14,
            this.tsbZoomIn3,
            this.toolStripLabel15,
            this.toolStripSeparator3,
            this.toolStripLabel16,
            this.toolStripLabel17,
            this.toolStripButtonAutoInspStart4,
            this.toolStripButtonOneShot4,
            this.toolStripButtonStop4,
            this.toolStripLabel18,
            this.tsbZoomOut4,
            this.tstxtZoomRatio4,
            this.toolStripLabel19,
            this.tsbZoomIn4,
            this.toolStripLabel20});
            this.toolStrip.Location = new System.Drawing.Point(0, 0);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.toolStrip.Size = new System.Drawing.Size(2564, 42);
            this.toolStrip.TabIndex = 0;
            this.toolStrip.Text = "toolStrip";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(71, 36);
            this.toolStripLabel2.Text = "CAM1";
            // 
            // toolStripLabel9
            // 
            this.toolStripLabel9.Name = "toolStripLabel9";
            this.toolStripLabel9.Size = new System.Drawing.Size(55, 36);
            this.toolStripLabel9.Text = "연결";
            this.toolStripLabel9.Visible = false;
            this.toolStripLabel9.Click += new System.EventHandler(this.toolStripLabel9_Click);
            // 
            // toolStripButtonOneShot
            // 
            this.toolStripButtonOneShot.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonOneShot.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonOneShot.Image")));
            this.toolStripButtonOneShot.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonOneShot.Name = "toolStripButtonOneShot";
            this.toolStripButtonOneShot.Size = new System.Drawing.Size(40, 36);
            this.toolStripButtonOneShot.Text = "One Shot";
            this.toolStripButtonOneShot.ToolTipText = "Capture Single Inspection";
            this.toolStripButtonOneShot.Click += new System.EventHandler(this.toolStripButtonOneShot_Click);
            // 
            // toolStripButtonStop
            // 
            this.toolStripButtonStop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonStop.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonStop.Image")));
            this.toolStripButtonStop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonStop.Name = "toolStripButtonStop";
            this.toolStripButtonStop.Size = new System.Drawing.Size(40, 36);
            this.toolStripButtonStop.Text = "Stop Grab";
            this.toolStripButtonStop.ToolTipText = "Stop Inspection";
            this.toolStripButtonStop.Click += new System.EventHandler(this.toolStripButtonStop_Click);
            // 
            // toolStripLabel5
            // 
            this.toolStripLabel5.Name = "toolStripLabel5";
            this.toolStripLabel5.Size = new System.Drawing.Size(34, 36);
            this.toolStripLabel5.Text = "   ";
            // 
            // tsbZoomOut
            // 
            this.tsbZoomOut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomOut.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomOut.Image")));
            this.tsbZoomOut.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomOut.Name = "tsbZoomOut";
            this.tsbZoomOut.Size = new System.Drawing.Size(40, 36);
            this.tsbZoomOut.Text = "toolStripButton2";
            this.tsbZoomOut.Click += new System.EventHandler(this.tsbZoomOut_Click);
            // 
            // tstxtZoomRatio
            // 
            this.tstxtZoomRatio.AutoSize = false;
            this.tstxtZoomRatio.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tstxtZoomRatio.Font = new System.Drawing.Font("Malgun Gothic", 9F);
            this.tstxtZoomRatio.Name = "tstxtZoomRatio";
            this.tstxtZoomRatio.Size = new System.Drawing.Size(78, 35);
            this.tstxtZoomRatio.Text = "5.89";
            this.tstxtZoomRatio.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tstxtZoomRatio.KeyDown += new System.Windows.Forms.KeyEventHandler(this.toolStripTextBox1_KeyDown);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(31, 36);
            this.toolStripLabel1.Text = "%";
            // 
            // tsbZoomIn
            // 
            this.tsbZoomIn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomIn.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomIn.Image")));
            this.tsbZoomIn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomIn.Name = "tsbZoomIn";
            this.tsbZoomIn.Size = new System.Drawing.Size(40, 36);
            this.tsbZoomIn.Text = "toolStripButton1";
            this.tsbZoomIn.Click += new System.EventHandler(this.tsbZoomIn_Click);
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Size = new System.Drawing.Size(34, 36);
            this.toolStripLabel4.Text = "   ";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 42);
            // 
            // toolStripLabel10
            // 
            this.toolStripLabel10.Name = "toolStripLabel10";
            this.toolStripLabel10.Size = new System.Drawing.Size(55, 36);
            this.toolStripLabel10.Text = "연결";
            this.toolStripLabel10.Visible = false;
            this.toolStripLabel10.Click += new System.EventHandler(this.toolStripLabel10_Click);
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(71, 36);
            this.toolStripLabel3.Text = "CAM2";
            // 
            // toolStripButtonAutoInspStart2
            // 
            this.toolStripButtonAutoInspStart2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonAutoInspStart2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAutoInspStart2.Image")));
            this.toolStripButtonAutoInspStart2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAutoInspStart2.Name = "toolStripButtonAutoInspStart2";
            this.toolStripButtonAutoInspStart2.Size = new System.Drawing.Size(40, 36);
            this.toolStripButtonAutoInspStart2.Text = "Continuous Shot";
            this.toolStripButtonAutoInspStart2.ToolTipText = "Automatic Inspection";
            this.toolStripButtonAutoInspStart2.Click += new System.EventHandler(this.toolStripButtonAutoInspStart2_Click);
            // 
            // toolStripButtonOneShot2
            // 
            this.toolStripButtonOneShot2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonOneShot2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonOneShot2.Image")));
            this.toolStripButtonOneShot2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonOneShot2.Name = "toolStripButtonOneShot2";
            this.toolStripButtonOneShot2.Size = new System.Drawing.Size(40, 36);
            this.toolStripButtonOneShot2.Text = "One Shot";
            this.toolStripButtonOneShot2.ToolTipText = "Capture Single Inspection";
            this.toolStripButtonOneShot2.Click += new System.EventHandler(this.toolStripButtonOneShot2_Click);
            // 
            // toolStripButtonStop2
            // 
            this.toolStripButtonStop2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonStop2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonStop2.Image")));
            this.toolStripButtonStop2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonStop2.Name = "toolStripButtonStop2";
            this.toolStripButtonStop2.Size = new System.Drawing.Size(40, 36);
            this.toolStripButtonStop2.Text = "Stop Grab";
            this.toolStripButtonStop2.ToolTipText = "Stop Inspection";
            this.toolStripButtonStop2.Click += new System.EventHandler(this.toolStripButtonStop2_Click);
            // 
            // toolStripLabel7
            // 
            this.toolStripLabel7.Name = "toolStripLabel7";
            this.toolStripLabel7.Size = new System.Drawing.Size(34, 36);
            this.toolStripLabel7.Text = "   ";
            // 
            // tsbZoomOut2
            // 
            this.tsbZoomOut2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomOut2.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomOut2.Image")));
            this.tsbZoomOut2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomOut2.Name = "tsbZoomOut2";
            this.tsbZoomOut2.Size = new System.Drawing.Size(40, 36);
            this.tsbZoomOut2.Text = "toolStripButton2";
            this.tsbZoomOut2.Click += new System.EventHandler(this.tsbZoomOut2_Click);
            // 
            // tstxtZoomRatio2
            // 
            this.tstxtZoomRatio2.AutoSize = false;
            this.tstxtZoomRatio2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tstxtZoomRatio2.Font = new System.Drawing.Font("Malgun Gothic", 9F);
            this.tstxtZoomRatio2.Name = "tstxtZoomRatio2";
            this.tstxtZoomRatio2.Size = new System.Drawing.Size(78, 35);
            this.tstxtZoomRatio2.Text = "5.89";
            this.tstxtZoomRatio2.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tstxtZoomRatio2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tstxtZoomRatio2_KeyDown);
            // 
            // toolStripLabel8
            // 
            this.toolStripLabel8.Name = "toolStripLabel8";
            this.toolStripLabel8.Size = new System.Drawing.Size(31, 36);
            this.toolStripLabel8.Text = "%";
            // 
            // tsbZoomIn2
            // 
            this.tsbZoomIn2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomIn2.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomIn2.Image")));
            this.tsbZoomIn2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomIn2.Name = "tsbZoomIn2";
            this.tsbZoomIn2.Size = new System.Drawing.Size(40, 36);
            this.tsbZoomIn2.Text = "toolStripButton1";
            this.tsbZoomIn2.Click += new System.EventHandler(this.tsbZoomIn2_Click);
            // 
            // toolStripLabel6
            // 
            this.toolStripLabel6.Name = "toolStripLabel6";
            this.toolStripLabel6.Size = new System.Drawing.Size(34, 36);
            this.toolStripLabel6.Text = "   ";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 42);
            // 
            // toolStripLabel11
            // 
            this.toolStripLabel11.Name = "toolStripLabel11";
            this.toolStripLabel11.Size = new System.Drawing.Size(55, 36);
            this.toolStripLabel11.Text = "연결";
            this.toolStripLabel11.Visible = false;
            // 
            // toolStripButtonAutoInspStart
            // 
            this.toolStripButtonAutoInspStart.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonAutoInspStart.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAutoInspStart.Image")));
            this.toolStripButtonAutoInspStart.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAutoInspStart.Name = "toolStripButtonAutoInspStart";
            this.toolStripButtonAutoInspStart.Size = new System.Drawing.Size(40, 36);
            this.toolStripButtonAutoInspStart.Text = "Continuous Shot";
            this.toolStripButtonAutoInspStart.ToolTipText = "Automatic Inspection";
            this.toolStripButtonAutoInspStart.Click += new System.EventHandler(this.toolStripButtonAutoInspStart_Click);
            // 
            // toolStripLabel12
            // 
            this.toolStripLabel12.Name = "toolStripLabel12";
            this.toolStripLabel12.Size = new System.Drawing.Size(71, 36);
            this.toolStripLabel12.Text = "CAM3";
            // 
            // toolStripButtonAutoInspStart3
            // 
            this.toolStripButtonAutoInspStart3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonAutoInspStart3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAutoInspStart3.Image")));
            this.toolStripButtonAutoInspStart3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAutoInspStart3.Name = "toolStripButtonAutoInspStart3";
            this.toolStripButtonAutoInspStart3.Size = new System.Drawing.Size(40, 36);
            this.toolStripButtonAutoInspStart3.Text = "Continuous Shot";
            this.toolStripButtonAutoInspStart3.ToolTipText = "Automatic Inspection";
            // 
            // toolStripButtonOneShot3
            // 
            this.toolStripButtonOneShot3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonOneShot3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonOneShot3.Image")));
            this.toolStripButtonOneShot3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonOneShot3.Name = "toolStripButtonOneShot3";
            this.toolStripButtonOneShot3.Size = new System.Drawing.Size(40, 36);
            this.toolStripButtonOneShot3.Text = "One Shot";
            this.toolStripButtonOneShot3.ToolTipText = "Capture Single Inspection";
            // 
            // toolStripButtonStop3
            // 
            this.toolStripButtonStop3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonStop3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonStop3.Image")));
            this.toolStripButtonStop3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonStop3.Name = "toolStripButtonStop3";
            this.toolStripButtonStop3.Size = new System.Drawing.Size(40, 36);
            this.toolStripButtonStop3.Text = "Stop Grab";
            this.toolStripButtonStop3.ToolTipText = "Stop Inspection";
            // 
            // toolStripLabel13
            // 
            this.toolStripLabel13.Name = "toolStripLabel13";
            this.toolStripLabel13.Size = new System.Drawing.Size(34, 36);
            this.toolStripLabel13.Text = "   ";
            // 
            // tsbZoomOut3
            // 
            this.tsbZoomOut3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomOut3.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomOut3.Image")));
            this.tsbZoomOut3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomOut3.Name = "tsbZoomOut3";
            this.tsbZoomOut3.Size = new System.Drawing.Size(40, 36);
            this.tsbZoomOut3.Text = "toolStripButton2";
            // 
            // tstxtZoomRatio3
            // 
            this.tstxtZoomRatio3.AutoSize = false;
            this.tstxtZoomRatio3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tstxtZoomRatio3.Font = new System.Drawing.Font("Malgun Gothic", 9F);
            this.tstxtZoomRatio3.Name = "tstxtZoomRatio3";
            this.tstxtZoomRatio3.Size = new System.Drawing.Size(78, 35);
            this.tstxtZoomRatio3.Text = "5.89";
            this.tstxtZoomRatio3.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // toolStripLabel14
            // 
            this.toolStripLabel14.Name = "toolStripLabel14";
            this.toolStripLabel14.Size = new System.Drawing.Size(31, 36);
            this.toolStripLabel14.Text = "%";
            // 
            // tsbZoomIn3
            // 
            this.tsbZoomIn3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomIn3.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomIn3.Image")));
            this.tsbZoomIn3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomIn3.Name = "tsbZoomIn3";
            this.tsbZoomIn3.Size = new System.Drawing.Size(40, 36);
            this.tsbZoomIn3.Text = "toolStripButton1";
            // 
            // toolStripLabel15
            // 
            this.toolStripLabel15.Name = "toolStripLabel15";
            this.toolStripLabel15.Size = new System.Drawing.Size(34, 36);
            this.toolStripLabel15.Text = "   ";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 42);
            // 
            // toolStripLabel16
            // 
            this.toolStripLabel16.Name = "toolStripLabel16";
            this.toolStripLabel16.Size = new System.Drawing.Size(55, 36);
            this.toolStripLabel16.Text = "연결";
            this.toolStripLabel16.Visible = false;
            // 
            // toolStripLabel17
            // 
            this.toolStripLabel17.Name = "toolStripLabel17";
            this.toolStripLabel17.Size = new System.Drawing.Size(71, 36);
            this.toolStripLabel17.Text = "CAM4";
            // 
            // toolStripButtonAutoInspStart4
            // 
            this.toolStripButtonAutoInspStart4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonAutoInspStart4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAutoInspStart4.Image")));
            this.toolStripButtonAutoInspStart4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAutoInspStart4.Name = "toolStripButtonAutoInspStart4";
            this.toolStripButtonAutoInspStart4.Size = new System.Drawing.Size(40, 36);
            this.toolStripButtonAutoInspStart4.Text = "Continuous Shot";
            this.toolStripButtonAutoInspStart4.ToolTipText = "Automatic Inspection";
            // 
            // toolStripButtonOneShot4
            // 
            this.toolStripButtonOneShot4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonOneShot4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonOneShot4.Image")));
            this.toolStripButtonOneShot4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonOneShot4.Name = "toolStripButtonOneShot4";
            this.toolStripButtonOneShot4.Size = new System.Drawing.Size(40, 36);
            this.toolStripButtonOneShot4.Text = "One Shot";
            this.toolStripButtonOneShot4.ToolTipText = "Capture Single Inspection";
            // 
            // toolStripButtonStop4
            // 
            this.toolStripButtonStop4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonStop4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonStop4.Image")));
            this.toolStripButtonStop4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonStop4.Name = "toolStripButtonStop4";
            this.toolStripButtonStop4.Size = new System.Drawing.Size(40, 36);
            this.toolStripButtonStop4.Text = "Stop Grab";
            this.toolStripButtonStop4.ToolTipText = "Stop Inspection";
            // 
            // toolStripLabel18
            // 
            this.toolStripLabel18.Name = "toolStripLabel18";
            this.toolStripLabel18.Size = new System.Drawing.Size(34, 36);
            this.toolStripLabel18.Text = "   ";
            // 
            // tsbZoomOut4
            // 
            this.tsbZoomOut4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomOut4.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomOut4.Image")));
            this.tsbZoomOut4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomOut4.Name = "tsbZoomOut4";
            this.tsbZoomOut4.Size = new System.Drawing.Size(40, 36);
            this.tsbZoomOut4.Text = "toolStripButton2";
            // 
            // tstxtZoomRatio4
            // 
            this.tstxtZoomRatio4.AutoSize = false;
            this.tstxtZoomRatio4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tstxtZoomRatio4.Font = new System.Drawing.Font("Malgun Gothic", 9F);
            this.tstxtZoomRatio4.Name = "tstxtZoomRatio4";
            this.tstxtZoomRatio4.Size = new System.Drawing.Size(54, 35);
            this.tstxtZoomRatio4.Text = "5.89";
            this.tstxtZoomRatio4.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // toolStripLabel19
            // 
            this.toolStripLabel19.Name = "toolStripLabel19";
            this.toolStripLabel19.Size = new System.Drawing.Size(31, 36);
            this.toolStripLabel19.Text = "%";
            // 
            // tsbZoomIn4
            // 
            this.tsbZoomIn4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbZoomIn4.Image = ((System.Drawing.Image)(resources.GetObject("tsbZoomIn4.Image")));
            this.tsbZoomIn4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbZoomIn4.Name = "tsbZoomIn4";
            this.tsbZoomIn4.Size = new System.Drawing.Size(40, 36);
            this.tsbZoomIn4.Text = "toolStripButton1";
            // 
            // toolStripLabel20
            // 
            this.toolStripLabel20.Name = "toolStripLabel20";
            this.toolStripLabel20.Size = new System.Drawing.Size(34, 36);
            this.toolStripLabel20.Text = "   ";
            // 
            // tabControlMain
            // 
            this.tabControlMain.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControlMain.Controls.Add(this.tabInspection);
            this.tabControlMain.Controls.Add(this.tabCameraConfig);
            this.tabControlMain.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabControlMain.Location = new System.Drawing.Point(2105, 83);
            this.tabControlMain.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabControlMain.Name = "tabControlMain";
            this.tabControlMain.SelectedIndex = 0;
            this.tabControlMain.Size = new System.Drawing.Size(505, 1902);
            this.tabControlMain.TabIndex = 2;
            // 
            // tabInspection
            // 
            this.tabInspection.Controls.Add(this.txtMsg2);
            this.tabInspection.Controls.Add(this.txtZOffset);
            this.tabInspection.Controls.Add(this.txtYOffset);
            this.tabInspection.Controls.Add(this.txtXOffset);
            this.tabInspection.Controls.Add(this.btnZOffset);
            this.tabInspection.Controls.Add(this.txtMsg1);
            this.tabInspection.Controls.Add(this.btnYOffset);
            this.tabInspection.Controls.Add(this.btnApply2);
            this.tabInspection.Controls.Add(this.btnXOffset);
            this.tabInspection.Controls.Add(this.btnApply1);
            this.tabInspection.Controls.Add(this.btnSCARA4Connect);
            this.tabInspection.Controls.Add(this.btnSCARA2Connect);
            this.tabInspection.Controls.Add(this.btnSCARA3Connect);
            this.tabInspection.Controls.Add(this.btnRN4);
            this.tabInspection.Controls.Add(this.btnRN2);
            this.tabInspection.Controls.Add(this.btnRN3);
            this.tabInspection.Controls.Add(this.btnRN1);
            this.tabInspection.Controls.Add(this.btnSO4);
            this.tabInspection.Controls.Add(this.btnSO2);
            this.tabInspection.Controls.Add(this.btnSO3);
            this.tabInspection.Controls.Add(this.btnSO1);
            this.tabInspection.Controls.Add(this.btnRSERR4);
            this.tabInspection.Controls.Add(this.btnRSERR2);
            this.tabInspection.Controls.Add(this.btnRSERR3);
            this.tabInspection.Controls.Add(this.btnRSERR1);
            this.tabInspection.Controls.Add(this.btnSCARA1Connect);
            this.tabInspection.Controls.Add(this.lstResults);
            this.tabInspection.Controls.Add(this.btnClearFrameCount);
            this.tabInspection.Controls.Add(this.lblMatchingResult4);
            this.tabInspection.Controls.Add(this.lblMatchingResult2);
            this.tabInspection.Controls.Add(this.lblMatchingResult3);
            this.tabInspection.Controls.Add(this.lblMatchingResult);
            this.tabInspection.Controls.Add(this.label3);
            this.tabInspection.Controls.Add(this.label1);
            this.tabInspection.Controls.Add(this.label2);
            this.tabInspection.Controls.Add(this.label52);
            this.tabInspection.Controls.Add(this.label18);
            this.tabInspection.Controls.Add(this.label5);
            this.tabInspection.Controls.Add(this.label17);
            this.tabInspection.Controls.Add(this.label22);
            this.tabInspection.Controls.Add(this.label21);
            this.tabInspection.Controls.Add(this.label20);
            this.tabInspection.Controls.Add(this.label19);
            this.tabInspection.Controls.Add(this.label33);
            this.tabInspection.Controls.Add(this.label16);
            this.tabInspection.Controls.Add(this.label4);
            this.tabInspection.Controls.Add(this.label15);
            this.tabInspection.Controls.Add(this.label30);
            this.tabInspection.Controls.Add(this.label10);
            this.tabInspection.Controls.Add(this.lblTotalTime4);
            this.tabInspection.Controls.Add(this.lblTotalTime2);
            this.tabInspection.Controls.Add(this.lblTotalTime3);
            this.tabInspection.Controls.Add(this.lblTotalTime);
            this.tabInspection.Controls.Add(this.lblFrameCount4);
            this.tabInspection.Controls.Add(this.lblFrameCount2);
            this.tabInspection.Controls.Add(this.lblFrameCount3);
            this.tabInspection.Controls.Add(this.lblFrameCount);
            this.tabInspection.Controls.Add(this.lblProcessingTime4);
            this.tabInspection.Controls.Add(this.lblProcessingTime2);
            this.tabInspection.Controls.Add(this.lblProcessingTime3);
            this.tabInspection.Controls.Add(this.lblProcessingTime);
            this.tabInspection.Controls.Add(this.btnSampleInspect);
            this.tabInspection.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabInspection.ForeColor = System.Drawing.Color.Black;
            this.tabInspection.Location = new System.Drawing.Point(4, 31);
            this.tabInspection.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabInspection.Name = "tabInspection";
            this.tabInspection.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabInspection.Size = new System.Drawing.Size(497, 1867);
            this.tabInspection.TabIndex = 0;
            this.tabInspection.Text = "Inspection";
            this.tabInspection.UseVisualStyleBackColor = true;
            // 
            // txtMsg2
            // 
            this.txtMsg2.Font = new System.Drawing.Font("Gulim", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtMsg2.Location = new System.Drawing.Point(37, 1717);
            this.txtMsg2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMsg2.Name = "txtMsg2";
            this.txtMsg2.Size = new System.Drawing.Size(319, 46);
            this.txtMsg2.TabIndex = 14;
            // 
            // txtZOffset
            // 
            this.txtZOffset.Font = new System.Drawing.Font("Gulim", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtZOffset.Location = new System.Drawing.Point(316, 1789);
            this.txtZOffset.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtZOffset.Name = "txtZOffset";
            this.txtZOffset.Size = new System.Drawing.Size(69, 46);
            this.txtZOffset.TabIndex = 14;
            this.txtZOffset.Text = "-30";
            // 
            // txtYOffset
            // 
            this.txtYOffset.Font = new System.Drawing.Font("Gulim", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtYOffset.Location = new System.Drawing.Point(179, 1789);
            this.txtYOffset.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtYOffset.Name = "txtYOffset";
            this.txtYOffset.Size = new System.Drawing.Size(69, 46);
            this.txtYOffset.TabIndex = 14;
            this.txtYOffset.Text = "15";
            // 
            // txtXOffset
            // 
            this.txtXOffset.Font = new System.Drawing.Font("Gulim", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtXOffset.Location = new System.Drawing.Point(37, 1789);
            this.txtXOffset.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtXOffset.Name = "txtXOffset";
            this.txtXOffset.Size = new System.Drawing.Size(69, 46);
            this.txtXOffset.TabIndex = 14;
            this.txtXOffset.Text = "-10";
            // 
            // btnZOffset
            // 
            this.btnZOffset.Location = new System.Drawing.Point(396, 1789);
            this.btnZOffset.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnZOffset.Name = "btnZOffset";
            this.btnZOffset.Size = new System.Drawing.Size(52, 61);
            this.btnZOffset.TabIndex = 13;
            this.btnZOffset.Text = "Z";
            this.btnZOffset.UseVisualStyleBackColor = true;
            this.btnZOffset.Click += new System.EventHandler(this.btnZOffset_Click);
            // 
            // txtMsg1
            // 
            this.txtMsg1.Font = new System.Drawing.Font("Gulim", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtMsg1.Location = new System.Drawing.Point(37, 1645);
            this.txtMsg1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMsg1.Name = "txtMsg1";
            this.txtMsg1.Size = new System.Drawing.Size(319, 46);
            this.txtMsg1.TabIndex = 14;
            // 
            // btnYOffset
            // 
            this.btnYOffset.Location = new System.Drawing.Point(260, 1789);
            this.btnYOffset.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnYOffset.Name = "btnYOffset";
            this.btnYOffset.Size = new System.Drawing.Size(52, 61);
            this.btnYOffset.TabIndex = 13;
            this.btnYOffset.Text = "Y";
            this.btnYOffset.UseVisualStyleBackColor = true;
            this.btnYOffset.Click += new System.EventHandler(this.btnYOffset_Click);
            // 
            // btnApply2
            // 
            this.btnApply2.Location = new System.Drawing.Point(366, 1717);
            this.btnApply2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnApply2.Name = "btnApply2";
            this.btnApply2.Size = new System.Drawing.Size(81, 61);
            this.btnApply2.TabIndex = 13;
            this.btnApply2.Text = "Apply";
            this.btnApply2.UseVisualStyleBackColor = true;
            this.btnApply2.Click += new System.EventHandler(this.btnApply2_Click);
            // 
            // btnXOffset
            // 
            this.btnXOffset.Location = new System.Drawing.Point(118, 1789);
            this.btnXOffset.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnXOffset.Name = "btnXOffset";
            this.btnXOffset.Size = new System.Drawing.Size(52, 61);
            this.btnXOffset.TabIndex = 13;
            this.btnXOffset.Text = "X";
            this.btnXOffset.UseVisualStyleBackColor = true;
            this.btnXOffset.Click += new System.EventHandler(this.btnXOffset_Click);
            // 
            // btnApply1
            // 
            this.btnApply1.Location = new System.Drawing.Point(366, 1645);
            this.btnApply1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnApply1.Name = "btnApply1";
            this.btnApply1.Size = new System.Drawing.Size(81, 61);
            this.btnApply1.TabIndex = 13;
            this.btnApply1.Text = "Apply";
            this.btnApply1.UseVisualStyleBackColor = true;
            this.btnApply1.Click += new System.EventHandler(this.btnApply1_Click);
            // 
            // btnSCARA4Connect
            // 
            this.btnSCARA4Connect.Location = new System.Drawing.Point(245, 1541);
            this.btnSCARA4Connect.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSCARA4Connect.Name = "btnSCARA4Connect";
            this.btnSCARA4Connect.Size = new System.Drawing.Size(205, 85);
            this.btnSCARA4Connect.TabIndex = 12;
            this.btnSCARA4Connect.Text = "SCARA4 CONNECT";
            this.btnSCARA4Connect.UseVisualStyleBackColor = true;
            this.btnSCARA4Connect.Click += new System.EventHandler(this.btnSCARA4Connect_Click);
            // 
            // btnSCARA2Connect
            // 
            this.btnSCARA2Connect.Location = new System.Drawing.Point(245, 1344);
            this.btnSCARA2Connect.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSCARA2Connect.Name = "btnSCARA2Connect";
            this.btnSCARA2Connect.Size = new System.Drawing.Size(205, 85);
            this.btnSCARA2Connect.TabIndex = 12;
            this.btnSCARA2Connect.Text = "SCARA2 CONNECT";
            this.btnSCARA2Connect.UseVisualStyleBackColor = true;
            this.btnSCARA2Connect.Click += new System.EventHandler(this.btnSCARA2Connect_Click);
            // 
            // btnSCARA3Connect
            // 
            this.btnSCARA3Connect.Location = new System.Drawing.Point(37, 1541);
            this.btnSCARA3Connect.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSCARA3Connect.Name = "btnSCARA3Connect";
            this.btnSCARA3Connect.Size = new System.Drawing.Size(205, 85);
            this.btnSCARA3Connect.TabIndex = 12;
            this.btnSCARA3Connect.Text = "SCARA3 CONNECT";
            this.btnSCARA3Connect.UseVisualStyleBackColor = true;
            this.btnSCARA3Connect.Click += new System.EventHandler(this.btnSCARA3Connect_Click);
            // 
            // btnRN4
            // 
            this.btnRN4.Location = new System.Drawing.Point(349, 1443);
            this.btnRN4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRN4.Name = "btnRN4";
            this.btnRN4.Size = new System.Drawing.Size(100, 37);
            this.btnRN4.TabIndex = 12;
            this.btnRN4.Text = "RUN4";
            this.btnRN4.UseVisualStyleBackColor = true;
            this.btnRN4.Click += new System.EventHandler(this.btnRN4_Click);
            // 
            // btnRN2
            // 
            this.btnRN2.Location = new System.Drawing.Point(349, 1245);
            this.btnRN2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRN2.Name = "btnRN2";
            this.btnRN2.Size = new System.Drawing.Size(100, 37);
            this.btnRN2.TabIndex = 12;
            this.btnRN2.Text = "RUN2";
            this.btnRN2.UseVisualStyleBackColor = true;
            this.btnRN2.Click += new System.EventHandler(this.btnRN2_Click);
            // 
            // btnRN3
            // 
            this.btnRN3.Location = new System.Drawing.Point(142, 1443);
            this.btnRN3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRN3.Name = "btnRN3";
            this.btnRN3.Size = new System.Drawing.Size(100, 37);
            this.btnRN3.TabIndex = 12;
            this.btnRN3.Text = "RUN3";
            this.btnRN3.UseVisualStyleBackColor = true;
            this.btnRN3.Click += new System.EventHandler(this.btnRN3_Click);
            // 
            // btnRN1
            // 
            this.btnRN1.Location = new System.Drawing.Point(142, 1245);
            this.btnRN1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRN1.Name = "btnRN1";
            this.btnRN1.Size = new System.Drawing.Size(100, 37);
            this.btnRN1.TabIndex = 12;
            this.btnRN1.Text = "RUN1";
            this.btnRN1.UseVisualStyleBackColor = true;
            this.btnRN1.Click += new System.EventHandler(this.btnRN1_Click);
            // 
            // btnSO4
            // 
            this.btnSO4.Location = new System.Drawing.Point(245, 1443);
            this.btnSO4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSO4.Name = "btnSO4";
            this.btnSO4.Size = new System.Drawing.Size(100, 37);
            this.btnSO4.TabIndex = 12;
            this.btnSO4.Text = "SrvON4";
            this.btnSO4.UseVisualStyleBackColor = true;
            this.btnSO4.Click += new System.EventHandler(this.btnSO4_Click);
            // 
            // btnSO2
            // 
            this.btnSO2.Location = new System.Drawing.Point(245, 1245);
            this.btnSO2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSO2.Name = "btnSO2";
            this.btnSO2.Size = new System.Drawing.Size(100, 37);
            this.btnSO2.TabIndex = 12;
            this.btnSO2.Text = "SrvON2";
            this.btnSO2.UseVisualStyleBackColor = true;
            this.btnSO2.Click += new System.EventHandler(this.btnSO2_Click);
            // 
            // btnSO3
            // 
            this.btnSO3.Location = new System.Drawing.Point(37, 1443);
            this.btnSO3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSO3.Name = "btnSO3";
            this.btnSO3.Size = new System.Drawing.Size(100, 37);
            this.btnSO3.TabIndex = 12;
            this.btnSO3.Text = "SrvON3";
            this.btnSO3.UseVisualStyleBackColor = true;
            this.btnSO3.Click += new System.EventHandler(this.btnSO3_Click);
            // 
            // btnSO1
            // 
            this.btnSO1.Location = new System.Drawing.Point(37, 1245);
            this.btnSO1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSO1.Name = "btnSO1";
            this.btnSO1.Size = new System.Drawing.Size(100, 37);
            this.btnSO1.TabIndex = 12;
            this.btnSO1.Text = "SrvON1";
            this.btnSO1.UseVisualStyleBackColor = true;
            this.btnSO1.Click += new System.EventHandler(this.btnSO1_Click);
            // 
            // btnRSERR4
            // 
            this.btnRSERR4.Location = new System.Drawing.Point(245, 1485);
            this.btnRSERR4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRSERR4.Name = "btnRSERR4";
            this.btnRSERR4.Size = new System.Drawing.Size(205, 51);
            this.btnRSERR4.TabIndex = 12;
            this.btnRSERR4.Text = "RESET ERR4";
            this.btnRSERR4.UseVisualStyleBackColor = true;
            this.btnRSERR4.Click += new System.EventHandler(this.btnRSERR4_Click);
            // 
            // btnRSERR2
            // 
            this.btnRSERR2.Location = new System.Drawing.Point(245, 1288);
            this.btnRSERR2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRSERR2.Name = "btnRSERR2";
            this.btnRSERR2.Size = new System.Drawing.Size(205, 51);
            this.btnRSERR2.TabIndex = 12;
            this.btnRSERR2.Text = "RESET ERR2";
            this.btnRSERR2.UseVisualStyleBackColor = true;
            this.btnRSERR2.Click += new System.EventHandler(this.btnRSERR2_Click);
            // 
            // btnRSERR3
            // 
            this.btnRSERR3.Location = new System.Drawing.Point(37, 1485);
            this.btnRSERR3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRSERR3.Name = "btnRSERR3";
            this.btnRSERR3.Size = new System.Drawing.Size(205, 51);
            this.btnRSERR3.TabIndex = 12;
            this.btnRSERR3.Text = "RESET ERR3";
            this.btnRSERR3.UseVisualStyleBackColor = true;
            this.btnRSERR3.Click += new System.EventHandler(this.btnRSERR3_Click);
            // 
            // btnRSERR1
            // 
            this.btnRSERR1.Location = new System.Drawing.Point(37, 1288);
            this.btnRSERR1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRSERR1.Name = "btnRSERR1";
            this.btnRSERR1.Size = new System.Drawing.Size(205, 51);
            this.btnRSERR1.TabIndex = 12;
            this.btnRSERR1.Text = "RESET ERR1";
            this.btnRSERR1.UseVisualStyleBackColor = true;
            this.btnRSERR1.Click += new System.EventHandler(this.btnRSERR1_Click);
            // 
            // btnSCARA1Connect
            // 
            this.btnSCARA1Connect.Location = new System.Drawing.Point(37, 1344);
            this.btnSCARA1Connect.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSCARA1Connect.Name = "btnSCARA1Connect";
            this.btnSCARA1Connect.Size = new System.Drawing.Size(205, 85);
            this.btnSCARA1Connect.TabIndex = 12;
            this.btnSCARA1Connect.Text = "SCARA1 CONNECT";
            this.btnSCARA1Connect.UseVisualStyleBackColor = true;
            this.btnSCARA1Connect.Click += new System.EventHandler(this.btnSCARA1Connect_Click);
            // 
            // lstResults
            // 
            this.lstResults.FormattingEnabled = true;
            this.lstResults.ItemHeight = 21;
            this.lstResults.Location = new System.Drawing.Point(23, 88);
            this.lstResults.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.lstResults.Name = "lstResults";
            this.lstResults.Size = new System.Drawing.Size(447, 403);
            this.lstResults.TabIndex = 11;
            this.lstResults.SelectedIndexChanged += new System.EventHandler(this.lstResults_SelectedIndexChanged);
            // 
            // btnClearFrameCount
            // 
            this.btnClearFrameCount.Location = new System.Drawing.Point(37, 1165);
            this.btnClearFrameCount.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnClearFrameCount.Name = "btnClearFrameCount";
            this.btnClearFrameCount.Size = new System.Drawing.Size(161, 53);
            this.btnClearFrameCount.TabIndex = 3;
            this.btnClearFrameCount.Text = "Reset";
            this.btnClearFrameCount.UseVisualStyleBackColor = true;
            this.btnClearFrameCount.Click += new System.EventHandler(this.btnClearFrameCount_Click);
            // 
            // lblMatchingResult4
            // 
            this.lblMatchingResult4.BackColor = System.Drawing.Color.Blue;
            this.lblMatchingResult4.Font = new System.Drawing.Font("Gulim", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblMatchingResult4.ForeColor = System.Drawing.Color.White;
            this.lblMatchingResult4.Location = new System.Drawing.Point(242, 731);
            this.lblMatchingResult4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMatchingResult4.Name = "lblMatchingResult4";
            this.lblMatchingResult4.Size = new System.Drawing.Size(219, 59);
            this.lblMatchingResult4.TabIndex = 10;
            this.lblMatchingResult4.Text = "0/0";
            this.lblMatchingResult4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMatchingResult2
            // 
            this.lblMatchingResult2.BackColor = System.Drawing.Color.Blue;
            this.lblMatchingResult2.Font = new System.Drawing.Font("Gulim", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblMatchingResult2.ForeColor = System.Drawing.Color.White;
            this.lblMatchingResult2.Location = new System.Drawing.Point(242, 595);
            this.lblMatchingResult2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMatchingResult2.Name = "lblMatchingResult2";
            this.lblMatchingResult2.Size = new System.Drawing.Size(219, 59);
            this.lblMatchingResult2.TabIndex = 10;
            this.lblMatchingResult2.Text = "0/0";
            this.lblMatchingResult2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMatchingResult3
            // 
            this.lblMatchingResult3.BackColor = System.Drawing.Color.Blue;
            this.lblMatchingResult3.Font = new System.Drawing.Font("Gulim", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblMatchingResult3.ForeColor = System.Drawing.Color.White;
            this.lblMatchingResult3.Location = new System.Drawing.Point(242, 664);
            this.lblMatchingResult3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMatchingResult3.Name = "lblMatchingResult3";
            this.lblMatchingResult3.Size = new System.Drawing.Size(219, 59);
            this.lblMatchingResult3.TabIndex = 10;
            this.lblMatchingResult3.Text = "0/0";
            this.lblMatchingResult3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMatchingResult
            // 
            this.lblMatchingResult.BackColor = System.Drawing.Color.Blue;
            this.lblMatchingResult.Font = new System.Drawing.Font("Gulim", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblMatchingResult.ForeColor = System.Drawing.Color.White;
            this.lblMatchingResult.Location = new System.Drawing.Point(242, 531);
            this.lblMatchingResult.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMatchingResult.Name = "lblMatchingResult";
            this.lblMatchingResult.Size = new System.Drawing.Size(219, 59);
            this.lblMatchingResult.TabIndex = 10;
            this.lblMatchingResult.Text = "0/0";
            this.lblMatchingResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Blue;
            this.label3.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(22, 731);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.label3.Size = new System.Drawing.Size(451, 59);
            this.label3.TabIndex = 10;
            this.label3.Text = "[4]Object Counts";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Blue;
            this.label1.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(22, 595);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.label1.Size = new System.Drawing.Size(451, 59);
            this.label1.TabIndex = 10;
            this.label1.Text = "[2]Object Counts";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Blue;
            this.label2.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(22, 664);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.label2.Size = new System.Drawing.Size(451, 59);
            this.label2.TabIndex = 10;
            this.label2.Text = "[3]Object Counts";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label52
            // 
            this.label52.BackColor = System.Drawing.Color.Blue;
            this.label52.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label52.ForeColor = System.Drawing.Color.White;
            this.label52.Location = new System.Drawing.Point(22, 531);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.label52.Size = new System.Drawing.Size(451, 59);
            this.label52.TabIndex = 10;
            this.label52.Text = "[1]Object Counts";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label18.Location = new System.Drawing.Point(404, 1043);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(61, 23);
            this.label18.TabIndex = 8;
            this.label18.Text = "mSec";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(404, 907);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 23);
            this.label5.TabIndex = 8;
            this.label5.Text = "mSec";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label17.Location = new System.Drawing.Point(404, 973);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(61, 23);
            this.label17.TabIndex = 8;
            this.label17.Text = "mSec";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label22.Location = new System.Drawing.Point(19, 1027);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(21, 23);
            this.label22.TabIndex = 8;
            this.label22.Text = "4";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label21.Location = new System.Drawing.Point(19, 963);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(21, 23);
            this.label21.TabIndex = 8;
            this.label21.Text = "3";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label20.Location = new System.Drawing.Point(19, 893);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(21, 23);
            this.label20.TabIndex = 8;
            this.label20.Text = "2";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label19.Location = new System.Drawing.Point(19, 827);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(21, 23);
            this.label19.TabIndex = 8;
            this.label19.Text = "1";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label33.Location = new System.Drawing.Point(404, 840);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(61, 23);
            this.label33.TabIndex = 8;
            this.label33.Text = "mSec";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label16.Location = new System.Drawing.Point(191, 1043);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(61, 23);
            this.label16.TabIndex = 8;
            this.label16.Text = "mSec";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(191, 907);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 23);
            this.label4.TabIndex = 8;
            this.label4.Text = "mSec";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label15.Location = new System.Drawing.Point(194, 973);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(61, 23);
            this.label15.TabIndex = 8;
            this.label15.Text = "mSec";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label30.Location = new System.Drawing.Point(194, 840);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(61, 23);
            this.label30.TabIndex = 8;
            this.label30.Text = "mSec";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.Location = new System.Drawing.Point(37, 1115);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(153, 23);
            this.label10.TabIndex = 8;
            this.label10.Text = "FRAME COUNT";
            // 
            // lblTotalTime4
            // 
            this.lblTotalTime4.BackColor = System.Drawing.Color.Olive;
            this.lblTotalTime4.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblTotalTime4.ForeColor = System.Drawing.Color.White;
            this.lblTotalTime4.Location = new System.Drawing.Point(278, 1013);
            this.lblTotalTime4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalTime4.Name = "lblTotalTime4";
            this.lblTotalTime4.Size = new System.Drawing.Size(118, 53);
            this.lblTotalTime4.TabIndex = 6;
            this.lblTotalTime4.Text = "0";
            this.lblTotalTime4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTotalTime2
            // 
            this.lblTotalTime2.BackColor = System.Drawing.Color.Olive;
            this.lblTotalTime2.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblTotalTime2.ForeColor = System.Drawing.Color.White;
            this.lblTotalTime2.Location = new System.Drawing.Point(278, 880);
            this.lblTotalTime2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalTime2.Name = "lblTotalTime2";
            this.lblTotalTime2.Size = new System.Drawing.Size(118, 53);
            this.lblTotalTime2.TabIndex = 6;
            this.lblTotalTime2.Text = "0";
            this.lblTotalTime2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTotalTime3
            // 
            this.lblTotalTime3.BackColor = System.Drawing.Color.Olive;
            this.lblTotalTime3.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblTotalTime3.ForeColor = System.Drawing.Color.White;
            this.lblTotalTime3.Location = new System.Drawing.Point(278, 947);
            this.lblTotalTime3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalTime3.Name = "lblTotalTime3";
            this.lblTotalTime3.Size = new System.Drawing.Size(118, 53);
            this.lblTotalTime3.TabIndex = 6;
            this.lblTotalTime3.Text = "0";
            this.lblTotalTime3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTotalTime
            // 
            this.lblTotalTime.BackColor = System.Drawing.Color.Olive;
            this.lblTotalTime.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblTotalTime.ForeColor = System.Drawing.Color.White;
            this.lblTotalTime.Location = new System.Drawing.Point(278, 813);
            this.lblTotalTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalTime.Name = "lblTotalTime";
            this.lblTotalTime.Size = new System.Drawing.Size(118, 53);
            this.lblTotalTime.TabIndex = 6;
            this.lblTotalTime.Text = "0";
            this.lblTotalTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFrameCount4
            // 
            this.lblFrameCount4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblFrameCount4.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblFrameCount4.ForeColor = System.Drawing.Color.White;
            this.lblFrameCount4.Location = new System.Drawing.Point(331, 1165);
            this.lblFrameCount4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFrameCount4.Name = "lblFrameCount4";
            this.lblFrameCount4.Size = new System.Drawing.Size(118, 53);
            this.lblFrameCount4.TabIndex = 6;
            this.lblFrameCount4.Text = "0";
            this.lblFrameCount4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFrameCount2
            // 
            this.lblFrameCount2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblFrameCount2.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblFrameCount2.ForeColor = System.Drawing.Color.White;
            this.lblFrameCount2.Location = new System.Drawing.Point(331, 1101);
            this.lblFrameCount2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFrameCount2.Name = "lblFrameCount2";
            this.lblFrameCount2.Size = new System.Drawing.Size(118, 53);
            this.lblFrameCount2.TabIndex = 6;
            this.lblFrameCount2.Text = "0";
            this.lblFrameCount2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFrameCount3
            // 
            this.lblFrameCount3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblFrameCount3.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblFrameCount3.ForeColor = System.Drawing.Color.White;
            this.lblFrameCount3.Location = new System.Drawing.Point(206, 1165);
            this.lblFrameCount3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFrameCount3.Name = "lblFrameCount3";
            this.lblFrameCount3.Size = new System.Drawing.Size(118, 53);
            this.lblFrameCount3.TabIndex = 6;
            this.lblFrameCount3.Text = "0";
            this.lblFrameCount3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFrameCount
            // 
            this.lblFrameCount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblFrameCount.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblFrameCount.ForeColor = System.Drawing.Color.White;
            this.lblFrameCount.Location = new System.Drawing.Point(206, 1101);
            this.lblFrameCount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFrameCount.Name = "lblFrameCount";
            this.lblFrameCount.Size = new System.Drawing.Size(118, 53);
            this.lblFrameCount.TabIndex = 6;
            this.lblFrameCount.Text = "0";
            this.lblFrameCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblProcessingTime4
            // 
            this.lblProcessingTime4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblProcessingTime4.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblProcessingTime4.ForeColor = System.Drawing.Color.White;
            this.lblProcessingTime4.Location = new System.Drawing.Point(66, 1013);
            this.lblProcessingTime4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProcessingTime4.Name = "lblProcessingTime4";
            this.lblProcessingTime4.Size = new System.Drawing.Size(118, 53);
            this.lblProcessingTime4.TabIndex = 6;
            this.lblProcessingTime4.Text = "0";
            this.lblProcessingTime4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblProcessingTime2
            // 
            this.lblProcessingTime2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblProcessingTime2.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblProcessingTime2.ForeColor = System.Drawing.Color.White;
            this.lblProcessingTime2.Location = new System.Drawing.Point(66, 880);
            this.lblProcessingTime2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProcessingTime2.Name = "lblProcessingTime2";
            this.lblProcessingTime2.Size = new System.Drawing.Size(118, 53);
            this.lblProcessingTime2.TabIndex = 6;
            this.lblProcessingTime2.Text = "0";
            this.lblProcessingTime2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblProcessingTime3
            // 
            this.lblProcessingTime3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblProcessingTime3.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblProcessingTime3.ForeColor = System.Drawing.Color.White;
            this.lblProcessingTime3.Location = new System.Drawing.Point(66, 947);
            this.lblProcessingTime3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProcessingTime3.Name = "lblProcessingTime3";
            this.lblProcessingTime3.Size = new System.Drawing.Size(118, 53);
            this.lblProcessingTime3.TabIndex = 6;
            this.lblProcessingTime3.Text = "0";
            this.lblProcessingTime3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblProcessingTime
            // 
            this.lblProcessingTime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblProcessingTime.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblProcessingTime.ForeColor = System.Drawing.Color.White;
            this.lblProcessingTime.Location = new System.Drawing.Point(66, 813);
            this.lblProcessingTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProcessingTime.Name = "lblProcessingTime";
            this.lblProcessingTime.Size = new System.Drawing.Size(118, 53);
            this.lblProcessingTime.TabIndex = 6;
            this.lblProcessingTime.Text = "0";
            this.lblProcessingTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSampleInspect
            // 
            this.btnSampleInspect.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnSampleInspect.Location = new System.Drawing.Point(15, 13);
            this.btnSampleInspect.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSampleInspect.Name = "btnSampleInspect";
            this.btnSampleInspect.Size = new System.Drawing.Size(462, 64);
            this.btnSampleInspect.TabIndex = 2;
            this.btnSampleInspect.Text = "Do Inspect Test";
            this.btnSampleInspect.UseVisualStyleBackColor = true;
            this.btnSampleInspect.Click += new System.EventHandler(this.btnSampleInspect_Click);
            // 
            // tabCameraConfig
            // 
            this.tabCameraConfig.Controls.Add(this.gridCalibration4);
            this.tabCameraConfig.Controls.Add(this.gridCalibration2);
            this.tabCameraConfig.Controls.Add(this.gridCalibration3);
            this.tabCameraConfig.Controls.Add(this.gridCalibration);
            this.tabCameraConfig.Location = new System.Drawing.Point(4, 31);
            this.tabCameraConfig.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabCameraConfig.Name = "tabCameraConfig";
            this.tabCameraConfig.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabCameraConfig.Size = new System.Drawing.Size(497, 1867);
            this.tabCameraConfig.TabIndex = 1;
            this.tabCameraConfig.Text = "Configuration";
            this.tabCameraConfig.UseVisualStyleBackColor = true;
            // 
            // gridCalibration4
            // 
            this.gridCalibration4.ColumnHeadersHeight = 25;
            this.gridCalibration4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewCheckBoxColumn3,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15});
            this.gridCalibration4.Location = new System.Drawing.Point(8, 589);
            this.gridCalibration4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gridCalibration4.Name = "gridCalibration4";
            this.gridCalibration4.RowHeadersWidth = 62;
            this.gridCalibration4.RowTemplate.Height = 23;
            this.gridCalibration4.Size = new System.Drawing.Size(477, 163);
            this.gridCalibration4.TabIndex = 25;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "No";
            this.dataGridViewTextBoxColumn11.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn11.Width = 30;
            // 
            // dataGridViewCheckBoxColumn3
            // 
            this.dataGridViewCheckBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dataGridViewCheckBoxColumn3.FalseValue = "0";
            this.dataGridViewCheckBoxColumn3.HeaderText = "활성화";
            this.dataGridViewCheckBoxColumn3.MinimumWidth = 8;
            this.dataGridViewCheckBoxColumn3.Name = "dataGridViewCheckBoxColumn3";
            this.dataGridViewCheckBoxColumn3.TrueValue = "1";
            this.dataGridViewCheckBoxColumn3.Width = 79;
            // 
            // dataGridViewTextBoxColumn12
            // 
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn12.DefaultCellStyle = dataGridViewCellStyle33;
            this.dataGridViewTextBoxColumn12.HeaderText = "픽셀X";
            this.dataGridViewTextBoxColumn12.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn12.Width = 120;
            // 
            // dataGridViewTextBoxColumn13
            // 
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn13.DefaultCellStyle = dataGridViewCellStyle34;
            this.dataGridViewTextBoxColumn13.HeaderText = "픽셀Y";
            this.dataGridViewTextBoxColumn13.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn13.Width = 120;
            // 
            // dataGridViewTextBoxColumn14
            // 
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn14.DefaultCellStyle = dataGridViewCellStyle35;
            this.dataGridViewTextBoxColumn14.HeaderText = "실제X";
            this.dataGridViewTextBoxColumn14.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn14.Width = 120;
            // 
            // dataGridViewTextBoxColumn15
            // 
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn15.DefaultCellStyle = dataGridViewCellStyle36;
            this.dataGridViewTextBoxColumn15.HeaderText = "실제Y";
            this.dataGridViewTextBoxColumn15.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn15.Width = 120;
            // 
            // gridCalibration2
            // 
            this.gridCalibration2.ColumnHeadersHeight = 25;
            this.gridCalibration2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gridCalibrationNo2,
            this.gridCalibrationUse2,
            this.gridCalibrationPixelX2,
            this.gridCalibrationPixelY2,
            this.gridCalibrationWorldX2,
            this.gridCalibrationWorldY2});
            this.gridCalibration2.Location = new System.Drawing.Point(8, 205);
            this.gridCalibration2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gridCalibration2.Name = "gridCalibration2";
            this.gridCalibration2.RowHeadersWidth = 62;
            this.gridCalibration2.RowTemplate.Height = 23;
            this.gridCalibration2.Size = new System.Drawing.Size(477, 163);
            this.gridCalibration2.TabIndex = 25;
            // 
            // gridCalibrationNo2
            // 
            this.gridCalibrationNo2.HeaderText = "No";
            this.gridCalibrationNo2.MinimumWidth = 8;
            this.gridCalibrationNo2.Name = "gridCalibrationNo2";
            this.gridCalibrationNo2.ReadOnly = true;
            this.gridCalibrationNo2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.gridCalibrationNo2.Width = 30;
            // 
            // gridCalibrationUse2
            // 
            this.gridCalibrationUse2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gridCalibrationUse2.FalseValue = "0";
            this.gridCalibrationUse2.HeaderText = "활성화";
            this.gridCalibrationUse2.MinimumWidth = 8;
            this.gridCalibrationUse2.Name = "gridCalibrationUse2";
            this.gridCalibrationUse2.TrueValue = "1";
            this.gridCalibrationUse2.Width = 79;
            // 
            // gridCalibrationPixelX2
            // 
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.gridCalibrationPixelX2.DefaultCellStyle = dataGridViewCellStyle37;
            this.gridCalibrationPixelX2.HeaderText = "픽셀X";
            this.gridCalibrationPixelX2.MinimumWidth = 8;
            this.gridCalibrationPixelX2.Name = "gridCalibrationPixelX2";
            this.gridCalibrationPixelX2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.gridCalibrationPixelX2.Width = 120;
            // 
            // gridCalibrationPixelY2
            // 
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.gridCalibrationPixelY2.DefaultCellStyle = dataGridViewCellStyle38;
            this.gridCalibrationPixelY2.HeaderText = "픽셀Y";
            this.gridCalibrationPixelY2.MinimumWidth = 8;
            this.gridCalibrationPixelY2.Name = "gridCalibrationPixelY2";
            this.gridCalibrationPixelY2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.gridCalibrationPixelY2.Width = 120;
            // 
            // gridCalibrationWorldX2
            // 
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.gridCalibrationWorldX2.DefaultCellStyle = dataGridViewCellStyle39;
            this.gridCalibrationWorldX2.HeaderText = "실제X";
            this.gridCalibrationWorldX2.MinimumWidth = 8;
            this.gridCalibrationWorldX2.Name = "gridCalibrationWorldX2";
            this.gridCalibrationWorldX2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.gridCalibrationWorldX2.Width = 120;
            // 
            // gridCalibrationWorldY2
            // 
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.gridCalibrationWorldY2.DefaultCellStyle = dataGridViewCellStyle40;
            this.gridCalibrationWorldY2.HeaderText = "실제Y";
            this.gridCalibrationWorldY2.MinimumWidth = 8;
            this.gridCalibrationWorldY2.Name = "gridCalibrationWorldY2";
            this.gridCalibrationWorldY2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.gridCalibrationWorldY2.Width = 120;
            // 
            // gridCalibration3
            // 
            this.gridCalibration3.ColumnHeadersHeight = 25;
            this.gridCalibration3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewCheckBoxColumn2,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10});
            this.gridCalibration3.Location = new System.Drawing.Point(8, 397);
            this.gridCalibration3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gridCalibration3.Name = "gridCalibration3";
            this.gridCalibration3.RowHeadersWidth = 62;
            this.gridCalibration3.RowTemplate.Height = 23;
            this.gridCalibration3.Size = new System.Drawing.Size(477, 163);
            this.gridCalibration3.TabIndex = 24;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "No";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 30;
            // 
            // dataGridViewCheckBoxColumn2
            // 
            this.dataGridViewCheckBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dataGridViewCheckBoxColumn2.FalseValue = "0";
            this.dataGridViewCheckBoxColumn2.HeaderText = "활성화";
            this.dataGridViewCheckBoxColumn2.MinimumWidth = 8;
            this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
            this.dataGridViewCheckBoxColumn2.TrueValue = "1";
            this.dataGridViewCheckBoxColumn2.Width = 79;
            // 
            // dataGridViewTextBoxColumn7
            // 
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle41;
            this.dataGridViewTextBoxColumn7.HeaderText = "픽셀X";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 120;
            // 
            // dataGridViewTextBoxColumn8
            // 
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle42;
            this.dataGridViewTextBoxColumn8.HeaderText = "픽셀Y";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn8.Width = 120;
            // 
            // dataGridViewTextBoxColumn9
            // 
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn9.DefaultCellStyle = dataGridViewCellStyle43;
            this.dataGridViewTextBoxColumn9.HeaderText = "실제X";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn9.Width = 120;
            // 
            // dataGridViewTextBoxColumn10
            // 
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn10.DefaultCellStyle = dataGridViewCellStyle44;
            this.dataGridViewTextBoxColumn10.HeaderText = "실제Y";
            this.dataGridViewTextBoxColumn10.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn10.Width = 120;
            // 
            // gridCalibration
            // 
            this.gridCalibration.ColumnHeadersHeight = 25;
            this.gridCalibration.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gridCalibrationNo,
            this.gridCalibrationUse,
            this.gridCalibrationPixelX,
            this.gridCalibrationPixelY,
            this.gridCalibrationWorldX,
            this.gridCalibrationWorldY});
            this.gridCalibration.Location = new System.Drawing.Point(8, 13);
            this.gridCalibration.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gridCalibration.Name = "gridCalibration";
            this.gridCalibration.RowHeadersWidth = 62;
            this.gridCalibration.RowTemplate.Height = 23;
            this.gridCalibration.Size = new System.Drawing.Size(477, 163);
            this.gridCalibration.TabIndex = 24;
            // 
            // gridCalibrationNo
            // 
            this.gridCalibrationNo.HeaderText = "No";
            this.gridCalibrationNo.MinimumWidth = 8;
            this.gridCalibrationNo.Name = "gridCalibrationNo";
            this.gridCalibrationNo.ReadOnly = true;
            this.gridCalibrationNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.gridCalibrationNo.Width = 30;
            // 
            // gridCalibrationUse
            // 
            this.gridCalibrationUse.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gridCalibrationUse.FalseValue = "0";
            this.gridCalibrationUse.HeaderText = "활성화";
            this.gridCalibrationUse.MinimumWidth = 8;
            this.gridCalibrationUse.Name = "gridCalibrationUse";
            this.gridCalibrationUse.TrueValue = "1";
            this.gridCalibrationUse.Width = 79;
            // 
            // gridCalibrationPixelX
            // 
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.gridCalibrationPixelX.DefaultCellStyle = dataGridViewCellStyle45;
            this.gridCalibrationPixelX.HeaderText = "픽셀X";
            this.gridCalibrationPixelX.MinimumWidth = 8;
            this.gridCalibrationPixelX.Name = "gridCalibrationPixelX";
            this.gridCalibrationPixelX.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.gridCalibrationPixelX.Width = 120;
            // 
            // gridCalibrationPixelY
            // 
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.gridCalibrationPixelY.DefaultCellStyle = dataGridViewCellStyle46;
            this.gridCalibrationPixelY.HeaderText = "픽셀Y";
            this.gridCalibrationPixelY.MinimumWidth = 8;
            this.gridCalibrationPixelY.Name = "gridCalibrationPixelY";
            this.gridCalibrationPixelY.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.gridCalibrationPixelY.Width = 120;
            // 
            // gridCalibrationWorldX
            // 
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.gridCalibrationWorldX.DefaultCellStyle = dataGridViewCellStyle47;
            this.gridCalibrationWorldX.HeaderText = "실제X";
            this.gridCalibrationWorldX.MinimumWidth = 8;
            this.gridCalibrationWorldX.Name = "gridCalibrationWorldX";
            this.gridCalibrationWorldX.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.gridCalibrationWorldX.Width = 120;
            // 
            // gridCalibrationWorldY
            // 
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.gridCalibrationWorldY.DefaultCellStyle = dataGridViewCellStyle48;
            this.gridCalibrationWorldY.HeaderText = "실제Y";
            this.gridCalibrationWorldY.MinimumWidth = 8;
            this.gridCalibrationWorldY.Name = "gridCalibrationWorldY";
            this.gridCalibrationWorldY.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.gridCalibrationWorldY.Width = 120;
            // 
            // imageListForDeviceList
            // 
            this.imageListForDeviceList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageListForDeviceList.ImageSize = new System.Drawing.Size(32, 32);
            this.imageListForDeviceList.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsslblAbsPosition,
            this.tsslblRelatedPosition,
            this.tsslblAbsPosition2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 1525);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 22, 0);
            this.statusStrip1.Size = new System.Drawing.Size(2564, 39);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsslblAbsPosition
            // 
            this.tsslblAbsPosition.Name = "tsslblAbsPosition";
            this.tsslblAbsPosition.Size = new System.Drawing.Size(313, 30);
            this.tsslblAbsPosition.Text = "Cursor Abs. Position : X-0 / Y-0";
            // 
            // tsslblRelatedPosition
            // 
            this.tsslblRelatedPosition.ForeColor = System.Drawing.Color.Black;
            this.tsslblRelatedPosition.Name = "tsslblRelatedPosition";
            this.tsslblRelatedPosition.Size = new System.Drawing.Size(60, 30);
            this.tsslblRelatedPosition.Text = "   |   ";
            this.tsslblRelatedPosition.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tsslblAbsPosition2
            // 
            this.tsslblAbsPosition2.Name = "tsslblAbsPosition2";
            this.tsslblAbsPosition2.Size = new System.Drawing.Size(313, 30);
            this.tsslblAbsPosition2.Text = "Cursor Abs. Position : X-0 / Y-0";
            // 
            // timerScroll
            // 
            this.timerScroll.Interval = 50;
            this.timerScroll.Tick += new System.EventHandler(this.timerScroll_Tick);
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.panel4);
            this.panel5.Controls.Add(this.panel3);
            this.panel5.Controls.Add(this.panel2);
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Location = new System.Drawing.Point(15, 83);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(2065, 1896);
            this.panel5.TabIndex = 10;
            // 
            // panel4
            // 
            this.panel4.AutoScroll = true;
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Controls.Add(this.label23);
            this.panel4.Controls.Add(this.pictureBox4);
            this.panel4.Location = new System.Drawing.Point(836, 723);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(811, 704);
            this.panel4.TabIndex = 13;
            // 
            // label23
            // 
            this.label23.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label23.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(8836, 1422);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(76, 53);
            this.label23.TabIndex = 6;
            this.label23.Text = "CAM2";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Black;
            this.pictureBox4.Location = new System.Drawing.Point(7, 5);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(580, 430);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox4.TabIndex = 1;
            this.pictureBox4.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Controls.Add(this.label24);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Location = new System.Drawing.Point(4, 723);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(811, 704);
            this.panel3.TabIndex = 12;
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label24.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(8833, 1443);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(76, 53);
            this.label24.TabIndex = 6;
            this.label24.Text = "CAM1";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Black;
            this.pictureBox3.Location = new System.Drawing.Point(7, 5);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(580, 430);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Controls.Add(this.label135);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Location = new System.Drawing.Point(836, 5);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(811, 704);
            this.panel2.TabIndex = 11;
            // 
            // label135
            // 
            this.label135.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label135.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label135.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label135.ForeColor = System.Drawing.Color.White;
            this.label135.Location = new System.Drawing.Point(8836, 1405);
            this.label135.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(76, 53);
            this.label135.TabIndex = 6;
            this.label135.Text = "CAM2";
            this.label135.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Black;
            this.pictureBox2.Location = new System.Drawing.Point(7, 3);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(580, 430);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.label132);
            this.panel1.Controls.Add(this.pictureBox);
            this.panel1.Location = new System.Drawing.Point(4, 5);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(811, 704);
            this.panel1.TabIndex = 10;
            // 
            // label132
            // 
            this.label132.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label132.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label132.Font = new System.Drawing.Font("Gulim", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label132.ForeColor = System.Drawing.Color.White;
            this.label132.Location = new System.Drawing.Point(8847, 1466);
            this.label132.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(76, 53);
            this.label132.TabIndex = 6;
            this.label132.Text = "CAM1";
            this.label132.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox
            // 
            this.pictureBox.BackColor = System.Drawing.Color.Black;
            this.pictureBox.Location = new System.Drawing.Point(7, 5);
            this.pictureBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(580, 430);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox.TabIndex = 1;
            this.pictureBox.TabStop = false;
            this.pictureBox.Click += new System.EventHandler(this.pictureBox_Click_1);
            // 
            // frmInspMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2564, 1564);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.tabControlMain);
            this.Controls.Add(this.toolStrip);
            this.Cursor = System.Windows.Forms.Cursors.Cross;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmInspMain";
            this.Text = " ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmInspMain_FormClosing);
            this.Load += new System.EventHandler(this.frmInspMain_Load);
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.tabControlMain.ResumeLayout(false);
            this.tabInspection.ResumeLayout(false);
            this.tabInspection.PerformLayout();
            this.tabCameraConfig.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridCalibration4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridCalibration2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridCalibration3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridCalibration)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.ToolStripButton toolStripButtonOneShot;
        private System.Windows.Forms.ToolStripButton toolStripButtonStop;
        private System.Windows.Forms.ToolStripButton toolStripButtonAutoInspStart;
        private System.Windows.Forms.TabControl tabControlMain;
        private System.Windows.Forms.TabPage tabInspection;
        private System.Windows.Forms.TabPage tabCameraConfig;
        private System.Windows.Forms.ImageList imageListForDeviceList;
        private System.Windows.Forms.Button btnSampleInspect;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label lblProcessingTime;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label lblTotalTime;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblFrameCount;
        private System.Windows.Forms.ToolStripButton tsbZoomOut;
        private System.Windows.Forms.ToolStripButton tsbZoomIn;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripTextBox tstxtZoomRatio;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsslblAbsPosition;
        private System.Windows.Forms.ToolStripStatusLabel tsslblRelatedPosition;
        private System.Windows.Forms.Timer timerScroll;
        private System.Windows.Forms.Button btnClearFrameCount;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label lblMatchingResult;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripButton toolStripButtonAutoInspStart2;
        private System.Windows.Forms.ToolStripButton toolStripButtonOneShot2;
        private System.Windows.Forms.ToolStripButton toolStripButtonStop2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel5;
        private System.Windows.Forms.ToolStripLabel toolStripLabel4;
        private System.Windows.Forms.ToolStripLabel toolStripLabel7;
        private System.Windows.Forms.ToolStripButton tsbZoomOut2;
        private System.Windows.Forms.ToolStripTextBox tstxtZoomRatio2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel8;
        private System.Windows.Forms.ToolStripButton tsbZoomIn2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel6;
        private System.Windows.Forms.Label lblFrameCount2;
        private System.Windows.Forms.Label lblMatchingResult2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblTotalTime2;
        private System.Windows.Forms.Label lblProcessingTime2;
        private System.Windows.Forms.ToolStripStatusLabel tsslblAbsPosition2;
        private System.Windows.Forms.DataGridView gridCalibration2;
        private System.Windows.Forms.DataGridView gridCalibration;
        private System.Windows.Forms.DataGridViewTextBoxColumn gridCalibrationNo;
        private System.Windows.Forms.DataGridViewCheckBoxColumn gridCalibrationUse;
        private System.Windows.Forms.DataGridViewTextBoxColumn gridCalibrationPixelX;
        private System.Windows.Forms.DataGridViewTextBoxColumn gridCalibrationPixelY;
        private System.Windows.Forms.DataGridViewTextBoxColumn gridCalibrationWorldX;
        private System.Windows.Forms.DataGridViewTextBoxColumn gridCalibrationWorldY;
        private System.Windows.Forms.ToolStripLabel toolStripLabel9;
        private System.Windows.Forms.ToolStripLabel toolStripLabel10;
        private System.Windows.Forms.Label lblMatchingResult4;
        private System.Windows.Forms.Label lblMatchingResult3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblTotalTime4;
        private System.Windows.Forms.Label lblTotalTime3;
        private System.Windows.Forms.Label lblFrameCount4;
        private System.Windows.Forms.Label lblFrameCount3;
        private System.Windows.Forms.Label lblProcessingTime4;
        private System.Windows.Forms.Label lblProcessingTime3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ListBox lstResults;
        private System.Windows.Forms.DataGridView gridCalibration4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridView gridCalibration3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel11;
        private System.Windows.Forms.ToolStripLabel toolStripLabel12;
        private System.Windows.Forms.ToolStripButton toolStripButtonAutoInspStart3;
        private System.Windows.Forms.ToolStripButton toolStripButtonOneShot3;
        private System.Windows.Forms.ToolStripButton toolStripButtonStop3;
        private System.Windows.Forms.ToolStripLabel toolStripLabel13;
        private System.Windows.Forms.ToolStripButton tsbZoomOut3;
        private System.Windows.Forms.ToolStripTextBox tstxtZoomRatio3;
        private System.Windows.Forms.ToolStripLabel toolStripLabel14;
        private System.Windows.Forms.ToolStripButton tsbZoomIn3;
        private System.Windows.Forms.ToolStripLabel toolStripLabel15;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripLabel toolStripLabel16;
        private System.Windows.Forms.ToolStripLabel toolStripLabel17;
        private System.Windows.Forms.ToolStripButton toolStripButtonAutoInspStart4;
        private System.Windows.Forms.ToolStripButton toolStripButtonOneShot4;
        private System.Windows.Forms.ToolStripButton toolStripButtonStop4;
        private System.Windows.Forms.ToolStripLabel toolStripLabel18;
        private System.Windows.Forms.ToolStripButton tsbZoomOut4;
        private System.Windows.Forms.ToolStripTextBox tstxtZoomRatio4;
        private System.Windows.Forms.ToolStripLabel toolStripLabel19;
        private System.Windows.Forms.ToolStripButton tsbZoomIn4;
        private System.Windows.Forms.ToolStripLabel toolStripLabel20;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Button btnSCARA1Connect;
        private System.Windows.Forms.Button btnSCARA4Connect;
        private System.Windows.Forms.Button btnSCARA2Connect;
        private System.Windows.Forms.Button btnSCARA3Connect;
        private System.Windows.Forms.Button btnApply2;
        private System.Windows.Forms.Button btnApply1;
        private System.Windows.Forms.TextBox txtMsg1;
        private System.Windows.Forms.TextBox txtMsg2;
        private System.Windows.Forms.Button btnSO1;
        private System.Windows.Forms.Button btnRN4;
        private System.Windows.Forms.Button btnRN2;
        private System.Windows.Forms.Button btnRN3;
        private System.Windows.Forms.Button btnRN1;
        private System.Windows.Forms.Button btnSO4;
        private System.Windows.Forms.Button btnSO2;
        private System.Windows.Forms.Button btnSO3;
        private System.Windows.Forms.Button btnRSERR1;
        private System.Windows.Forms.Button btnRSERR2;
        private System.Windows.Forms.Button btnRSERR4;
        private System.Windows.Forms.Button btnRSERR3;
        private System.Windows.Forms.DataGridViewTextBoxColumn gridCalibrationNo2;
        private System.Windows.Forms.DataGridViewCheckBoxColumn gridCalibrationUse2;
        private System.Windows.Forms.DataGridViewTextBoxColumn gridCalibrationPixelX2;
        private System.Windows.Forms.DataGridViewTextBoxColumn gridCalibrationPixelY2;
        private System.Windows.Forms.DataGridViewTextBoxColumn gridCalibrationWorldX2;
        private System.Windows.Forms.DataGridViewTextBoxColumn gridCalibrationWorldY2;
        private System.Windows.Forms.TextBox txtYOffset;
        private System.Windows.Forms.TextBox txtXOffset;
        private System.Windows.Forms.Button btnYOffset;
        private System.Windows.Forms.Button btnXOffset;
        private System.Windows.Forms.TextBox txtZOffset;
        private System.Windows.Forms.Button btnZOffset;
    }
}

