﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MVINSP_LINESCAN
{
    public partial class frmLoading : Form
    {
        private int nDotCount = 0;
        private int nMessageFlag = 0;
        private string[] strMessage = new string[4];

        public frmLoading()
        {
            InitializeComponent();

            strMessage[0] = "Loading Modules";
            strMessage[1] = "Loading Configurations";
            strMessage[2] = "Progress Calibration";
            strMessage[3] = "Loading Tool Preset";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void frmLoading_Load(object sender, EventArgs e)
        {
            timer1.Start();
            timer2.Start();
        }

        ~frmLoading()
        {
            timer1.Dispose();
            timer2.Dispose();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (nDotCount < 10)
            {
                lblLoading.Text += ".";
                nDotCount++;
            }
            else
            {
                nDotCount = 0;
                if(nMessageFlag < 3)    nMessageFlag++;

                lblLoading.Text = strMessage[nMessageFlag];
            }
        }
    }
}
