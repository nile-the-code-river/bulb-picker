﻿using System;
using System.IO.Ports;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
//using System.Collections;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using MVINSP_LINESCAN;   
using Basler.Pylon;
using Euresys.Open_eVision_22_12;// 유레시스 사에서 개발한 머신 비전용 소프트웨어 sdk open evision
using System.Runtime.InteropServices;
using System.Runtime.ExceptionServices;
using System.Net;
using System.Net.Sockets;

namespace MVINSP_LINESCAN
{
    public partial class frmInspMain : Form
    {
        [System.Runtime.InteropServices.DllImport("Kernel32.dll")]
        private static extern bool QueryPerformanceCounter(out long perfcount); // Kernel32.dll의 QueryPerformanceCounter라는 함수를 사용하여 고해상도 타이머의 카운터 값을 가져옵니다. 이 함수는 성능 측정 시 타이머의 정확한 값을 확인하는 데 사용됩니다. 이 함수는 long 형식의 값으로 성능 카운터 값을 반환합니다.
        [System.Runtime.InteropServices.DllImport("Kernel32.dll")]
        private static extern bool QueryPerformanceFrequency(out long freq); //QueryPerformanceFrequency는 성능 카운터의 주파수를 가져오는 함수입니다. 카운터가 초당 몇 번씩 증가하는지 알려줍니다. 이 값은 타이머를 기반으로 시간 측정을 정밀하게 하기 위해 사용됩니다.

        #region Pylon
        //네 개의 카메라 객체를 정의합니다.
        private Camera camera = null;
        private Camera camera2 = null;
        private Camera camera3 = null;
        private Camera camera4 = null;

        // PixelDataConverter는 픽셀 데이터를 처리하고 변환하는 데 사용되는 객체입니다. 각 카메라로부터 얻은 이미지를 처리하거나 포맷을 변환할 때 사용됩니다. 여기서는 세 개의 변환기
        private PixelDataConverter converter2 = new PixelDataConverter();
        private PixelDataConverter converter3 = new PixelDataConverter();
        private PixelDataConverter converter4 = new PixelDataConverter();

        //Stopwatch 객체는 시간 측정에 사용됩니다.카메라의 성능을 측정하거나, 이미지 캡처의 타이밍을 기록할 때 사용 각각 독립적인 시간 측정
        private Stopwatch stopWatch = new Stopwatch();
        private Stopwatch stopWatch2 = new Stopwatch();
        private Stopwatch stopWatch3 = new Stopwatch();
        private Stopwatch stopWatch4 = new Stopwatch();

        //private ImageProvider m_imageProvider = new ImageProvider(); /* Create one image provider. */
        //Bitmap 객체는 이미지를 저장하는 데 사용됩니다. 여기서는 가로 2590, 세로 2048 크기의 8비트 색상 인덱스를 가진 비트맵 이미지(m_bitmap)를 생성합니다
        private Bitmap m_bitmap = new Bitmap(2590, 2048, PixelFormat.Format8bppIndexed);
        private Bitmap m_CacheBitmap = null;  //캐시 비트맵으로 아직 초기화하지 않았으므로 null 처리
        private Bitmap m_bitmap2 = new Bitmap(2590, 2048, PixelFormat.Format8bppIndexed);
        private Bitmap m_CacheBitmap2 = null;
        private Bitmap m_bitmap3 = new Bitmap(2590, 2048, PixelFormat.Format8bppIndexed);
        private Bitmap m_CacheBitmap3 = null;
        private Bitmap m_bitmap4 = new Bitmap(2590, 2048, PixelFormat.Format8bppIndexed);
        private Bitmap m_CacheBitmap4 = null;
        #endregion

        #region Euresys
        EWorldShape EWorldShape1 = new EWorldShape(); // EWorldShape instance
        EWorldShape EWorldShape2 = new EWorldShape(); // EWorldShape instance
        EWorldShape EWorldShape3 = new EWorldShape(); // EWorldShape instance
        EWorldShape EWorldShape4 = new EWorldShape(); // EWorldShape instance
        EImageBW8 imgSrc = new EImageBW8(); // EImageBW8 instance
        EImageBW8 imgSrc2 = new EImageBW8(); // EImageBW8 instance
        EImageBW8 imgSrc3 = new EImageBW8(); // EImageBW8 instance
        EImageBW8 imgSrc4 = new EImageBW8(); // EImageBW8 instance

        EROIBW8 roiSrc = new EROIBW8();
        EROIBW8 roiSrc2 = new EROIBW8();
        EROIBW8 roiSrc3 = new EROIBW8();
        EROIBW8 roiSrc4 = new EROIBW8();
        EROIBW8 roiManual = new EROIBW8();
        EROIBW8 roiManual2 = new EROIBW8();
        EROIBW8 roiManual3 = new EROIBW8();
        EROIBW8 roiManual4 = new EROIBW8();
        EFrameShape EFrameShape1 = new EFrameShape(); // EFrameShape instance
        EFrameShape EFrameShape2 = new EFrameShape(); // EFrameShape instance
        EFrameShape EFrameShape3 = new EFrameShape(); // EFrameShape instance
        EFrameShape EFrameShape4 = new EFrameShape(); // EFrameShape instance
        ELineGauge ELineGaugeFindPosition = new ELineGauge();
        EPointGauge EPointGaugeFindPosition = new EPointGauge();
        EMatcher EMatcherFindPosition = new EMatcher();
        EMatcher EMatcherFindPosition2 = new EMatcher();
        EMatcher EMatcherFindPosition3 = new EMatcher();
        EMatcher EMatcherFindPosition4 = new EMatcher();
        #endregion

        #region Inspection Results
        ArrayList arrFrameShapes = new ArrayList();
        ArrayList arrFrameShapes2 = new ArrayList();
        ArrayList arrFrameShapes3 = new ArrayList();
        ArrayList arrFrameShapes4 = new ArrayList();
        ArrayList arrToolResults = new ArrayList();
        ArrayList arrToolResults2 = new ArrayList();
        ArrayList arrToolResults3 = new ArrayList();
        ArrayList arrToolResults4 = new ArrayList();
        ArrayList arrIsToolActivate = new ArrayList();
        ArrayList arrIsToolActivate2 = new ArrayList();
        ArrayList arrIsToolActivate3 = new ArrayList();
        ArrayList arrIsToolActivate4 = new ArrayList();
        ArrayList arrRepeatResult = new ArrayList();
        ArrayList arrRepeatResult2 = new ArrayList();
        ArrayList arrRepeatResult3 = new ArrayList();
        ArrayList arrRepeatResult4 = new ArrayList();
        #endregion

        // 여러 카메라 시스템을 동시에 제어, 성능 측정, 이미지 데이터를 처리하는 데 필요한 변수 선언
        private frmLoading fLoading;  //로딩 화면을 표시하는 폼 객체, 이미지 처리 중이거나 데이터를 로드하는 동안 사용자에게 대기 상태를 보여주는데 사용

        // System.Diagnostics.Stopwatch 클래스를 사용하여 시간을 측정하는 타이머
        private System.Diagnostics.Stopwatch swInspProc; //검사 프로세스의 시간을 측정하는데 타이머 객체
        private System.Diagnostics.Stopwatch swTotalProc; //전체 프로세스 시간을 측정하는 객체
        private System.Diagnostics.Stopwatch swInspProc2; //2번
        private System.Diagnostics.Stopwatch swTotalProc2;
        private System.Diagnostics.Stopwatch swInspProc3; //3번
        private System.Diagnostics.Stopwatch swTotalProc3;
        private System.Diagnostics.Stopwatch swInspProc4; //4번
        private System.Diagnostics.Stopwatch swTotalProc4;

        //각 카메라에 보여주는 이미지를 저장하는 배열 객체
        private ArrayList arrImages = new ArrayList(); 
        private ArrayList arrImages2 = new ArrayList();
        private ArrayList arrImages3 = new ArrayList();
        private ArrayList arrImages4 = new ArrayList();

        //각 카메라에서 처리된 프레임 수를 기록하는 변수들
        private int n_FrameCount = 0;  //첫번쨰 카메라의 처리된 프레임 수. 일단 0으로 초기화
        private int n_FrameCount2 = 0; //두번째 카메라의 처리된 프레임 수. 일단 0으로 초기화
        private int n_FrameCount3 = 0; //3
        private int n_FrameCount4 = 0; // 4
        private int TOTAL_FRAME_COUNT = 1;  //첫번쨰 카메라의 처리된 총 프레임수
        private int TOTAL_FRAME_COUNT2 = 1; //두번째
        private int TOTAL_FRAME_COUNT3 = 1; //세번쨰
        private int TOTAL_FRAME_COUNT4 = 1;  // 네번쨰 카메라의 처리된 총 프레임 수

        // 각 카메라의 해상도를 조정하는 변수. 너비와 높이를 일단 0으로 초기화
        private int nResolutionWidth = 0;
        private int nResolutionHeight = 0;
        private int nResolutionWidth2 = 0;
        private int nResolutionHeight2 = 0;
        private int nResolutionWidth3 = 0;
        private int nResolutionHeight3 = 0;
        private int nResolutionWidth4 = 0;
        private int nResolutionHeight4 = 0;


        // ROI(관심영역)의 좌표와 크기를 나타내는 변수들. ROI는 이미지에서 처리할 특정 영역을 나타냄
        private int nDMCodeROI_X = 0;  //첫번째 카메라의 관심영역 x좌표
        private int nDMCodeROI_X2 = 0;
        private int nDMCodeROI_X3 = 0;
        private int nDMCodeROI_X4 = 0;
        private int nDMCodeROI_Y = 0; //첫번째 카메라의 관심영역 y좌표
        private int nDMCodeROI_Y2 = 0;
        private int nDMCodeROI_Y3 = 0;
        private int nDMCodeROI_Y4 = 0;
        private int nDMCodeROI_WIDTH = 0;  //첫번쨰 카메라의 관심영역 너비
        private int nDMCodeROI_WIDTH2 = 0;
        private int nDMCodeROI_WIDTH3 = 0;
        private int nDMCodeROI_WIDTH4 = 0;
        private int nDMCodeROI_HEIGHT = 0; //첫번째 카메라의 관심영역 높이
        private int nDMCodeROI_HEIGHT2 = 0;
        private int nDMCodeROI_HEIGHT3 = 0;
        private int nDMCodeROI_HEIGHT4 = 0;

        private int n_defaultPictureBoxWidth = 0;
        private int n_defaultPictureBoxHeight = 0;
        private int n_defaultPictureBoxWidth2 = 0;
        private int n_defaultPictureBoxHeight2 = 0;
        private int n_defaultPictureBoxWidth3 = 0;
        private int n_defaultPictureBoxHeight3 = 0;
        private int n_defaultPictureBoxWidth4 = 0;
        private int n_defaultPictureBoxHeight4 = 0;

        private bool b_isOneShot = false;
        private bool b_isOneShot2 = false;
        private bool b_isOneShot3 = false;
        private bool b_isOneShot4 = false;

        Point pPositionOfFirstClickScroll;

        OpenFileDialog ofdCurrentFile;
        OpenFileDialog ofdCurrentFile2;
        OpenFileDialog ofdCurrentFile3;
        OpenFileDialog ofdCurrentFile4;
        OpenFileDialog ofdMatchingFile;
        OpenFileDialog ofdMatchingFile2;
        OpenFileDialog ofdMatchingFile3;
        OpenFileDialog ofdMatchingFile4;

        OpenFileDialog ofdToolPreset;
        OpenFileDialog ofdToolPreset2;
        OpenFileDialog ofdToolPreset3;
        OpenFileDialog ofdToolPreset4;

        private float fMatchMinScore = 0.60f;
        private float fMatchMinScore2 = 0.60f;
        private float fMatchMinScore3 = 0.60f;
        private float fMatchMinScore4 = 0.60f;
        private float fMatchingAngle = 1.00f;
        private float fMatchingAngle2 = 1.00f;
        private float fMatchingAngle3 = 1.00f;
        private float fMatchingAngle4 = 1.00f;
        private int nMatchingCount = 1;
        private int nMatchingCount2 = 1;
        private int nMatchingCount3 = 1;
        private int nMatchingCount4 = 1;

        /* COMM Preset */
        private string strPortName = "";
        private string strBaudRate = "";

        /* TCPIP SCARA Controller IP Endpoint Preset */
        IPEndPoint ipepSCARA1, ipepSCARA2, ipepSCARA3, ipepSCARA4;
        IPEndPoint ipepSCARA1CMD, ipepSCARA2CMD, ipepSCARA3CMD, ipepSCARA4CMD;
        Socket clientSCARA1, clientSCARA2, clientSCARA3, clientSCARA4;
        Socket clientSCARA1CMD, clientSCARA2CMD, clientSCARA3CMD, clientSCARA4CMD;
        string SCARA1_IP = "192.168.0.11";
        string SCARA2_IP = "192.168.0.12";
        string SCARA3_IP = "192.168.0.21";
        string SCARA4_IP = "192.168.0.22";
        int SCARA1_SYS_PORT = 1000;
        int SCARA2_SYS_PORT = 1000;
        int SCARA3_SYS_PORT = 1000;
        int SCARA4_SYS_PORT = 1000;
        int SCARA1_PORT = 8011;
        int SCARA2_PORT = 8012;
        int SCARA3_PORT = 8021;
        int SCARA4_PORT = 8022;
        bool bFlagSCARA1 = false;
        bool bFlagSCARA2 = false;
        bool bFlagSCARA3 = false;
        bool bFlagSCARA4 = false;
        //보통 scara 로봇 장비 제조사들은 이런 포맷으로 데이터를 주고받는다. 스칼라는 TCP/IP 기반 소켓통신
        string strMsgSCARA1 = "2,321.064,-503.605,227.472,1,0,0,221.064,-403.605,200.472,2,0,0\r";
        string strMsgSCARA2 = "2,321.064,-503.605,227.472,1,0,0,221.064,-403.605,200.472,2,0,0\r";
        string strMsgSCARA3 = "2,321.064,-503.605,227.472,1,0,0,221.064,-403.605,200.472,2,0,0\r";
        string strMsgSCARA4 = "2,321.064,-503.605,227.472,1,0,0,221.064,-403.605,200.472,2,0,0\r";
        float fScaraXOffset = 0.000f;
        float fScaraYOffset = 0.000f;
        float fScaraZOffset = 0.000f;

        public frmInspMain()
        {
            fLoading = new MVINSP_LINESCAN.frmLoading();
            fLoading.ShowDialog();
            InitializeComponent();

            this.Cursor = Cursors.WaitCursor;

            #region Basler
            EnableButtons(false, false);
            EnableButtons2(false, false);
            EnableButtons3(false, false);
            EnableButtons4(false, false);
            #endregion

            swInspProc = new System.Diagnostics.Stopwatch();
            swTotalProc = new System.Diagnostics.Stopwatch();
            swInspProc2 = new System.Diagnostics.Stopwatch();
            swTotalProc2 = new System.Diagnostics.Stopwatch();
            swInspProc3 = new System.Diagnostics.Stopwatch();
            swTotalProc3 = new System.Diagnostics.Stopwatch();
            swInspProc4 = new System.Diagnostics.Stopwatch();
            swTotalProc4 = new System.Diagnostics.Stopwatch();

            try
            {
                GetSystemConfig();
            }
            catch (Exception ex)
            {
                MessageBox.Show("시스템 설정파일을 불러오는 중 에러가 발생하였습니다. 프로그램 경로의 CONFIG.INI 파일을 확인하여주세요.");
                SaveExceptionLog(ex.StackTrace);
            }

            if (ofdToolPreset != null && ofdToolPreset.FileName != "")
            {
                try
                {
                    GetToolPreset();
                    GetToolPreset2();
                    GetToolPreset3();
                    GetToolPreset4();
                    UpdateDataGrid();
                    UpdateDataGrid2();
                    UpdateDataGrid3();
                    UpdateDataGrid4();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    MessageBox.Show("기본 툴 프리셋을 설정하는 중 에러가 발생하였습니다. 기본 툴 설정파일을 확인하여 주세요.");
                    SaveExceptionLog(ex.StackTrace);
                }
            }
        }
        private void frmInspMain_Load(object sender, EventArgs e)
        {
            n_defaultPictureBoxWidth = panel5.Width / 2 - 10;
            n_defaultPictureBoxWidth = panel5.Width / 2 - 10;
            n_defaultPictureBoxHeight = panel5.Height / 2 - 7;
            n_defaultPictureBoxWidth2 = panel5.Width / 2 - 10;
            n_defaultPictureBoxHeight2 = panel5.Height / 2 - 7;
            n_defaultPictureBoxWidth3 = panel5.Width / 2 - 10;
            n_defaultPictureBoxHeight3 = panel5.Height / 2 - 7;
            n_defaultPictureBoxWidth4 = panel5.Width / 2 - 10;
            n_defaultPictureBoxHeight4 = panel5.Height / 2 - 7;

            this.Cursor = Cursors.Cross;

            panel1.Width = panel5.Width / 2 - 10;
            panel1.Height = panel5.Height / 2 - 7;
            panel2.Width = panel5.Width / 2 - 10;
            panel2.Height = panel5.Height / 2 - 7;
            panel2.Left = panel5.Width / 2;
            panel3.Width = panel5.Width / 2 - 10;
            panel3.Height = panel5.Height / 2 - 7;
            panel3.Top = panel5.Height / 2;
            panel4.Width = panel5.Width / 2 - 10;
            panel4.Height = panel5.Height / 2 - 7;
            panel4.Top = panel5.Height / 2;
            panel4.Left = panel5.Width / 2;

            txtMsg1.Text = strMsgSCARA1.Trim();
            txtMsg2.Text = strMsgSCARA3.Trim();

            if (camera == null) //L
            {
                try
                {
                    // Create a new camera object.
                    camera = new Camera("40007011");
                    camera.CameraOpened += Configuration.AcquireContinuous;
                    // Register for the events of the image provider needed for proper operation.
                    camera.ConnectionLost += OnConnectionLost;
                    camera.CameraOpened += OnCameraOpened;
                    camera.CameraClosed += OnCameraClosed;
                    camera.StreamGrabber.GrabStarted += OnGrabStarted;
                    camera.StreamGrabber.ImageGrabbed += OnImageGrabbed;
                    camera.StreamGrabber.GrabStopped += OnGrabStopped;
                    camera.Open();
                }
                catch (Exception exception)
                {
                    MessageBox.Show("지정된 카메라 연결에 실패하였습니다. \r\n 카메라 연결상태 혹은 다른 프로그램에서 카메라에 연결되어있는지 확인하세요.");
                    //ShowException(exception);
                }
            }

            if (camera2 == null) //R
            {
                try
                {
                    // Create a new camera object.
                    camera2 = new Camera("40012243");
                    camera2.CameraOpened += Configuration.AcquireContinuous;
                    // Register for the events of the image provider needed for proper operation.
                    camera2.ConnectionLost += OnConnectionLost2;
                    camera2.CameraOpened += OnCameraOpened2;
                    camera2.CameraClosed += OnCameraClosed2;
                    camera2.StreamGrabber.GrabStarted += OnGrabStarted2;
                    camera2.StreamGrabber.ImageGrabbed += OnImageGrabbed2;
                    camera2.StreamGrabber.GrabStopped += OnGrabStopped2;
                    camera2.Open();
                }
                catch (Exception exception)
                {
                    MessageBox.Show("지정된 카메라 연결에 실패하였습니다. \r\n 카메라 연결상태 혹은 다른 프로그램에서 카메라에 연결되어있는지 확인하세요.");
                    //ShowException(exception);
                }
            }

            fScaraXOffset = float.Parse(txtXOffset.Text.Trim());
            fScaraYOffset = float.Parse(txtYOffset.Text.Trim());
            fScaraZOffset = float.Parse(txtZOffset.Text.Trim());

            Calibrate();
            Calibrate2();
        }
        private void frmInspMain_FormClosing(object sender, FormClosingEventArgs ev)
        {
            try
            {
                if (clientSCARA1 != null && clientSCARA1.Connected) clientSCARA1.Close();
                if (clientSCARA2 != null && clientSCARA2.Connected) clientSCARA2.Close();
                if (clientSCARA3 != null && clientSCARA3.Connected) clientSCARA3.Close();
                if (clientSCARA4 != null && clientSCARA4.Connected) clientSCARA4.Close();
            }
            catch (Exception ex)
            {
            }
            DestroyCamera();
        }
        private void DestroyCamera()
        {
            // Destroy the camera object.
            try
            {
                if (camera != null)
                {
                    camera.Close();
                    camera.Dispose();
                    camera = null;
                }
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }

            // Destroy the camera object.
            try
            {
                if (camera2 != null)
                {
                    camera2.Close();
                    camera2.Dispose();
                    camera2 = null;
                }
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }

            // Destroy the camera object.
            try
            {
                if (camera3 != null)
                {
                    camera3.Close();
                    camera3.Dispose();
                    camera3 = null;
                }
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }

            // Destroy the camera object.
            try
            {
                if (camera4 != null)
                {
                    camera4.Close();
                    camera4.Dispose();
                    camera4 = null;
                }
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }

        private void ScaraConnect1()
        {
            try
            {
                ipepSCARA1 = new IPEndPoint(IPAddress.Parse(SCARA1_IP), SCARA1_PORT);
                clientSCARA1 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                clientSCARA1.Connect(ipepSCARA1);
                btnSCARA1Connect.Text = "SCARA1 DISCONNECT";
                // 접속이 되면 Task로 병렬 처리
                new Task(() =>
                {
                    try
                    {
                        // 종료되면 자동 client 종료
                        // 무한 루프
                        while (true)
                        {
                            var binary = new Byte[4096];
                            clientSCARA1.Receive(binary);
                            var data = Encoding.ASCII.GetString(binary).Trim('\0');
                            if (String.IsNullOrWhiteSpace(data))
                            {
                                continue;
                            }
                            AddListResult("[SCARA1] " + data);
                        }
                    }
                    catch (SocketException ex)
                    {
                        //btnSCARA1Connect.Text = "SCARA1 CONNECT";
                        AddListResult("[SCARA1] DISCONNECTED");
                        initConnectScara1("SCARA1 CONNECT");
                        // 접속 끝김이 발생하면 Exception이 발생
                        //ShowException(ex);
                    }
                }).Start();
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }
        private void ScaraConnect2()
        {
            try
            {
                ipepSCARA2 = new IPEndPoint(IPAddress.Parse(SCARA2_IP), SCARA2_PORT);
                clientSCARA2 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                clientSCARA2.Connect(ipepSCARA2);
                btnSCARA2Connect.Text = "SCARA2 DISCONNECT";
                // 접속이 되면 Task로 병렬 처리
                new Task(() =>
                {
                    try
                    {
                        // 종료되면 자동 client 종료
                        // 무한 루프
                        while (true)
                        {
                            var binary = new Byte[4096];
                            clientSCARA2.Receive(binary);
                            var data = Encoding.ASCII.GetString(binary).Trim('\0');
                            if (String.IsNullOrWhiteSpace(data))
                            {
                                continue;
                            }
                            AddListResult("[SCARA2] " + data);
                        }
                    }
                    catch (SocketException ex)
                    {
                        //btnSCARA2Connect.Text = "SCARA2 CONNECT";
                        AddListResult("[SCARA2] DISCONNECTED");
                        // 접속 끝김이 발생하면 Exception이 발생
                        //ShowException(ex);
                    }
                }).Start();
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }
        private void ScaraConnect3()
        {
            try
            {
                ipepSCARA3 = new IPEndPoint(IPAddress.Parse(SCARA3_IP), SCARA3_PORT);
                clientSCARA3 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                clientSCARA3.Connect(ipepSCARA3);
                btnSCARA3Connect.Text = "SCARA3 DISCONNECT";
                // 접속이 되면 Task로 병렬 처리
                new Task(() =>
                {
                    try
                    {
                        // 종료되면 자동 client 종료
                        // 무한 루프
                        while (true)
                        {
                            var binary = new Byte[4096];
                            clientSCARA3.Receive(binary);
                            var data = Encoding.ASCII.GetString(binary).Trim('\0');
                            if (String.IsNullOrWhiteSpace(data))
                            {
                                continue;
                            }
                            AddListResult("[SCARA3] " + data);
                        }
                    }
                    catch (SocketException ex)
                    {
                        // 접속 끝김이 발생하면 Exception이 발생
                        ShowException(ex);
                    }
                }).Start();
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }
        private void ScaraConnect4()
        {
            try
            {
                ipepSCARA4 = new IPEndPoint(IPAddress.Parse(SCARA4_IP), SCARA4_PORT);
                clientSCARA4 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                clientSCARA4.Connect(ipepSCARA4);
                btnSCARA4Connect.Text = "SCARA4 DISCONNECT";
                // 접속이 되면 Task로 병렬 처리
                new Task(() =>
                {
                    try
                    {
                        // 종료되면 자동 client 종료
                        // 무한 루프
                        while (true)
                        {
                            var binary = new Byte[4096];
                            clientSCARA4.Receive(binary);
                            var data = Encoding.ASCII.GetString(binary).Trim('\0');
                            if (String.IsNullOrWhiteSpace(data))
                            {
                                continue;
                            }
                            AddListResult("[SCARA4] " + data);
                        }
                    }
                    catch (SocketException ex)
                    {
                        // 접속 끝김이 발생하면 Exception이 발생
                        ShowException(ex);
                    }
                }).Start();
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }
        private void ScaraDisconnect1()
        {
            clientSCARA1.Close();
        }
        private void ScaraDisconnect2()
        {
            clientSCARA2.Close();
        }
        private void ScaraDisconnect3()
        {
            clientSCARA3.Close();
        }
        private void ScaraDisconnect4()
        {
            clientSCARA4.Close();
        }

        //이 메서드는 scara 장비에게 so\r 라는 명령을 보내는 함수. tcp/ip 소켓통신을 이용해서 연결하고 명령을 전송하는 구조이다.
        //scara로 so 명령 전송 -> 장비 상태 요청 -> 특정 기능수행
        //so : servo On : 모터에 전원을 공급. 동작을 준비 (이동 가능 상태)
        // rn : Reset Node (리셋 또는 에러 초기화) : 에러 초기화, 비상 정지 해제, 재가동 준비
        private void ScaraSO1()
        {
            try
            {
                if (clientSCARA1CMD != null && clientSCARA1CMD.Connected)
                {
                    clientSCARA1CMD.Send(Encoding.ASCII.GetBytes("SO\r"));
                }
                else
                {
                    ipepSCARA1CMD = new IPEndPoint(IPAddress.Parse(SCARA1_IP), SCARA1_SYS_PORT);
                    clientSCARA1CMD = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    clientSCARA1CMD.Connect(ipepSCARA1CMD);
                    clientSCARA1CMD.Send(Encoding.ASCII.GetBytes("SO\r"));
                }
            }
            catch (Exception exception)
            {
                //ShowException(exception);
            }
        }
        private void ScaraSO2()
        {
            try
            {
                if (clientSCARA2CMD != null && clientSCARA2CMD.Connected)
                {
                    clientSCARA2CMD.Send(Encoding.ASCII.GetBytes("SO\r"));
                }
                else
                {
                    ipepSCARA2CMD = new IPEndPoint(IPAddress.Parse(SCARA2_IP), SCARA2_SYS_PORT);
                    clientSCARA2CMD = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    clientSCARA2CMD.Connect(ipepSCARA2CMD);
                    clientSCARA2CMD.Send(Encoding.ASCII.GetBytes("SO\r"));
                }
            }
            catch (Exception exception)
            {
                //ShowException(exception);
            }
        }
        private void ScaraSO3()
        {
            try
            {
                if (clientSCARA3CMD != null && clientSCARA3CMD.Connected)
                {
                    clientSCARA3CMD.Send(Encoding.ASCII.GetBytes("SO\r"));
                }
                else
                {
                    ipepSCARA3CMD = new IPEndPoint(IPAddress.Parse(SCARA3_IP), SCARA3_SYS_PORT);
                    clientSCARA3CMD = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    clientSCARA3CMD.Connect(ipepSCARA3CMD);
                    clientSCARA3CMD.Send(Encoding.ASCII.GetBytes("SO\r"));
                }
            }
            catch (Exception exception)
            {
                //ShowException(exception);
            }
        }
        private void ScaraSO4()
        {
            try
            {
                if (clientSCARA4CMD != null && clientSCARA4CMD.Connected)
                {
                    clientSCARA4CMD.Send(Encoding.ASCII.GetBytes("SO\r"));
                }
                else
                {
                    ipepSCARA4CMD = new IPEndPoint(IPAddress.Parse(SCARA4_IP), SCARA4_SYS_PORT);
                    clientSCARA4CMD = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    clientSCARA4CMD.Connect(ipepSCARA4CMD);
                    clientSCARA4CMD.Send(Encoding.ASCII.GetBytes("SO\r"));
                }
            }
            catch (Exception exception)
            {
                //ShowException(exception);
            }
        }

        private void ScaraRN1()
        {
            try
            {
                if (clientSCARA1CMD != null && clientSCARA1CMD.Connected)
                {
                    clientSCARA1CMD.Send(Encoding.ASCII.GetBytes("RN\r"));
                }
                else
                {
                    ipepSCARA1CMD = new IPEndPoint(IPAddress.Parse(SCARA1_IP), SCARA1_SYS_PORT);
                    clientSCARA1CMD = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    clientSCARA1CMD.Connect(ipepSCARA1CMD);
                    clientSCARA1CMD.Send(Encoding.ASCII.GetBytes("RN\r"));
                }
            }
            catch (Exception exception)
            {
                //ShowException(exception);
            }
        }
        private void ScaraRN2()
        {
            try
            {
                if (clientSCARA2CMD != null && clientSCARA2CMD.Connected)
                {
                    clientSCARA2CMD.Send(Encoding.ASCII.GetBytes("RN\r"));
                }
                else
                {
                    ipepSCARA2CMD = new IPEndPoint(IPAddress.Parse(SCARA2_IP), SCARA2_SYS_PORT);
                    clientSCARA2CMD = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    clientSCARA2CMD.Connect(ipepSCARA2CMD);
                    clientSCARA2CMD.Send(Encoding.ASCII.GetBytes("RN\r"));
                }
            }
            catch (Exception exception)
            {
                //ShowException(exception);
            }
        }
        private void ScaraRN3()
        {
            try
            {
                if (clientSCARA3CMD != null && clientSCARA3CMD.Connected)
                {
                    clientSCARA3CMD.Send(Encoding.ASCII.GetBytes("RN\r"));
                }
                else
                {
                    ipepSCARA3CMD = new IPEndPoint(IPAddress.Parse(SCARA3_IP), SCARA3_SYS_PORT);
                    clientSCARA3CMD = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    clientSCARA3CMD.Connect(ipepSCARA3CMD);
                    clientSCARA3CMD.Send(Encoding.ASCII.GetBytes("RN\r"));
                }
            }
            catch (Exception exception)
            {
                //ShowException(exception);
            }
        }
        private void ScaraRN4()
        {
            try
            {
                if (clientSCARA4CMD != null && clientSCARA4CMD.Connected)
                {
                    clientSCARA4CMD.Send(Encoding.ASCII.GetBytes("RN\r"));
                }
                else
                {
                    ipepSCARA4CMD = new IPEndPoint(IPAddress.Parse(SCARA4_IP), SCARA4_SYS_PORT);
                    clientSCARA4CMD = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    clientSCARA4CMD.Connect(ipepSCARA4CMD);
                    clientSCARA4CMD.Send(Encoding.ASCII.GetBytes("RN\r"));
                }
            }
            catch (Exception exception)
            {
                //ShowException(exception);
            }
        }
         
        private void ScaraRSERR1()
        {
            try
            {
                if (clientSCARA1CMD != null && clientSCARA1CMD.Connected)
                {
                    clientSCARA1CMD.Send(Encoding.ASCII.GetBytes("RS,ERR\r"));
                }
                else
                {
                    ipepSCARA1CMD = new IPEndPoint(IPAddress.Parse(SCARA1_IP), SCARA1_SYS_PORT);
                    clientSCARA1CMD = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    clientSCARA1CMD.Connect(ipepSCARA1CMD);
                    clientSCARA1CMD.Send(Encoding.ASCII.GetBytes("RS,ERR\r"));
                }
            }
            catch (Exception exception)
            {
                //ShowException(exception);
            }
        }
        private void ScaraRSERR2()
        {
            try
            {
                if (clientSCARA2CMD != null && clientSCARA2CMD.Connected)
                {
                    clientSCARA2CMD.Send(Encoding.ASCII.GetBytes("RS,ERR\r"));
                }
                else
                {
                    ipepSCARA2CMD = new IPEndPoint(IPAddress.Parse(SCARA2_IP), SCARA2_SYS_PORT);
                    clientSCARA2CMD = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    clientSCARA2CMD.Connect(ipepSCARA2CMD);
                    clientSCARA2CMD.Send(Encoding.ASCII.GetBytes("RS,ERR\r"));
                }
            }
            catch (Exception exception)
            {
                //ShowException(exception);
            }
        }
        private void ScaraRSERR3()
        {
            try
            {
                if (clientSCARA3CMD != null && clientSCARA3CMD.Connected)
                {
                    clientSCARA3CMD.Send(Encoding.ASCII.GetBytes("RS,ERR\r"));
                }
                else
                {
                    ipepSCARA3CMD = new IPEndPoint(IPAddress.Parse(SCARA3_IP), SCARA3_SYS_PORT);
                    clientSCARA3CMD = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    clientSCARA3CMD.Connect(ipepSCARA3CMD);
                    clientSCARA3CMD.Send(Encoding.ASCII.GetBytes("RS,ERR\r"));
                }
            }
            catch (Exception exception)
            {
                //ShowException(exception);
            }
        }
        private void ScaraRSERR4()
        {
            try
            {
                if (clientSCARA4CMD != null && clientSCARA4CMD.Connected)
                {
                    clientSCARA4CMD.Send(Encoding.ASCII.GetBytes("RS,ERR\r"));
                }
                else
                {
                    ipepSCARA4CMD = new IPEndPoint(IPAddress.Parse(SCARA4_IP), SCARA4_SYS_PORT);
                    clientSCARA4CMD = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    clientSCARA4CMD.Connect(ipepSCARA4CMD);
                    clientSCARA4CMD.Send(Encoding.ASCII.GetBytes("RS,ERR\r"));
                }
            }
            catch (Exception exception)
            {
                //ShowException(exception);
            }
        }

        private void AddListResult(string msg)
        {
            if (lstResults.InvokeRequired)
            {
                lstResults.Invoke(new MethodInvoker(delegate { lstResults.Items.Add(msg); }));
            }
            else
            {
                lstResults.Items.Add(msg);
            }
        }
        // 현재 실행중인 스레드가 UI 스레드인지 확인. 만약 InvokeRequired == true이면 지금은 백그라운드 스레드에서 실행중이라는 뜻. 따라서 직접 btnSCARA1Connect.Text를 바꾸면 안됨
        private void initConnectScara1(string msg)
        {
            if(btnSCARA1Connect.InvokeRequired)
            {
                //UI스레드에게 이 작업을 대신 실행해줘 (백그라운드 스레드가) 요청. MethodInvoker : 반환값 없는 델리게이트 (간단한 Action과 비슷). delegate : 익명 메서드. 버튼 텍스트를 변경
                btnSCARA1Connect.Invoke(new MethodInvoker(delegate { btnSCARA1Connect.Text = msg; }));
            } else
            {
                btnSCARA1Connect.Text = msg;
            }
        }

        // INI 파일에서 특정 키의 값을 읽어옴
        #region Support Functions
        [DllImport("kernel32")] //kernel32는 windows os의 핵심 시스템 라이브러리 (윈도우 API 호출 기능)  DLLImport는 네이티브 DLL의 함수를 C#에서 사용할 수 있게 만들어주는 어트리뷰트
        public static extern int GetPrivateProfileString(string section, string key, string default1, StringBuilder result, int size, string path);
        
        //INI 파일에 값을 기록
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string path);
        
        //특정 섹션의 모든 키 값 쌍을 읽어옴
        [DllImport("kernel32")]
        private static extern uint GetPrivateProfileSection(string IpAppName, byte[] IpPairValues, uint nSize, string IpFileName);
        public string[] GetIniValue(string Section, string path)
        {
            byte[] ba = new byte[5000];
            uint Flag = GetPrivateProfileSection(Section, ba, 5000, path);
            return Encoding.Default.GetString(ba).Split(new char[1] { '\0' }, StringSplitOptions.RemoveEmptyEntries);
        }

        // 장비 프로그램이 부팅할 때 설정파일 config.ini을 읽어서 시스템 초기설정값을 불러오는 과정이다.
        //ini파일에서 여러 검사기 프리셋, 캘리브레이션 보정값, 이미지 프레임 정보 등을 읽어와서 프로그램 변수 및 UI 그리드에 로드하는 초기화 함수
        private void GetSystemConfig()
        {
            StringBuilder result = new StringBuilder(255);

            GetPrivateProfileString("DEFAULT PRESET", "FILE_NAME", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            ofdToolPreset = new OpenFileDialog();
            ofdToolPreset.FileName = result.ToString();

            GetPrivateProfileString("DEFAULT PRESET2", "FILE_NAME", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            ofdToolPreset2 = new OpenFileDialog();
            ofdToolPreset2.FileName = result.ToString();

            GetPrivateProfileString("DEFAULT PRESET3", "FILE_NAME", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            ofdToolPreset3 = new OpenFileDialog();
            ofdToolPreset3.FileName = result.ToString();

            GetPrivateProfileString("DEFAULT PRESET4", "FILE_NAME", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            ofdToolPreset4 = new OpenFileDialog();
            ofdToolPreset4.FileName = result.ToString();

            int nTotalCalibrationCount;
            int nTotalCalibrationCount2;
            int nTotalCalibrationCount3;
            int nTotalCalibrationCount4;
            GetPrivateProfileString("CALIBRATION_INFO", "CALIBRATION_COUNT", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            nTotalCalibrationCount = int.Parse(result.ToString());
            GetPrivateProfileString("CALIBRATION_INFO2", "CALIBRATION_COUNT", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            nTotalCalibrationCount2 = int.Parse(result.ToString());
            GetPrivateProfileString("CALIBRATION_INFO3", "CALIBRATION_COUNT", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            nTotalCalibrationCount3 = int.Parse(result.ToString());
            GetPrivateProfileString("CALIBRATION_INFO4", "CALIBRATION_COUNT", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            nTotalCalibrationCount4 = int.Parse(result.ToString());

            GetPrivateProfileString("CALIBRATION_INFO", "CALIBRATION_METHOD", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            if (result.ToString().Trim() == "1") { } else if (result.ToString().Trim() == "2") { }
            GetPrivateProfileString("CALIBRATION_INFO", "GRAB_FRAME_COUNT", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            TOTAL_FRAME_COUNT = int.Parse(result.ToString().Trim());
            GetPrivateProfileString("CALIBRATION_INFO", "RESOLUTION_WIDTH", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            nResolutionWidth = int.Parse(result.ToString().Trim());
            GetPrivateProfileString("CALIBRATION_INFO", "RESOLUTION_HEIGHT", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            nResolutionHeight = int.Parse(result.ToString().Trim());
            //gridToolSet.Rows.Clear();
            for (int i = 0; i < nTotalCalibrationCount; i++)
            {
                gridCalibration.Rows.Add();
                string[] ColumnName = GetIniValue("CALIBRATION_PRESET_" + i.ToString(), Application.StartupPath + "\\CONFIG.INI");
                foreach (string str in ColumnName)
                {
                    gridCalibration[int.Parse(str.Split('=')[0].Replace("CALIBRATION_", "")), i].Value = str.Split('=')[1];
                }
            }

            GetPrivateProfileString("CALIBRATION_INFO2", "GRAB_FRAME_COUNT", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            TOTAL_FRAME_COUNT2 = int.Parse(result.ToString().Trim());
            GetPrivateProfileString("CALIBRATION_INFO2", "RESOLUTION_WIDTH", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            nResolutionWidth2 = int.Parse(result.ToString().Trim());
            GetPrivateProfileString("CALIBRATION_INFO2", "RESOLUTION_HEIGHT", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            nResolutionHeight2 = int.Parse(result.ToString().Trim());
            for (int i = 0; i < nTotalCalibrationCount2; i++)
            {
                gridCalibration2.Rows.Add();
                string[] ColumnName = GetIniValue("CALIBRATION_PRESET2_" + i.ToString(), Application.StartupPath + "\\CONFIG.INI");
                foreach (string str in ColumnName)
                {
                    gridCalibration2[int.Parse(str.Split('=')[0].Replace("CALIBRATION_", "")), i].Value = str.Split('=')[1];
                }
            }

            GetPrivateProfileString("CALIBRATION_INFO3", "GRAB_FRAME_COUNT", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            TOTAL_FRAME_COUNT3 = int.Parse(result.ToString().Trim());
            GetPrivateProfileString("CALIBRATION_INFO3", "RESOLUTION_WIDTH", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            nResolutionWidth3 = int.Parse(result.ToString().Trim());
            GetPrivateProfileString("CALIBRATION_INFO3", "RESOLUTION_HEIGHT", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            nResolutionHeight3 = int.Parse(result.ToString().Trim());
            for (int i = 0; i < nTotalCalibrationCount3; i++)
            {
                gridCalibration3.Rows.Add();
                string[] ColumnName = GetIniValue("CALIBRATION_PRESET3_" + i.ToString(), Application.StartupPath + "\\CONFIG.INI");
                foreach (string str in ColumnName)
                {
                    gridCalibration3[int.Parse(str.Split('=')[0].Replace("CALIBRATION_", "")), i].Value = str.Split('=')[1];
                }
            }

            GetPrivateProfileString("CALIBRATION_INFO4", "GRAB_FRAME_COUNT", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            TOTAL_FRAME_COUNT4 = int.Parse(result.ToString().Trim());
            GetPrivateProfileString("CALIBRATION_INFO4", "RESOLUTION_WIDTH", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            nResolutionWidth4 = int.Parse(result.ToString().Trim());
            GetPrivateProfileString("CALIBRATION_INFO4", "RESOLUTION_HEIGHT", "none", result, 255, Application.StartupPath + "\\CONFIG.INI");
            nResolutionHeight4 = int.Parse(result.ToString().Trim());
            for (int i = 0; i < nTotalCalibrationCount4; i++)
            {
                gridCalibration4.Rows.Add();
                string[] ColumnName = GetIniValue("CALIBRATION_PRESET4_" + i.ToString(), Application.StartupPath + "\\CONFIG.INI");
                foreach (string str in ColumnName)
                {
                    gridCalibration4[int.Parse(str.Split('=')[0].Replace("CALIBRATION_", "")), i].Value = str.Split('=')[1];
                }
            }
        }
        //GetPrivateProfileString("DEFAULT TOOL", "METHOD", "none", result, 255, ofdToolPreset.FileName);
        //GetIniValue("TOOL_PRESET_" + i.ToString(), ofdToolPreset.FileName);
        private void GetToolPreset()
        {
            StringBuilder result = new StringBuilder(255);

            GetPrivateProfileString("MATCHING", "FILE_NAME", "none", result, 255, ofdToolPreset.FileName);
            ofdMatchingFile = new OpenFileDialog();
            ofdMatchingFile.FileName = result.ToString();
            if (ofdMatchingFile != null && ofdMatchingFile.FileName != "") PatternMatchingLearn();

            GetPrivateProfileString("MATCHING", "SCORE", "0.76", result, 255, ofdToolPreset.FileName);
            fMatchMinScore = float.Parse(result.ToString());

            GetPrivateProfileString("MATCHING", "ANGLE", "45", result, 255, ofdToolPreset.FileName);
            fMatchingAngle = float.Parse(result.ToString());

            GetPrivateProfileString("MATCHING", "COUNT", "45", result, 255, ofdToolPreset.FileName);
            nMatchingCount = int.Parse(result.ToString());

            GetPrivateProfileString("DMCODE_ROI_INFO", "X", "none", result, 255, ofdToolPreset.FileName);
            nDMCodeROI_X = int.Parse(result.ToString());
            GetPrivateProfileString("DMCODE_ROI_INFO", "Y", "none", result, 255, ofdToolPreset.FileName);
            nDMCodeROI_Y = int.Parse(result.ToString());
            GetPrivateProfileString("DMCODE_ROI_INFO", "WIDTH", "none", result, 255, ofdToolPreset.FileName);
            nDMCodeROI_WIDTH = int.Parse(result.ToString());
            GetPrivateProfileString("DMCODE_ROI_INFO", "HEIGHT", "none", result, 255, ofdToolPreset.FileName);
            nDMCodeROI_HEIGHT = int.Parse(result.ToString());
        }
        private void GetToolPreset2()
        {
            StringBuilder result = new StringBuilder(255);

            GetPrivateProfileString("MATCHING", "FILE_NAME", "none", result, 255, ofdToolPreset2.FileName);
            ofdMatchingFile2 = new OpenFileDialog();
            ofdMatchingFile2.FileName = result.ToString();
            if (ofdMatchingFile2 != null && ofdMatchingFile2.FileName != "") PatternMatchingLearn2();

            GetPrivateProfileString("MATCHING", "SCORE", "0.76", result, 255, ofdToolPreset2.FileName);
            fMatchMinScore2 = float.Parse(result.ToString());

            GetPrivateProfileString("MATCHING", "ANGLE", "45", result, 255, ofdToolPreset2.FileName);
            fMatchingAngle2 = float.Parse(result.ToString());

            GetPrivateProfileString("MATCHING", "COUNT", "45", result, 255, ofdToolPreset2.FileName);
            nMatchingCount2 = int.Parse(result.ToString());

            GetPrivateProfileString("DMCODE_ROI_INFO", "X", "none", result, 255, ofdToolPreset2.FileName);
            nDMCodeROI_X2 = int.Parse(result.ToString());
            GetPrivateProfileString("DMCODE_ROI_INFO", "Y", "none", result, 255, ofdToolPreset2.FileName);
            nDMCodeROI_Y2 = int.Parse(result.ToString());
            GetPrivateProfileString("DMCODE_ROI_INFO", "WIDTH", "none", result, 255, ofdToolPreset2.FileName);
            nDMCodeROI_WIDTH2 = int.Parse(result.ToString());
            GetPrivateProfileString("DMCODE_ROI_INFO", "HEIGHT", "none", result, 255, ofdToolPreset2.FileName);
            nDMCodeROI_HEIGHT2 = int.Parse(result.ToString());

        }
        private void GetToolPreset3()
        {
            StringBuilder result = new StringBuilder(255);

            GetPrivateProfileString("MATCHING", "FILE_NAME", "none", result, 255, ofdToolPreset3.FileName);
            ofdMatchingFile3 = new OpenFileDialog();
            ofdMatchingFile3.FileName = result.ToString();
            if (ofdMatchingFile3 != null && ofdMatchingFile3.FileName != "") PatternMatchingLearn3();

            GetPrivateProfileString("MATCHING", "SCORE", "0.76", result, 255, ofdToolPreset3.FileName);
            fMatchMinScore3 = float.Parse(result.ToString());

            GetPrivateProfileString("MATCHING", "ANGLE", "45", result, 255, ofdToolPreset3.FileName);
            fMatchingAngle3 = float.Parse(result.ToString());

            GetPrivateProfileString("MATCHING", "COUNT", "45", result, 255, ofdToolPreset3.FileName);
            nMatchingCount3 = int.Parse(result.ToString());

            GetPrivateProfileString("DMCODE_ROI_INFO", "X", "none", result, 255, ofdToolPreset3.FileName);
            nDMCodeROI_X3 = int.Parse(result.ToString());
            GetPrivateProfileString("DMCODE_ROI_INFO", "Y", "none", result, 255, ofdToolPreset3.FileName);
            nDMCodeROI_Y3 = int.Parse(result.ToString());
            GetPrivateProfileString("DMCODE_ROI_INFO", "WIDTH", "none", result, 255, ofdToolPreset3.FileName);
            nDMCodeROI_WIDTH3 = int.Parse(result.ToString());
            GetPrivateProfileString("DMCODE_ROI_INFO", "HEIGHT", "none", result, 255, ofdToolPreset3.FileName);
            nDMCodeROI_HEIGHT3 = int.Parse(result.ToString());

        }
        private void GetToolPreset4()
        {
            StringBuilder result = new StringBuilder(255);

            GetPrivateProfileString("MATCHING", "FILE_NAME", "none", result, 255, ofdToolPreset4.FileName);
            ofdMatchingFile4 = new OpenFileDialog();
            ofdMatchingFile4.FileName = result.ToString();
            if (ofdMatchingFile4 != null && ofdMatchingFile4.FileName != "") PatternMatchingLearn4();

            GetPrivateProfileString("MATCHING", "SCORE", "0.76", result, 255, ofdToolPreset4.FileName);
            fMatchMinScore4 = float.Parse(result.ToString());

            GetPrivateProfileString("MATCHING", "ANGLE", "45", result, 255, ofdToolPreset4.FileName);
            fMatchingAngle4 = float.Parse(result.ToString());

            GetPrivateProfileString("MATCHING", "COUNT", "45", result, 255, ofdToolPreset4.FileName);
            nMatchingCount4 = int.Parse(result.ToString());

            GetPrivateProfileString("DMCODE_ROI_INFO", "X", "none", result, 255, ofdToolPreset4.FileName);
            nDMCodeROI_X4 = int.Parse(result.ToString());
            GetPrivateProfileString("DMCODE_ROI_INFO", "Y", "none", result, 255, ofdToolPreset4.FileName);
            nDMCodeROI_Y4 = int.Parse(result.ToString());
            GetPrivateProfileString("DMCODE_ROI_INFO", "WIDTH", "none", result, 255, ofdToolPreset4.FileName);
            nDMCodeROI_WIDTH4 = int.Parse(result.ToString());
            GetPrivateProfileString("DMCODE_ROI_INFO", "HEIGHT", "none", result, 255, ofdToolPreset4.FileName);
            nDMCodeROI_HEIGHT4 = int.Parse(result.ToString());

        }
        public bool IsSingleShotSupported()
        {
            // Camera can be null if not yet opened
            if (camera == null)
            {
                return false;
            }

            // Camera can be closed
            if (!camera.IsOpen)
            {
                return false;
            }

            bool canSet = camera.Parameters[PLCamera.AcquisitionMode].CanSetValue("SingleFrame");
            return canSet;
        }
        public bool IsSingleShotSupported2()
        {
            // Camera can be null if not yet opened
            if (camera2 == null)
            {
                return false;
            }

            // Camera can be closed
            if (!camera2.IsOpen)
            {
                return false;
            }

            bool canSet = camera2.Parameters[PLCamera.AcquisitionMode].CanSetValue("SingleFrame");
            return canSet;
        }
        public bool IsSingleShotSupported3()
        {
            // Camera can be null if not yet opened
            if (camera3 == null)
            {
                return false;
            }

            // Camera can be closed
            if (!camera3.IsOpen)
            {
                return false;
            }

            bool canSet = camera3.Parameters[PLCamera.AcquisitionMode].CanSetValue("SingleFrame");
            return canSet;
        }
        public bool IsSingleShotSupported4()
        {
            // Camera can be null if not yet opened
            if (camera4 == null)
            {
                return false;
            }

            // Camera can be closed
            if (!camera4.IsOpen)
            {
                return false;
            }

            bool canSet = camera4.Parameters[PLCamera.AcquisitionMode].CanSetValue("SingleFrame");
            return canSet;
        }
        private void EnableButtons(bool canGrab, bool canStop)
        {
            toolStripButtonAutoInspStart.Enabled = canGrab;
            toolStripButtonOneShot.Enabled = canGrab && IsSingleShotSupported();
            toolStripButtonStop.Enabled = canStop;    
        }
        private void EnableButtons2(bool canGrab, bool canStop)
        {
            toolStripButtonAutoInspStart2.Enabled = canGrab;
            toolStripButtonOneShot2.Enabled = canGrab && IsSingleShotSupported2();
            toolStripButtonStop2.Enabled = canStop;
        }
        private void EnableButtons3(bool canGrab, bool canStop)
        {
            toolStripButtonAutoInspStart3.Enabled = canGrab;
            toolStripButtonOneShot3.Enabled = canGrab && IsSingleShotSupported3();
            toolStripButtonStop3.Enabled = canStop;
        }
        private void EnableButtons4(bool canGrab, bool canStop)
        {
            toolStripButtonAutoInspStart4.Enabled = canGrab;
            toolStripButtonOneShot4.Enabled = canGrab && IsSingleShotSupported4();
            toolStripButtonStop4.Enabled = canStop;
        }
        private void ShowException(Exception exception)
        {
            MessageBox.Show("Exception caught:\n" + exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void ShowException(Exception e, string additionalErrorMessage)
        {
            string more = "\n\nLast error message (may not belong to the exception):\n" + additionalErrorMessage;
            MessageBox.Show("Exception caught:\n" + e.Message + (additionalErrorMessage.Length > 0 ? more : ""), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void SaveDMCodeLog(string code)
        {
            if (!System.IO.Directory.Exists(Application.StartupPath + "\\InspectionLog\\" + DateTime.Now.ToString("yyyyMMdd")))
            {
                System.IO.Directory.CreateDirectory(Application.StartupPath + "\\InspectionLog\\" + DateTime.Now.ToString("yyyyMMdd"));
            }

            string strTmpCode1 = "";
            string strTmpCode2 = "";
            string strFront = "";
            string strEnd = "J0.0";
            string strTmp = "";
            strTmp = code.Replace("J0.0", "").Substring(7);
            strFront = code.Substring(0, 7);

            if (long.Parse(strTmp) % 2 == 0) //짝수
            {
                strTmpCode1 = strFront + (long.Parse(strTmp) - 1).ToString() + strEnd;
                strTmpCode2 = strFront + (long.Parse(strTmp)).ToString() + strEnd;
            }
            else // 홀수
            {
                strTmpCode1 = strFront + (long.Parse(strTmp)).ToString() + strEnd;
                strTmpCode2 = strFront + (long.Parse(strTmp) + 1).ToString() + strEnd;
            }

            string filename = Application.StartupPath + "\\InspectionLog\\" + DateTime.Now.ToString("yyyyMMdd") + "\\" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".txt";
            WritePrivateProfileString("CAM1", "DMCODE1", strTmpCode1, filename);
            WritePrivateProfileString("CAM1", "DMCODE2", strTmpCode2, filename);

        }
        private void SaveDMCodeLog2(string code)
        {
            if (!System.IO.Directory.Exists(Application.StartupPath + "\\InspectionLog2\\" + DateTime.Now.ToString("yyyyMMdd")))
            {
                System.IO.Directory.CreateDirectory(Application.StartupPath + "\\InspectionLog2\\" + DateTime.Now.ToString("yyyyMMdd"));
            }

            string strTmpCode1 = "";
            string strTmpCode2 = "";
            string strFront = "";
            string strEnd = "J0.0";
            string strTmp = "";
            strTmp = code.Replace("J0.0", "").Substring(7);
            strFront = code.Substring(0, 7);

            if (long.Parse(strTmp) % 2 == 0) //짝수
            {
                strTmpCode1 = strFront + (long.Parse(strTmp) - 1).ToString() + strEnd;
                strTmpCode2 = strFront + (long.Parse(strTmp)).ToString() + strEnd;
            }
            else // 홀수
            {
                strTmpCode1 = strFront + (long.Parse(strTmp)).ToString() + strEnd;
                strTmpCode2 = strFront + (long.Parse(strTmp) + 1).ToString() + strEnd;
            }

            string filename = Application.StartupPath + "\\InspectionLog2\\" + DateTime.Now.ToString("yyyyMMdd") + "\\" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".txt";

            WritePrivateProfileString("CAM2", "DMCODE1", strTmpCode1, filename);
            WritePrivateProfileString("CAM2", "DMCODE2", strTmpCode2, filename);
        }
        private void SaveLogImages(string status)
        {
            if (!System.IO.Directory.Exists(Application.StartupPath + "\\InspectionLog\\" + DateTime.Now.ToString("yyyyMMdd")))
            {
                System.IO.Directory.CreateDirectory(Application.StartupPath + "\\InspectionLog\\" + DateTime.Now.ToString("yyyyMMdd"));
            }

            if (status == "OK")
            {
                if (!System.IO.Directory.Exists(Application.StartupPath + "\\InspectionLog\\" + DateTime.Now.ToString("yyyyMMdd") + "\\OK"))
                {
                    System.IO.Directory.CreateDirectory(Application.StartupPath + "\\InspectionLog\\" + DateTime.Now.ToString("yyyyMMdd") + "\\OK");
                }
                pictureBox.Image.Save(Application.StartupPath + "\\InspectionLog\\" + DateTime.Now.ToString("yyyyMMdd") + "\\OK\\" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".bmp", ImageFormat.Jpeg);
            }
            else if (status == "NG")
            {
                if (!System.IO.Directory.Exists(Application.StartupPath + "\\InspectionLog\\" + DateTime.Now.ToString("yyyyMMdd") + "\\NG"))
                {
                    System.IO.Directory.CreateDirectory(Application.StartupPath + "\\InspectionLog\\" + DateTime.Now.ToString("yyyyMMdd") + "\\NG");
                }
                pictureBox.Image.Save(Application.StartupPath + "\\InspectionLog\\" + DateTime.Now.ToString("yyyyMMdd") + "\\NG\\" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".bmp", ImageFormat.Jpeg);
            }
            else
            {
                pictureBox.Image.Save(Application.StartupPath + "\\InspectionLog\\" + DateTime.Now.ToString("yyyyMMdd") + "\\" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".bmp", ImageFormat.Jpeg);
            }
        }
        private void SaveLogImages2(string status)
        {
            if (!System.IO.Directory.Exists(Application.StartupPath + "\\InspectionLog2\\" + DateTime.Now.ToString("yyyyMMdd")))
            {
                System.IO.Directory.CreateDirectory(Application.StartupPath + "\\InspectionLog2\\" + DateTime.Now.ToString("yyyyMMdd"));
            }

            if (status == "OK")
            {
                if (!System.IO.Directory.Exists(Application.StartupPath + "\\InspectionLog2\\" + DateTime.Now.ToString("yyyyMMdd") + "\\OK"))
                {
                    System.IO.Directory.CreateDirectory(Application.StartupPath + "\\InspectionLog2\\" + DateTime.Now.ToString("yyyyMMdd") + "\\OK");
                }
                pictureBox.Image.Save(Application.StartupPath + "\\InspectionLog2\\" + DateTime.Now.ToString("yyyyMMdd") + "\\OK\\" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".bmp", ImageFormat.Jpeg);
            }
            else if (status == "NG")
            {
                if (!System.IO.Directory.Exists(Application.StartupPath + "\\InspectionLog2\\" + DateTime.Now.ToString("yyyyMMdd") + "\\NG"))
                {
                    System.IO.Directory.CreateDirectory(Application.StartupPath + "\\InspectionLog2\\" + DateTime.Now.ToString("yyyyMMdd") + "\\NG");
                }
                pictureBox.Image.Save(Application.StartupPath + "\\InspectionLog2\\" + DateTime.Now.ToString("yyyyMMdd") + "\\NG\\" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".bmp", ImageFormat.Jpeg);
            }
            else
            {
                pictureBox.Image.Save(Application.StartupPath + "\\InspectionLog2\\" + DateTime.Now.ToString("yyyyMMdd") + "\\" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".bmp", ImageFormat.Jpeg);
            }
        }
        private void SaveExceptionLog(string message)
        {
            if (!System.IO.Directory.Exists(Application.StartupPath + "\\LOG"))
            {
                System.IO.Directory.CreateDirectory(Application.StartupPath + "\\LOG");
            }
            WritePrivateProfileString(DateTime.Now.ToString("yyyyMMdd HH:mm:ss"), "MESSAGE", message, Application.StartupPath + "\\LOG\\" + DateTime.Now.ToString("yyyyMMdd") + ".LOG");
        }
        #endregion

        #region Vision Calibration/Inspection/Result/Display
        private void Calibrate()
        {
            try
            {
                EWorldShape1.SetSensorSize(nResolutionWidth, nResolutionHeight);
                imgSrc.Load(Application.StartupPath + "\\FRAME_BUFFER\\ACQ.bmp");
                EWorldShape1.Process(imgSrc, true);

                for (int j = 0; j < gridCalibration.Rows.Count; j++)
                {
                    try
                    {
                        if (!gridCalibration.Rows[j].IsNewRow)
                        {
                            if (gridCalibration["gridCalibrationUse", j].Value.ToString() == "1")
                            {
                                EWorldShape1.AddLandmark(
                                    new EPoint(
                                        float.Parse(gridCalibration["gridCalibrationPixelX", j].Value.ToString().Trim()),
                                        float.Parse(gridCalibration["gridCalibrationPixelY", j].Value.ToString().Trim())),
                                    new EPoint(
                                        float.Parse(gridCalibration["gridCalibrationWorldX", j].Value.ToString().Trim()),
                                        float.Parse(gridCalibration["gridCalibrationWorldY", j].Value.ToString().Trim())));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        SaveExceptionLog(ex.StackTrace);
                    }
                }

                EWorldShape1.AutoCalibrateLandmarks(false);
            }
            catch (EException ex)
            {
                MessageBox.Show(ex.ToString());
                SaveExceptionLog(ex.StackTrace);
            }
        }
        private void Calibrate2()
        {
            try
            {
                EWorldShape2.SetSensorSize(nResolutionWidth2, nResolutionHeight2);
                imgSrc2.Load(Application.StartupPath + "\\FRAME_BUFFER2\\ACQ.bmp");
                EWorldShape2.Process(imgSrc2, true);

                for (int j = 0; j < gridCalibration2.Rows.Count; j++)
                {
                    try
                    {
                        if (!gridCalibration2.Rows[j].IsNewRow)
                        {
                            if (gridCalibration2["gridCalibrationUse2", j].Value.ToString() == "1")
                            {
                                EWorldShape2.AddLandmark(
                                    new EPoint(
                                        float.Parse(gridCalibration2["gridCalibrationPixelX2", j].Value.ToString().Trim()),
                                        float.Parse(gridCalibration2["gridCalibrationPixelY2", j].Value.ToString().Trim())),
                                    new EPoint(
                                        float.Parse(gridCalibration2["gridCalibrationWorldX2", j].Value.ToString().Trim()),
                                        float.Parse(gridCalibration2["gridCalibrationWorldY2", j].Value.ToString().Trim())));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        SaveExceptionLog(ex.StackTrace);
                    }
                }

                EWorldShape2.AutoCalibrateLandmarks(false);
            }
            catch (EException ex)
            {
                MessageBox.Show(ex.ToString());
                SaveExceptionLog(ex.StackTrace);
            }
        }
        private void Calibrate3()
        {
            try
            {
                EWorldShape3.SetSensorSize(nResolutionWidth3, nResolutionHeight3);
                EWorldShape3.Process(imgSrc3, true);

                for (int j = 0; j < gridCalibration3.Rows.Count; j++)
                {
                    try
                    {
                        if (!gridCalibration3.Rows[j].IsNewRow)
                        {
                            if (gridCalibration3["gridCalibrationUse", j].Value.ToString() == "1")
                            {
                                EWorldShape3.AddLandmark(
                                    new EPoint(
                                        float.Parse(gridCalibration3["gridCalibrationPixelX", j].Value.ToString().Trim()),
                                        float.Parse(gridCalibration3["gridCalibrationPixelY", j].Value.ToString().Trim())),
                                    new EPoint(
                                        float.Parse(gridCalibration3["gridCalibrationWorldX", j].Value.ToString().Trim()),
                                        float.Parse(gridCalibration3["gridCalibrationWorldY", j].Value.ToString().Trim())));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        SaveExceptionLog(ex.StackTrace);
                    }
                }

                EWorldShape3.AutoCalibrateLandmarks(false);
            }
            catch (EException ex)
            {
                MessageBox.Show(ex.ToString());
                SaveExceptionLog(ex.StackTrace);
            }
        }
        private void Calibrate4()
        {
            try
            {
                EWorldShape4.SetSensorSize(nResolutionWidth4, nResolutionHeight4);
                EWorldShape4.Process(imgSrc4, true);

                for (int j = 0; j < gridCalibration4.Rows.Count; j++)
                {
                    try
                    {
                        if (!gridCalibration4.Rows[j].IsNewRow)
                        {
                            if (gridCalibration4["gridCalibrationUse", j].Value.ToString() == "1")
                            {
                                EWorldShape4.AddLandmark(
                                    new EPoint(
                                        float.Parse(gridCalibration4["gridCalibrationPixelX", j].Value.ToString().Trim()),
                                        float.Parse(gridCalibration4["gridCalibrationPixelY", j].Value.ToString().Trim())),
                                    new EPoint(
                                        float.Parse(gridCalibration4["gridCalibrationWorldX", j].Value.ToString().Trim()),
                                        float.Parse(gridCalibration4["gridCalibrationWorldY", j].Value.ToString().Trim())));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        SaveExceptionLog(ex.StackTrace);
                    }
                }

                EWorldShape4.AutoCalibrateLandmarks(false);
            }
            catch (EException ex)
            {
                MessageBox.Show(ex.ToString());
                SaveExceptionLog(ex.StackTrace);
            }
        }

        private void PatternMatchingLearn()
        {
            //EMatcherFindPosition.Load(ofdMatchingFile.FileName);
            EImageBW8 imgTmp = new EImageBW8();
            if (ofdMatchingFile != null)
                imgTmp.Load(ofdMatchingFile.FileName);
            else
                imgTmp.Load(Application.StartupPath + "\\Calibration\\TYPE1_MATCH.bmp");
            EMatcherFindPosition.LearnPattern(imgTmp);
        }
        private void PatternMatchingLearn2()
        {
            //EMatcherFindPosition.Load(ofdMatchingFile.FileName);
            EImageBW8 imgTmp = new EImageBW8();
            if (ofdMatchingFile2 != null)
                imgTmp.Load(ofdMatchingFile2.FileName);
            else
                imgTmp.Load(Application.StartupPath + "\\Calibration\\TYPE1_MATCH.bmp");
            EMatcherFindPosition2.LearnPattern(imgTmp);
        }
        private void PatternMatchingLearn3()
        {
            //EMatcherFindPosition.Load(ofdMatchingFile.FileName);
            EImageBW8 imgTmp = new EImageBW8();
            if (ofdMatchingFile3 != null)
                imgTmp.Load(ofdMatchingFile3.FileName);
            else
                imgTmp.Load(Application.StartupPath + "\\Calibration\\TYPE1_MATCH.bmp");
            EMatcherFindPosition3.LearnPattern(imgTmp);
        }
        private void PatternMatchingLearn4()
        {
            //EMatcherFindPosition.Load(ofdMatchingFile.FileName);
            EImageBW8 imgTmp = new EImageBW8();
            if (ofdMatchingFile4 != null)
                imgTmp.Load(ofdMatchingFile4.FileName);
            else
                imgTmp.Load(Application.StartupPath + "\\Calibration\\TYPE1_MATCH.bmp");
            EMatcherFindPosition4.LearnPattern(imgTmp);
        }

        [HandleProcessCorruptedStateExceptions]
        private bool FindInitialPosition()
        {
            try
            {
                EMatcherFindPosition.MaxAngle = float.Parse("10.0");
                EMatcherFindPosition.MinAngle = float.Parse("10.0") * -1;
                EMatcherFindPosition.MaxPositions = 1;
                EMatcherFindPosition.Interpolate = true;
                EMatcherFindPosition.MaxScale = 1.2f;
                EMatcherFindPosition.MinScale = 0.8f;
                EMatcherFindPosition.MinScore = float.Parse("0.6");
                EMatcherFindPosition.ContrastMode = EMatchContrastMode.Normal;
                EMatcherFindPosition.CorrelationMode = ECorrelationMode.Normalized;

                try
                {
                    EMatcherFindPosition.Match(imgSrc);
                }
                catch (AccessViolationException ex)
                {
                    MessageBox.Show(ex.ToString());
                    SaveExceptionLog(ex.StackTrace);
                }

                return true;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                SaveExceptionLog(ex.StackTrace + "[" + ex.Source + "]" + "[매칭 에러]");
                return false;
            }
        }

        [HandleProcessCorruptedStateExceptions]
        private bool FindInitialPosition2()
        {
            try
            {
                EMatcherFindPosition2.MaxAngle = float.Parse("10.0");
                EMatcherFindPosition2.MinAngle = float.Parse("10.0") * -1;
                EMatcherFindPosition2.MaxPositions = 1;
                EMatcherFindPosition2.Interpolate = true;
                EMatcherFindPosition2.MaxScale = 1.2f;
                EMatcherFindPosition2.MinScale = 0.8f;
                EMatcherFindPosition2.MinScore = float.Parse("0.6");
                EMatcherFindPosition2.ContrastMode = EMatchContrastMode.Normal;
                EMatcherFindPosition2.CorrelationMode = ECorrelationMode.Normalized;

                try
                {
                    EMatcherFindPosition2.Match(imgSrc2);
                }
                catch (AccessViolationException ex)
                {
                    MessageBox.Show(ex.ToString());
                    SaveExceptionLog(ex.StackTrace);
                }

                return true;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                SaveExceptionLog(ex.StackTrace + "[" + ex.Source + "]" + "[매칭 에러]");
                return false;
            }
        }
        [HandleProcessCorruptedStateExceptions]
        private bool FindInitialPosition3()
        {
            try
            {
                EMatcherFindPosition3.MaxAngle = float.Parse("10.0");
                EMatcherFindPosition3.MinAngle = float.Parse("10.0") * -1;
                EMatcherFindPosition3.MaxPositions = 1;
                EMatcherFindPosition3.Interpolate = true;
                EMatcherFindPosition3.MaxScale = 1.03f;
                EMatcherFindPosition3.MinScale = 0.97f;
                EMatcherFindPosition3.MinScore = float.Parse("0.6");
                EMatcherFindPosition3.ContrastMode = EMatchContrastMode.Normal;
                EMatcherFindPosition3.CorrelationMode = ECorrelationMode.Normalized;

                try
                {
                    EMatcherFindPosition3.Match(imgSrc3);
                }
                catch (AccessViolationException ex)
                {
                    MessageBox.Show(ex.ToString());
                    SaveExceptionLog(ex.StackTrace);
                }

                return true;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                SaveExceptionLog(ex.StackTrace + "[" + ex.Source + "]" + "[매칭 에러]");
                return false;
            }
        }
        [HandleProcessCorruptedStateExceptions]
        private bool FindInitialPosition4()
        {
            try
            {
                EMatcherFindPosition4.MaxAngle = float.Parse("10.0");
                EMatcherFindPosition4.MinAngle = float.Parse("10.0") * -1;
                EMatcherFindPosition4.MaxPositions = 1;
                EMatcherFindPosition4.Interpolate = true;
                EMatcherFindPosition4.MaxScale = 1.03f;
                EMatcherFindPosition4.MinScale = 0.97f;
                EMatcherFindPosition4.MinScore = float.Parse("0.6");
                EMatcherFindPosition4.ContrastMode = EMatchContrastMode.Normal;
                EMatcherFindPosition4.CorrelationMode = ECorrelationMode.Normalized;

                try
                {
                    EMatcherFindPosition4.Match(imgSrc4);
                }
                catch (AccessViolationException ex)
                {
                    MessageBox.Show(ex.ToString());
                    SaveExceptionLog(ex.StackTrace);
                }

                return true;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                SaveExceptionLog(ex.StackTrace + "[" + ex.Source + "]" + "[매칭 에러]");
                return false;
            }
        }

        [HandleProcessCorruptedStateExceptions]
        private void DoInspection()
        {
            //MessageBox.Show("검사Procedure");
            swInspProc.Reset();
            swInspProc.Start();
            this.Cursor = Cursors.WaitCursor;

            bool bCurrentJudge = true;
            float fResultJudgeRatio = 100;

            Cursor.Current = Cursors.WaitCursor;
            
            try
            {
                UpdateDataGrid();
                
                if (System.IO.File.Exists(Application.StartupPath + "\\FRAME_BUFFER\\ACQ.bmp"))
                {
                    imgSrc.Load(Application.StartupPath + "\\FRAME_BUFFER\\ACQ.bmp");
                }
                else
                {
                    MessageBox.Show("버퍼에 이미지가 없습니다.");
                    throw new Exception("FRAME_BUFFER 폴더에 버퍼이미지[ACQ.BMP]가 없습니다. 카메라 연결 후 검사하고자 하는 대상물을 스캔하여 주세요.");
                }

                if (!FindInitialPosition())
                {
                    MessageBox.Show("원점 갱신에 실패하였습니다. 원점을 보정하여 주세요.");
                    return;
                }

                lblMatchingResult.Text = EMatcherFindPosition.NumPositions.ToString() + "/1";

                #region Match Inspection

                arrFrameShapes.Clear();
                arrToolResults.Clear();
                arrIsToolActivate.Clear();

                for (int i = 0; i < EMatcherFindPosition.NumPositions; i++)
                {
                    EFrameShape efs = new EFrameShape();

                    efs.Attach(EWorldShape1);
                    efs.Center = EWorldShape1.SensorToLocal(new EPoint(EMatcherFindPosition.GetPosition((uint)i).CenterX, EMatcherFindPosition.GetPosition((uint)i).CenterY));
                    efs.Angle = EMatcherFindPosition.GetPosition((uint)i).Angle * 1;
                    
                    lstResults.Items.Add(efs.CenterY.ToString("0.000") + ", " + efs.CenterX.ToString("0.000"));
                    //strMsgSCARA1 = "2,321.064,-503.605,227.472,1,0,0,221.064,-403.605,200.472,2,0,0\r";
                    //strMsgSCARA1 = "2," + efs.CenterY.ToString("0.000") + "," + efs.CenterX.ToString("0.000") + ",149.616,1,0,0,221.064,-403.605,149.616,2,0,0\r";
                    strMsgSCARA1 = "1," + (efs.CenterY + fScaraXOffset).ToString("0.000") + "," + (efs.CenterX + fScaraYOffset).ToString("0.000") + "," + (149.616 + fScaraZOffset).ToString("0.000") + ",1,0,0\r";
                    lstResults.Items.Add(strMsgSCARA1);

                    try
                    {
                        if (clientSCARA1 != null && clientSCARA1.Connected) clientSCARA1.Send(Encoding.ASCII.GetBytes(strMsgSCARA1));
                    }
                    catch (Exception ex)
                    {
                        ShowException(ex);
                    }

                    try
                    {
                        efs.Process(imgSrc, true);
                    }
                    catch (AccessViolationException avex)
                    {
                        SaveExceptionLog(avex.ToString());
                    }

                    //EMatrixCodeReader EMatrixCodeReader1 = new EMatrixCodeReader(); // EMatrixCodeReader instance
                    //EMatrixCode EMatrixCodeReader1Result = null; // EMatrixCode instance
                    //EROIBW8 EBW8Image1Roi1 = new EROIBW8();
                    //EBW8Image1Roi1.Attach(imgSrc);
                    //EBW8Image1Roi1.SetPlacement(
                    //    (int)EMatcherFindPosition.GetPosition((uint)i).CenterX + nDMCodeROI_X, (int)EMatcherFindPosition.GetPosition((uint)i).CenterY + nDMCodeROI_Y,
                    //    nDMCodeROI_WIDTH, nDMCodeROI_HEIGHT);

                    //try { EMatrixCodeReader1Result = EMatrixCodeReader1.Read(EBW8Image1Roi1); } catch { }
                    //arrToolResults.Add(EMatrixCodeReader1Result);

                    arrFrameShapes.Add(efs);
                }

                foreach (object obj in arrFrameShapes)
                {
                    ((EFrameShape)obj).Process(imgSrc, true);
                }
                #endregion

                EWorldShape1.Process(imgSrc, true);
                Redraw(pictureBox.CreateGraphics());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                SaveExceptionLog(ex.StackTrace + "[" + ex.Source + "]" + ex.Source);
            }
            
            swInspProc.Stop();
            swTotalProc.Stop();
            lblProcessingTime.Text = swInspProc.ElapsedMilliseconds.ToString();
            lblTotalTime.Text = swTotalProc.ElapsedMilliseconds.ToString();

            //Cursor.Current = Cursors.Cross;

            float scale = ((float)pictureBox.Height / (float)imgSrc.Height) * 1.00f;
            tstxtZoomRatio.Text = (scale * 100.00f).ToString("0.00");

            //#region Match Results with None Repeat
            //try
            //{
            //    for (int i = 0; i < arrToolResults.Count; i++)
            //    {
            //        if (arrToolResults[i] != null)
            //        {
            //            //gridResults.Rows.Add();
            //            //gridResults[0, i].Value = (i + 1).ToString();
            //            //gridResults[1, i].Value = ((EMatrixCode)arrToolResults[i]).DecodedString;
            //            //SaveDMCodeLog(((EMatrixCode)arrToolResults[i]).DecodedString);
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    SaveExceptionLog(ex.StackTrace + "[" + ex.Source + "]" + "[툴 프리셋 Fatal Error]");
            //}
            //#endregion

            this.Cursor = Cursors.Cross;
        }

        [HandleProcessCorruptedStateExceptions]
        private void DoInspection2()
        {
            //MessageBox.Show("검사Procedure");
            swInspProc2.Reset();
            swInspProc2.Start();
            this.Cursor = Cursors.WaitCursor;

            bool bCurrentJudge = true;
            float fResultJudgeRatio = 100;

            Cursor.Current = Cursors.WaitCursor;

            try
            {
                UpdateDataGrid2();

                if (System.IO.File.Exists(Application.StartupPath + "\\FRAME_BUFFER2\\ACQ.bmp"))
                {
                    imgSrc2.Load(Application.StartupPath + "\\FRAME_BUFFER2\\ACQ.bmp");
                }
                else
                {
                    MessageBox.Show("버퍼에 이미지가 없습니다.");
                    throw new Exception("FRAME_BUFFER2 폴더에 버퍼이미지[ACQ.BMP]가 없습니다. 카메라 연결 후 검사하고자 하는 대상물을 스캔하여 주세요.");
                }

                if (!FindInitialPosition2())
                {
                    MessageBox.Show("원점 갱신에 실패하였습니다. 원점을 보정하여 주세요.");
                    return;
                }

                lblMatchingResult2.Text = EMatcherFindPosition2.NumPositions.ToString() + "/1";

                #region Match Inspection

                arrFrameShapes2.Clear();
                arrToolResults2.Clear();
                arrIsToolActivate2.Clear();

                for (int i = 0; i < EMatcherFindPosition2.NumPositions; i++)
                {
                    EFrameShape efs = new EFrameShape();

                    efs.Attach(EWorldShape2);
                    efs.Center = EWorldShape2.SensorToLocal(new EPoint(EMatcherFindPosition2.GetPosition((uint)i).CenterX, EMatcherFindPosition2.GetPosition((uint)i).CenterY));
                    efs.Angle = EMatcherFindPosition2.GetPosition((uint)i).Angle * 1;

                    //lstResults.Items.Add(efs.CenterY.ToString("0.000") + ", " + efs.CenterX.ToString("0.000"));
                    ////strMsgSCARA1 = "2,321.064,-503.605,227.472,1,0,0,221.064,-403.605,200.472,2,0,0\r";
                    ////strMsgSCARA2 = "2,321.064,-503.605,149.616,1,0,0," + efs.CenterY.ToString("0.000") + "," + efs.CenterX.ToString("0.000") + ",149.616,2,0,0\r";
                    //strMsgSCARA2 = efs.CenterY.ToString("0.000") + "," + efs.CenterX.ToString("0.000") + ",149.616,2,0,0\r";
                    //lstResults.Items.Add(strMsgSCARA2);
                    //try
                    //{
                    //    //if (clientSCARA1 != null && clientSCARA1.Connected)
                    //    (Encoding.ASCII.GetBytes(strMsgSCARA1));
                    //    //if (clientSCARA2 != null && clientSCARA2.Connected) clientSCARA2.Send(Encoding.ASCII.GetBytes(strMsgSCARA2));
                    //}
                    //catch (Exception ex)
                    //{
                    //    ShowException(ex);
                    //}

                    try
                    {
                        efs.Process(imgSrc2, true);
                    }
                    catch (AccessViolationException avex)
                    {
                        SaveExceptionLog(avex.ToString());
                    }

                    //EMatrixCodeReader EMatrixCodeReader1 = new EMatrixCodeReader(); // EMatrixCodeReader instance
                    //EMatrixCode EMatrixCodeReader1Result = null; // EMatrixCode instance
                    //EROIBW8 EBW8Image1Roi1 = new EROIBW8();
                    //EBW8Image1Roi1.Attach(imgSrc2);
                    //EBW8Image1Roi1.SetPlacement(
                    //    (int)EMatcherFindPosition2.GetPosition((uint)i).CenterX + nDMCodeROI_X2, (int)EMatcherFindPosition2.GetPosition((uint)i).CenterY + nDMCodeROI_Y2,
                    //    nDMCodeROI_WIDTH2, nDMCodeROI_HEIGHT2);

                    //try { EMatrixCodeReader1Result = EMatrixCodeReader1.Read(EBW8Image1Roi1); } catch { }
                    //arrToolResults2.Add(EMatrixCodeReader1Result);

                    arrFrameShapes2.Add(efs);
                }

                foreach (object obj in arrFrameShapes2)
                {
                    ((EFrameShape)obj).Process(imgSrc2, true);
                }
                #endregion

                EWorldShape2.Process(imgSrc2, true);
                Redraw2(pictureBox2.CreateGraphics());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                SaveExceptionLog(ex.StackTrace + "[" + ex.Source + "]" + ex.Source);
            }

            swInspProc2.Stop();
            swTotalProc2.Stop();
            lblProcessingTime2.Text = swInspProc2.ElapsedMilliseconds.ToString();
            lblTotalTime2.Text = swTotalProc2.ElapsedMilliseconds.ToString();

            //Cursor.Current = Cursors.Cross;

            float scale = ((float)pictureBox2.Height / (float)imgSrc2.Height) * 1.00f;
            tstxtZoomRatio2.Text = (scale * 100.00f).ToString("0.00");

            //#region Match Results with None Repeat
            //try
            //{
            //    for (int i = 0; i < arrToolResults2.Count; i++)
            //    {
            //        if (arrToolResults2[i] != null)
            //        {
            //            //gridResults2.Rows.Add();
            //            //gridResults2[0, i].Value = (i + 1).ToString();
            //            //gridResults2[1, i].Value = ((EMatrixCode)arrToolResults2[i]).DecodedString;
            //            //SaveDMCodeLog2(((EMatrixCode)arrToolResults2[i]).DecodedString);
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    SaveExceptionLog(ex.StackTrace + "[" + ex.Source + "]" + "[툴 프리셋 Fatal Error]");
            //}
            //#endregion

            //try
            //{
            //    if (clientSCARA1 != null && clientSCARA1.Connected) clientSCARA1.Send(Encoding.ASCII.GetBytes(strMsgSCARA1));
            //    if (clientSCARA2 != null && clientSCARA2.Connected) clientSCARA2.Send(Encoding.ASCII.GetBytes(strMsgSCARA2));
            //}
            //catch (Exception ex)
            //{
            //    ShowException(ex);
            //}

            this.Cursor = Cursors.Cross;
        }

        [HandleProcessCorruptedStateExceptions]
        private void DoInspection3()
        {
            //MessageBox.Show("검사Procedure");
            swInspProc3.Reset();
            swInspProc3.Start();
            this.Cursor = Cursors.WaitCursor;

            bool bCurrentJudge = true;
            float fResultJudgeRatio = 100;

            Cursor.Current = Cursors.WaitCursor;

            try
            {
                UpdateDataGrid3();

                if (System.IO.File.Exists(Application.StartupPath + "\\FRAME_BUFFER3\\ACQ.bmp"))
                {
                    imgSrc3.Load(Application.StartupPath + "\\FRAME_BUFFER3\\ACQ.bmp");
                }
                else
                {
                    MessageBox.Show("버퍼에 이미지가 없습니다.");
                    throw new Exception("FRAME_BUFFER3 폴더에 버퍼이미지[ACQ.BMP]가 없습니다. 카메라 연결 후 검사하고자 하는 대상물을 스캔하여 주세요.");
                }

                if (!FindInitialPosition3())
                {
                    MessageBox.Show("원점 갱신에 실패하였습니다. 원점을 보정하여 주세요.");
                    return;
                }

                lblMatchingResult3.Text = EMatcherFindPosition3.NumPositions.ToString() + "/1";

                #region Match Inspection

                arrFrameShapes3.Clear();
                arrToolResults3.Clear();
                arrIsToolActivate3.Clear();

                for (int i = 0; i < EMatcherFindPosition3.NumPositions; i++)
                {
                    EFrameShape efs = new EFrameShape();

                    efs.Attach(EWorldShape3);
                    efs.Center = EWorldShape3.SensorToLocal(new EPoint(EMatcherFindPosition3.GetPosition((uint)i).CenterX, EMatcherFindPosition3.GetPosition((uint)i).CenterY));
                    efs.Angle = EMatcherFindPosition3.GetPosition((uint)i).Angle * 1;

                    try
                    {
                        efs.Process(imgSrc3, true);
                    }
                    catch (AccessViolationException avex)
                    {
                        SaveExceptionLog(avex.ToString());
                    }

                    EMatrixCodeReader EMatrixCodeReader1 = new EMatrixCodeReader(); // EMatrixCodeReader instance
                    EMatrixCode EMatrixCodeReader1Result = null; // EMatrixCode instance
                    EROIBW8 EBW8Image1Roi1 = new EROIBW8();
                    EBW8Image1Roi1.Attach(imgSrc3);
                    EBW8Image1Roi1.SetPlacement(
                        (int)EMatcherFindPosition3.GetPosition((uint)i).CenterX + nDMCodeROI_X3, (int)EMatcherFindPosition3.GetPosition((uint)i).CenterY + nDMCodeROI_Y3,
                        nDMCodeROI_WIDTH3, nDMCodeROI_HEIGHT3);

                    try { EMatrixCodeReader1Result = EMatrixCodeReader1.Read(EBW8Image1Roi1); } catch { }
                    arrToolResults3.Add(EMatrixCodeReader1Result);

                    arrFrameShapes3.Add(efs);
                }

                foreach (object obj in arrFrameShapes3)
                {
                    ((EFrameShape)obj).Process(imgSrc3, true);
                }
                #endregion

                //EWorldShape1.Process(imgSrc, true);
                Redraw3(pictureBox3.CreateGraphics());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                SaveExceptionLog(ex.StackTrace + "[" + ex.Source + "]" + ex.Source);
            }

            swInspProc3.Stop();
            swTotalProc3.Stop();
            lblProcessingTime3.Text = swInspProc3.ElapsedMilliseconds.ToString();
            lblTotalTime3.Text = swTotalProc3.ElapsedMilliseconds.ToString();

            //Cursor.Current = Cursors.Cross;

            float scale = ((float)pictureBox3.Height / (float)imgSrc3.Height) * 1.00f;
            tstxtZoomRatio3.Text = (scale * 100.00f).ToString("0.00");

            #region Match Results with None Repeat
            try
            {
                for (int i = 0; i < arrToolResults3.Count; i++)
                {
                    if (arrToolResults3[i] != null)
                    {
                        //gridResults2.Rows.Add();
                        //gridResults2[0, i].Value = (i + 1).ToString();
                        //gridResults2[1, i].Value = ((EMatrixCode)arrToolResults2[i]).DecodedString;
                        //SaveDMCodeLog2(((EMatrixCode)arrToolResults2[i]).DecodedString);
                    }
                }
            }
            catch (Exception ex)
            {
                SaveExceptionLog(ex.StackTrace + "[" + ex.Source + "]" + "[툴 프리셋 Fatal Error]");
            }
            #endregion

            this.Cursor = Cursors.Cross;
        }
        [HandleProcessCorruptedStateExceptions]
        private void DoInspection4()
        {
            //MessageBox.Show("검사Procedure");
            swInspProc4.Reset();
            swInspProc4.Start();
            this.Cursor = Cursors.WaitCursor;

            bool bCurrentJudge = true;
            float fResultJudgeRatio = 100;

            Cursor.Current = Cursors.WaitCursor;

            try
            {
                UpdateDataGrid4();

                if (System.IO.File.Exists(Application.StartupPath + "\\FRAME_BUFFER4\\ACQ.bmp"))
                {
                    imgSrc4.Load(Application.StartupPath + "\\FRAME_BUFFER4\\ACQ.bmp");
                }
                else
                {
                    MessageBox.Show("버퍼에 이미지가 없습니다.");
                    throw new Exception("FRAME_BUFFER4 폴더에 버퍼이미지[ACQ.BMP]가 없습니다. 카메라 연결 후 검사하고자 하는 대상물을 스캔하여 주세요.");
                }

                if (!FindInitialPosition4())
                {
                    MessageBox.Show("원점 갱신에 실패하였습니다. 원점을 보정하여 주세요.");
                    return;
                }

                lblMatchingResult4.Text = EMatcherFindPosition4.NumPositions.ToString() + "/1";

                #region Match Inspection

                arrFrameShapes4.Clear();
                arrToolResults4.Clear();
                arrIsToolActivate4.Clear();

                for (int i = 0; i < EMatcherFindPosition4.NumPositions; i++)
                {
                    EFrameShape efs = new EFrameShape();

                    efs.Attach(EWorldShape4);
                    efs.Center = EWorldShape4.SensorToLocal(new EPoint(EMatcherFindPosition4.GetPosition((uint)i).CenterX, EMatcherFindPosition4.GetPosition((uint)i).CenterY));
                    efs.Angle = EMatcherFindPosition4.GetPosition((uint)i).Angle * 1;

                    try
                    {
                        efs.Process(imgSrc4, true);
                    }
                    catch (AccessViolationException avex)
                    {
                        SaveExceptionLog(avex.ToString());
                    }

                    EMatrixCodeReader EMatrixCodeReader1 = new EMatrixCodeReader(); // EMatrixCodeReader instance
                    EMatrixCode EMatrixCodeReader1Result = null; // EMatrixCode instance
                    EROIBW8 EBW8Image1Roi1 = new EROIBW8();
                    EBW8Image1Roi1.Attach(imgSrc4);
                    EBW8Image1Roi1.SetPlacement(
                        (int)EMatcherFindPosition4.GetPosition((uint)i).CenterX + nDMCodeROI_X4, (int)EMatcherFindPosition4.GetPosition((uint)i).CenterY + nDMCodeROI_Y4,
                        nDMCodeROI_WIDTH4, nDMCodeROI_HEIGHT4);

                    try { EMatrixCodeReader1Result = EMatrixCodeReader1.Read(EBW8Image1Roi1); } catch { }
                    arrToolResults4.Add(EMatrixCodeReader1Result);

                    arrFrameShapes4.Add(efs);
                }

                foreach (object obj in arrFrameShapes4)
                {
                    ((EFrameShape)obj).Process(imgSrc4, true);
                }
                #endregion

                //EWorldShape1.Process(imgSrc, true);
                Redraw4(pictureBox4.CreateGraphics());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                SaveExceptionLog(ex.StackTrace + "[" + ex.Source + "]" + ex.Source);
            }

            swInspProc4.Stop();
            swTotalProc4.Stop();
            lblProcessingTime4.Text = swInspProc4.ElapsedMilliseconds.ToString();
            lblTotalTime4.Text = swTotalProc4.ElapsedMilliseconds.ToString();

            //Cursor.Current = Cursors.Cross;

            float scale = ((float)pictureBox4.Height / (float)imgSrc4.Height) * 1.00f;
            tstxtZoomRatio4.Text = (scale * 100.00f).ToString("0.00");

            #region Match Results with None Repeat
            try
            {
                for (int i = 0; i < arrToolResults4.Count; i++)
                {
                    if (arrToolResults4[i] != null)
                    {
                        //gridResults2.Rows.Add();
                        //gridResults2[0, i].Value = (i + 1).ToString();
                        //gridResults2[1, i].Value = ((EMatrixCode)arrToolResults2[i]).DecodedString;
                        //SaveDMCodeLog2(((EMatrixCode)arrToolResults2[i]).DecodedString);
                    }
                }
            }
            catch (Exception ex)
            {
                SaveExceptionLog(ex.StackTrace + "[" + ex.Source + "]" + "[툴 프리셋 Fatal Error]");
            }
            #endregion

            this.Cursor = Cursors.Cross;
        }

        private void UpdateDataGrid()
        {
        }
        private void UpdateDataGrid2()
        {
        }
        private void UpdateDataGrid3()
        {
        }
        private void UpdateDataGrid4()
        {
        }

        private void Redraw(Graphics g)
        {
            try
            {
                if (imgSrc.IsVoid)
                {
                    // If image is empty, exit
                    return;
                }

                roiSrc.Attach(imgSrc);

                float scale = ((float)pictureBox.Height / (float)imgSrc.Height) * 1.00f;
                float scaleX = ((float)pictureBox.Width / (float)imgSrc.Width) * 1.00f;
                int nTmpPicWidth = pictureBox.Width;

                g.Clear(Color.Black);
                
                imgSrc.Draw(g, scale);
                pictureBox.Width = (int)(imgSrc.Width * scale);
                //EPointGauge1.SetZoom(scale);
                //EPointGauge1.Draw(g, EDrawingMode.Actual);
                
                EFrameShape1.SetZoom(scale);
                
                EFrameShape1.Draw(g, EDrawingMode.Actual);

                if (arrToolResults.Count > 0)
                {
                    for (int i = 0; i < arrToolResults.Count; i++)
                    {
                        if (arrToolResults[i] != null)
                        {
                            if (arrToolResults[i].GetType().Equals(typeof(EMatrixCode)))
                            {
                                ((EMatrixCode)arrToolResults[i]).Draw(g, scaleX);
                            }
                        }
                    }
                }

                EMatcherFindPosition.DrawPositions(g, true, scale, scale);
                // Draw the ROI frame
                roiSrc.DrawFrame(g, true);

                pictureBox.Location =
                    new Point((panel1.Width / 2) - ((int)(((float)imgSrc.Width * scale) / 2)) + 6,
                        pictureBox.Location.Y
                            //picInspection.Location.Y + ((nTmpPicHeight / 2) - ((int)(((float)imgSrc.Height * scale) / 2)))
                            );

                tstxtZoomRatio.Text = (scale * 100.00f).ToString("0.00");
            }
            catch (EException exc)
            {
                if (exc.Error != EError.LicenseMissing)
                {
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                SaveExceptionLog(exc.ToString());
            }
        }
        private void Redraw2(Graphics g)
        {
            try
            {
                if (imgSrc2.IsVoid)
                {
                    // If image is empty, exit
                    return;
                }

                roiSrc2.Attach(imgSrc2);

                float scale = ((float)pictureBox2.Height / (float)imgSrc2.Height) * 1.00f;
                float scaleX = ((float)pictureBox2.Width / (float)imgSrc2.Width) * 1.00f;
                int nTmpPicWidth = pictureBox2.Width;

                g.Clear(Color.Black);

                imgSrc2.Draw(g, scale);
                pictureBox2.Width = (int)(imgSrc2.Width * scale);
                //EPointGauge1.SetZoom(scale);
                //EPointGauge1.Draw(g, EDrawingMode.Actual);

                EFrameShape2.SetZoom(scale);

                EFrameShape2.Draw(g, EDrawingMode.Actual);

                if (arrToolResults2.Count > 0)
                {
                    for (int i = 0; i < arrToolResults2.Count; i++)
                    {
                        if (arrToolResults2[i] != null)
                        {
                            if (arrToolResults2[i].GetType().Equals(typeof(EMatrixCode)))
                            {
                                ((EMatrixCode)arrToolResults2[i]).Draw(g, scaleX);
                            }
                        }
                    }
                }

                EMatcherFindPosition2.DrawPositions(g, true, scale, scale);
                // Draw the ROI frame
                roiSrc2.DrawFrame(g, true);

                pictureBox.Location =
                    new Point((panel1.Width / 2) - ((int)(((float)imgSrc.Width * scale) / 2)) + 6,
                        pictureBox.Location.Y
                            //picInspection.Location.Y + ((nTmpPicHeight / 2) - ((int)(((float)imgSrc.Height * scale) / 2)))
                            );

                tstxtZoomRatio.Text = (scale * 100.00f).ToString("0.00");
            }
            catch (EException exc)
            {
                if (exc.Error != EError.LicenseMissing)
                {
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                SaveExceptionLog(exc.ToString());
            }
        }
        private void Redraw3(Graphics g)
        {
            try
            {
                if (imgSrc3.IsVoid)
                {
                    // If image is empty, exit
                    return;
                }

                roiSrc3.Attach(imgSrc3);

                float scale = ((float)pictureBox3.Height / (float)imgSrc3.Height) * 1.00f;
                float scaleX = ((float)pictureBox3.Width / (float)imgSrc3.Width) * 1.00f;
                int nTmpPicWidth = pictureBox3.Width;

                g.Clear(Color.Black);

                imgSrc3.Draw(g, scale);
                pictureBox3.Width = (int)(imgSrc3.Width * scale);
                //EPointGauge1.SetZoom(scale);
                //EPointGauge1.Draw(g, EDrawingMode.Actual);

                EFrameShape3.SetZoom(scale);

                EFrameShape3.Draw(g, EDrawingMode.Actual);

                if (arrToolResults3.Count > 0)
                {
                    for (int i = 0; i < arrToolResults3.Count; i++)
                    {
                        if (arrToolResults3[i] != null)
                        {
                            if (arrToolResults3[i].GetType().Equals(typeof(EMatrixCode)))
                            {
                                ((EMatrixCode)arrToolResults3[i]).Draw(g, scaleX);
                            }
                        }
                    }
                }

                EMatcherFindPosition3.DrawPositions(g, true, scale, scale);
                // Draw the ROI frame
                roiSrc3.DrawFrame(g, true);

                //pictureBox.Location =
                //    new Point((panel1.Width / 2) - ((int)(((float)imgSrc.Width * scale) / 2)) + 6,
                //        pictureBox.Location.Y
                //            //picInspection.Location.Y + ((nTmpPicHeight / 2) - ((int)(((float)imgSrc.Height * scale) / 2)))
                //            );

                //tstxtZoomRatio.Text = (scale * 100.00f).ToString("0.00");
            }
            catch (EException exc)
            {
                if (exc.Error != EError.LicenseMissing)
                {
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                SaveExceptionLog(exc.ToString());
            }
        }
        private void Redraw4(Graphics g)
        {
            try
            {
                if (imgSrc4.IsVoid)
                {
                    // If image is empty, exit
                    return;
                }

                roiSrc4.Attach(imgSrc4);

                float scale = ((float)pictureBox4.Height / (float)imgSrc4.Height) * 1.00f;
                float scaleX = ((float)pictureBox4.Width / (float)imgSrc4.Width) * 1.00f;
                int nTmpPicWidth = pictureBox4.Width;

                g.Clear(Color.Black);

                imgSrc4.Draw(g, scale);
                pictureBox4.Width = (int)(imgSrc4.Width * scale);
                //EPointGauge1.SetZoom(scale);
                //EPointGauge1.Draw(g, EDrawingMode.Actual);

                EFrameShape4.SetZoom(scale);

                EFrameShape4.Draw(g, EDrawingMode.Actual);

                if (arrToolResults4.Count > 0)
                {
                    for (int i = 0; i < arrToolResults4.Count; i++)
                    {
                        if (arrToolResults4[i] != null)
                        {
                            if (arrToolResults4[i].GetType().Equals(typeof(EMatrixCode)))
                            {
                                ((EMatrixCode)arrToolResults4[i]).Draw(g, scaleX);
                            }
                        }
                    }
                }

                EMatcherFindPosition4.DrawPositions(g, true, scale, scale);
                // Draw the ROI frame
                roiSrc4.DrawFrame(g, true);

                //pictureBox.Location =
                //    new Point((panel1.Width / 2) - ((int)(((float)imgSrc.Width * scale) / 2)) + 6,
                //        pictureBox.Location.Y
                //            //picInspection.Location.Y + ((nTmpPicHeight / 2) - ((int)(((float)imgSrc.Height * scale) / 2)))
                //            );

                //tstxtZoomRatio.Text = (scale * 100.00f).ToString("0.00");
            }
            catch (EException exc)
            {
                if (exc.Error != EError.LicenseMissing)
                {
                    MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                SaveExceptionLog(exc.ToString());
            }
        }
        #endregion

        #region Pylon Support Functions
        private void Stop()
        {
            // Stop the grabbing.
            try
            {
                camera.StreamGrabber.Stop();
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }
        private void OneShot()
        {
            try
            {
                // Starts the grabbing of one image.
                //Configuration.AcquireSingleFrame(camera, null);
                camera.StreamGrabber.Start(1, GrabStrategy.OneByOne, GrabLoop.ProvidedByStreamGrabber);
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }
        private void ContinuousShot()
        {
            try
            {
                // Start the grabbing of images until grabbing is stopped.
                //Configuration.AcquireContinuous(camera, null);
                camera.StreamGrabber.Start(GrabStrategy.OneByOne, GrabLoop.ProvidedByStreamGrabber);
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }
        private void Stop2()
        {
            // Stop the grabbing.
            try
            {
                camera2.StreamGrabber.Stop();
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }
        private void OneShot2()
        {
            try
            {
                // Starts the grabbing of one image.
                //Configuration.AcquireSingleFrame(camera, null);
                camera2.StreamGrabber.Start(1, GrabStrategy.OneByOne, GrabLoop.ProvidedByStreamGrabber);
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }
        private void ContinuousShot2()
        {
            try
            {
                // Start the grabbing of images until grabbing is stopped.
                //Configuration.AcquireContinuous(camera, null);
                camera2.StreamGrabber.Start(GrabStrategy.OneByOne, GrabLoop.ProvidedByStreamGrabber);
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }
        private void Stop3()
        {
            // Stop the grabbing.
            try
            {
                camera3.StreamGrabber.Stop();
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }
        private void OneShot3()
        {
            try
            {
                // Starts the grabbing of one image.
                //Configuration.AcquireSingleFrame(camera, null);
                camera3.StreamGrabber.Start(1, GrabStrategy.OneByOne, GrabLoop.ProvidedByStreamGrabber);
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }
        private void ContinuousShot3()
        {
            try
            {
                // Start the grabbing of images until grabbing is stopped.
                //Configuration.AcquireContinuous(camera, null);
                camera3.StreamGrabber.Start(GrabStrategy.OneByOne, GrabLoop.ProvidedByStreamGrabber);
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }
        private void Stop4()
        {
            // Stop the grabbing.
            try
            {
                camera4.StreamGrabber.Stop();
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }
        private void OneShot4()
        {
            try
            {
                // Starts the grabbing of one image.
                //Configuration.AcquireSingleFrame(camera, null);
                camera4.StreamGrabber.Start(1, GrabStrategy.OneByOne, GrabLoop.ProvidedByStreamGrabber);
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }
        private void ContinuousShot4()
        {
            try
            {
                // Start the grabbing of images until grabbing is stopped.
                //Configuration.AcquireContinuous(camera, null);
                camera4.StreamGrabber.Start(GrabStrategy.OneByOne, GrabLoop.ProvidedByStreamGrabber);
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
        }
        #endregion

        #region Pylon Callback Functions
        private void OnConnectionLost(Object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<EventArgs>(OnConnectionLost), sender, e);
                return;
            }

            // Close the camera object.
            DestroyCamera();
        }
        private void OnCameraOpened(Object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<EventArgs>(OnCameraOpened), sender, e);
                return;
            }

            try
            {
                camera.Parameters.Load(Application.StartupPath + "\\camera1_profile.pfs", ParameterPath.CameraDevice);
            }
            catch (Exception ex)
            {
                MessageBox.Show("카메라1 프로파일을 로드하는 중 에러가 발생하였습니다. \r\n" + ex.ToString());
            }

            // The image provider is ready to grab. Enable the grab buttons.
            EnableButtons(true, false);
        }
        private void OnCameraClosed(Object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<EventArgs>(OnCameraClosed), sender, e);
                return;
            }

            // The camera connection is closed. Disable all buttons.
            EnableButtons(false, false);
        }
        private void OnGrabStarted(Object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<EventArgs>(OnGrabStarted), sender, e);
                return;
            }

            // Reset the stopwatch used to reduce the amount of displayed images. The camera may acquire images faster than the images can be displayed.

            stopWatch.Reset();

            // The camera is grabbing. Disable the grab buttons. Enable the stop button.
            EnableButtons(false, true);
        }
        private void OnImageGrabbed(Object sender, ImageGrabbedEventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper GUI thread.
                // The grab result will be disposed after the event call. Clone the event arguments for marshaling to the GUI thread.
                BeginInvoke(new EventHandler<ImageGrabbedEventArgs>(OnImageGrabbed), sender, e.Clone());
                return;
            }

            try
            {
                // Acquire the image from the camera. Only show the latest image. The camera may acquire images faster than the images can be displayed.

                // Get the grab result.
                IGrabResult grabResult = e.GrabResult;

                // Check if the image can be displayed.
                if (grabResult.IsValid)
                {
                    // Reduce the number of displayed images to a reasonable amount if the camera is acquiring images very fast.
                    if (!stopWatch.IsRunning || stopWatch.ElapsedMilliseconds > 33)
                    {
                        stopWatch.Restart();

                        Bitmap bitmap = new Bitmap(grabResult.Width, grabResult.Height, PixelFormat.Format32bppRgb);
                        // Lock the bits of the bitmap.
                        BitmapData bmpData = bitmap.LockBits(new Rectangle(0, 0, bitmap.Width, bitmap.Height), ImageLockMode.ReadWrite, bitmap.PixelFormat);
                        // Place the pointer to the buffer of the bitmap.
                        //converter.OutputPixelFormat = PixelType.BGRA8packed;
                        IntPtr ptrBmp = bmpData.Scan0;
                        //converter.Convert(ptrBmp, bmpData.Stride * bitmap.Height, grabResult);
                        bitmap.UnlockBits(bmpData);

                        // Assign a temporary variable to dispose the bitmap after assigning the new bitmap to the display control.
                        Bitmap bitmapOld = pictureBox.Image as Bitmap;
                        // Provide the display control with the new bitmap. This action automatically updates the display.
                        pictureBox.Image = bitmap;
                        if (bitmapOld != null)
                        {
                            // Dispose the bitmap.
                            bitmapOld.Dispose();
                        }
                        n_FrameCount++;
                        lblFrameCount.Text = n_FrameCount.ToString();
                        pictureBox.Image.Save(Application.StartupPath.ToString() + "\\FRAME_BUFFER\\ACQ.BMP");
                        DoInspection();
                    }
                }
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
            finally
            {
                // Dispose the grab result if needed for returning it to the grab loop.
                e.DisposeGrabResultIfClone();
            }
        }
        private void OnGrabStopped(Object sender, GrabStopEventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<GrabStopEventArgs>(OnGrabStopped), sender, e);
                return;
            }

            // Reset the stopwatch.
            stopWatch.Reset();

            // The camera stopped grabbing. Enable the grab buttons. Disable the stop button.
            EnableButtons(true, false);

            // If the grabbed stop due to an error, display the error message.
            if (e.Reason != GrabStopReason.UserRequest)
            {
                MessageBox.Show("A grab error occured:\n" + e.ErrorMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OnConnectionLost2(Object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<EventArgs>(OnConnectionLost2), sender, e);
                return;
            }

            // Close the camera object.
            DestroyCamera();
        }
        private void OnCameraOpened2(Object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<EventArgs>(OnCameraOpened2), sender, e);
                return;
            }

            try
            {
                camera2.Parameters.Load(Application.StartupPath + "\\camera2_profile.pfs", ParameterPath.CameraDevice);
            }
            catch (Exception ex)
            {
                MessageBox.Show("카메라2 프로파일을 로드하는 중 에러가 발생하였습니다. \r\n" + ex.ToString());
            }

            // The image provider is ready to grab. Enable the grab buttons.
            EnableButtons2(true, false);
        }
        private void OnCameraClosed2(Object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<EventArgs>(OnCameraClosed2), sender, e);
                return;
            }

            // The camera connection is closed. Disable all buttons.
            EnableButtons2(false, false);
        }
        private void OnGrabStarted2(Object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<EventArgs>(OnGrabStarted2), sender, e);
                return;
            }

            // Reset the stopwatch used to reduce the amount of displayed images. The camera may acquire images faster than the images can be displayed.

            stopWatch2.Reset();

            // The camera is grabbing. Disable the grab buttons. Enable the stop button.
            EnableButtons2(false, true);
        }
        private void OnImageGrabbed2(Object sender, ImageGrabbedEventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper GUI thread.
                // The grab result will be disposed after the event call. Clone the event arguments for marshaling to the GUI thread.
                BeginInvoke(new EventHandler<ImageGrabbedEventArgs>(OnImageGrabbed2), sender, e.Clone());
                return;
            }

            try
            {
                // Acquire the image from the camera. Only show the latest image. The camera may acquire images faster than the images can be displayed.

                // Get the grab result.
                IGrabResult grabResult = e.GrabResult;

                // Check if the image can be displayed.
                if (grabResult.IsValid)
                {
                    // Reduce the number of displayed images to a reasonable amount if the camera is acquiring images very fast.
                    if (!stopWatch2.IsRunning || stopWatch2.ElapsedMilliseconds > 33)
                    {
                        stopWatch2.Restart();

                        Bitmap bitmap = new Bitmap(grabResult.Width, grabResult.Height, PixelFormat.Format32bppRgb);
                        // Lock the bits of the bitmap.
                        BitmapData bmpData = bitmap.LockBits(new Rectangle(0, 0, bitmap.Width, bitmap.Height), ImageLockMode.ReadWrite, bitmap.PixelFormat);
                        // Place the pointer to the buffer of the bitmap.
                        converter2.OutputPixelFormat = PixelType.BGRA8packed;
                        IntPtr ptrBmp = bmpData.Scan0;
                        converter2.Convert(ptrBmp, bmpData.Stride * bitmap.Height, grabResult);
                        bitmap.UnlockBits(bmpData);

                        // Assign a temporary variable to dispose the bitmap after assigning the new bitmap to the display control.
                        Bitmap bitmapOld = pictureBox2.Image as Bitmap;
                        // Provide the display control with the new bitmap. This action automatically updates the display.
                        pictureBox2.Image = bitmap;
                        if (bitmapOld != null)
                        {
                            // Dispose the bitmap.
                            bitmapOld.Dispose();
                        }
                        n_FrameCount2++;
                        lblFrameCount2.Text = n_FrameCount2.ToString();
                        pictureBox2.Image.Save(Application.StartupPath.ToString() + "\\FRAME_BUFFER2\\ACQ.BMP");
                        DoInspection2();
                    }
                }
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
            finally
            {
                // Dispose the grab result if needed for returning it to the grab loop.
                e.DisposeGrabResultIfClone();
            }
        }
        private void OnGrabStopped2(Object sender, GrabStopEventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<GrabStopEventArgs>(OnGrabStopped2), sender, e);
                return;
            }

            // Reset the stopwatch.
            stopWatch2.Reset();

            // The camera stopped grabbing. Enable the grab buttons. Disable the stop button.
            EnableButtons2(true, false);

            // If the grabbed stop due to an error, display the error message.
            if (e.Reason != GrabStopReason.UserRequest)
            {
                MessageBox.Show("A grab error occured:\n" + e.ErrorMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OnConnectionLost3(Object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<EventArgs>(OnConnectionLost3), sender, e);
                return;
            }

            // Close the camera object.
            DestroyCamera();
        }
        private void OnCameraOpened3(Object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<EventArgs>(OnCameraOpened3), sender, e);
                return;
            }

            try
            {
                camera3.Parameters.Load(Application.StartupPath + "\\camera3_profile.pfs", ParameterPath.CameraDevice);
            }
            catch (Exception ex)
            {
                MessageBox.Show("카메라3 프로파일을 로드하는 중 에러가 발생하였습니다. \r\n" + ex.ToString());
            }

            // The image provider is ready to grab. Enable the grab buttons.
            EnableButtons3(true, false);
        }
        private void OnCameraClosed3(Object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<EventArgs>(OnCameraClosed3), sender, e);
                return;
            }

            // The camera connection is closed. Disable all buttons.
            EnableButtons3(false, false);
        }
        private void OnGrabStarted3(Object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<EventArgs>(OnGrabStarted3), sender, e);
                return;
            }

            // Reset the stopwatch used to reduce the amount of displayed images. The camera may acquire images faster than the images can be displayed.

            stopWatch3.Reset();

            // The camera is grabbing. Disable the grab buttons. Enable the stop button.
            EnableButtons3(false, true);
        }
        private void OnImageGrabbed3(Object sender, ImageGrabbedEventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper GUI thread.
                // The grab result will be disposed after the event call. Clone the event arguments for marshaling to the GUI thread.
                BeginInvoke(new EventHandler<ImageGrabbedEventArgs>(OnImageGrabbed3), sender, e.Clone());
                return;
            }

            try
            {
                // Acquire the image from the camera. Only show the latest image. The camera may acquire images faster than the images can be displayed.

                // Get the grab result.
                IGrabResult grabResult = e.GrabResult;

                // Check if the image can be displayed.
                if (grabResult.IsValid)
                {
                    // Reduce the number of displayed images to a reasonable amount if the camera is acquiring images very fast.
                    if (!stopWatch3.IsRunning || stopWatch3.ElapsedMilliseconds > 33)
                    {
                        stopWatch3.Restart();

                        Bitmap bitmap = new Bitmap(grabResult.Width, grabResult.Height, PixelFormat.Format32bppRgb);
                        // Lock the bits of the bitmap.
                        BitmapData bmpData = bitmap.LockBits(new Rectangle(0, 0, bitmap.Width, bitmap.Height), ImageLockMode.ReadWrite, bitmap.PixelFormat);
                        // Place the pointer to the buffer of the bitmap.
                        converter3.OutputPixelFormat = PixelType.BGRA8packed;
                        IntPtr ptrBmp = bmpData.Scan0;
                        converter3.Convert(ptrBmp, bmpData.Stride * bitmap.Height, grabResult);
                        bitmap.UnlockBits(bmpData);

                        // Assign a temporary variable to dispose the bitmap after assigning the new bitmap to the display control.
                        Bitmap bitmapOld = pictureBox3.Image as Bitmap;
                        // Provide the display control with the new bitmap. This action automatically updates the display.
                        pictureBox3.Image = bitmap;
                        if (bitmapOld != null)
                        {
                            // Dispose the bitmap.
                            bitmapOld.Dispose();
                        }
                        n_FrameCount3++;
                        lblFrameCount3.Text = n_FrameCount3.ToString();
                        pictureBox3.Image.Save(Application.StartupPath.ToString() + "\\FRAME_BUFFER3\\ACQ.BMP");
                        DoInspection3();
                    }
                }
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
            finally
            {
                // Dispose the grab result if needed for returning it to the grab loop.
                e.DisposeGrabResultIfClone();
            }
        }
        private void OnGrabStopped3(Object sender, GrabStopEventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<GrabStopEventArgs>(OnGrabStopped3), sender, e);
                return;
            }

            // Reset the stopwatch.
            stopWatch3.Reset();

            // The camera stopped grabbing. Enable the grab buttons. Disable the stop button.
            EnableButtons3(true, false);

            // If the grabbed stop due to an error, display the error message.
            if (e.Reason != GrabStopReason.UserRequest)
            {
                MessageBox.Show("A grab error occured:\n" + e.ErrorMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OnConnectionLost4(Object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<EventArgs>(OnConnectionLost4), sender, e);
                return;
            }

            // Close the camera object.
            DestroyCamera();
        }
        private void OnCameraOpened4(Object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<EventArgs>(OnCameraOpened4), sender, e);
                return;
            }

            try
            {
                camera4.Parameters.Load(Application.StartupPath + "\\camera4_profile.pfs", ParameterPath.CameraDevice);
            }
            catch (Exception ex)
            {
                MessageBox.Show("카메라4 프로파일을 로드하는 중 에러가 발생하였습니다. \r\n" + ex.ToString());
            }

            // The image provider is ready to grab. Enable the grab buttons.
            EnableButtons4(true, false);
        }
        private void OnCameraClosed4(Object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<EventArgs>(OnCameraClosed4), sender, e);
                return;
            }

            // The camera connection is closed. Disable all buttons.
            EnableButtons4(false, false);
        }
        private void OnGrabStarted4(Object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<EventArgs>(OnGrabStarted4), sender, e);
                return;
            }

            // Reset the stopwatch used to reduce the amount of displayed images. The camera may acquire images faster than the images can be displayed.

            stopWatch4.Reset();

            // The camera is grabbing. Disable the grab buttons. Enable the stop button.
            EnableButtons4(false, true);
        }
        private void OnImageGrabbed4(Object sender, ImageGrabbedEventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper GUI thread.
                // The grab result will be disposed after the event call. Clone the event arguments for marshaling to the GUI thread.
                BeginInvoke(new EventHandler<ImageGrabbedEventArgs>(OnImageGrabbed4), sender, e.Clone());
                return;
            }

            try
            {
                // Acquire the image from the camera. Only show the latest image. The camera may acquire images faster than the images can be displayed.

                // Get the grab result.
                IGrabResult grabResult = e.GrabResult;

                // Check if the image can be displayed.
                if (grabResult.IsValid)
                {
                    // Reduce the number of displayed images to a reasonable amount if the camera is acquiring images very fast.
                    if (!stopWatch4.IsRunning || stopWatch4.ElapsedMilliseconds > 33)
                    {
                        stopWatch4.Restart();

                        Bitmap bitmap = new Bitmap(grabResult.Width, grabResult.Height, PixelFormat.Format32bppRgb);
                        // Lock the bits of the bitmap.
                        BitmapData bmpData = bitmap.LockBits(new Rectangle(0, 0, bitmap.Width, bitmap.Height), ImageLockMode.ReadWrite, bitmap.PixelFormat);
                        // Place the pointer to the buffer of the bitmap.
                        converter4.OutputPixelFormat = PixelType.BGRA8packed;
                        IntPtr ptrBmp = bmpData.Scan0;
                        converter4.Convert(ptrBmp, bmpData.Stride * bitmap.Height, grabResult);
                        bitmap.UnlockBits(bmpData);

                        // Assign a temporary variable to dispose the bitmap after assigning the new bitmap to the display control.
                        Bitmap bitmapOld = pictureBox4.Image as Bitmap;
                        // Provide the display control with the new bitmap. This action automatically updates the display.
                        pictureBox4.Image = bitmap;
                        if (bitmapOld != null)
                        {
                            // Dispose the bitmap.
                            bitmapOld.Dispose();
                        }
                        n_FrameCount4++;
                        lblFrameCount4.Text = n_FrameCount4.ToString();
                        pictureBox4.Image.Save(Application.StartupPath.ToString() + "\\FRAME_BUFFER4\\ACQ.BMP");
                        DoInspection4();
                    }
                }
            }
            catch (Exception exception)
            {
                ShowException(exception);
            }
            finally
            {
                // Dispose the grab result if needed for returning it to the grab loop.
                e.DisposeGrabResultIfClone();
            }
        }
        private void OnGrabStopped4(Object sender, GrabStopEventArgs e)
        {
            if (InvokeRequired)
            {
                // If called from a different thread, we must use the Invoke method to marshal the call to the proper thread.
                BeginInvoke(new EventHandler<GrabStopEventArgs>(OnGrabStopped4), sender, e);
                return;
            }

            // Reset the stopwatch.
            stopWatch4.Reset();

            // The camera stopped grabbing. Enable the grab buttons. Disable the stop button.
            EnableButtons4(true, false);

            // If the grabbed stop due to an error, display the error message.
            if (e.Reason != GrabStopReason.UserRequest)
            {
                MessageBox.Show("A grab error occured:\n" + e.ErrorMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region Event Handler
        private void btnSCARA1Connect_Click(object sender, EventArgs e)
        {
            if (btnSCARA1Connect.Text == "SCARA1 DISCONNECT")
            {
                ScaraDisconnect1();
            }
            else
            {
                ScaraConnect1();
            }
        }

        private void btnSCARA2Connect_Click(object sender, EventArgs e)
        {
            if (btnSCARA2Connect.Text == "SCARA2 DISCONNECT")
            {
                ScaraDisconnect2();
            }
            else
            {
                ScaraConnect2();
            }
        }

        private void btnSCARA3Connect_Click(object sender, EventArgs e)
        {
            if (btnSCARA3Connect.Text == "SCARA3 DISCONNECT")
            {
                ScaraDisconnect3();
            }
            else
            {
                ScaraConnect3();
            }
        }

        private void btnSCARA4Connect_Click(object sender, EventArgs e)
        {
            if (btnSCARA4Connect.Text == "SCARA4 DISCONNECT")
            {
                ScaraDisconnect4();
            }
            else
            {
                ScaraConnect4();
            }
        }

        private void toolStripButtonOneShot_Click(object sender, EventArgs e)
        {
            b_isOneShot = true;
            
            OneShot();
            //DoInspection();
        }
        private void toolStripButtonAutoInspStart_Click(object sender, EventArgs e)
        {
            //if (bIsVieworksOpened)
            //{
            //    b_isOneShot = true;
            //    OneShot();
            //}
            //else
            //{
                //StartInsp();
                n_FrameCount = 0;
                ContinuousShot();
            //}
        }
        private void toolStripButtonContinuousShot_Click(object sender, EventArgs e)
        {
            ContinuousShot();
        }
        private void toolStripButtonStop_Click(object sender, EventArgs e)
        {
            Stop();
        }
        private void btnSampleInspect_Click(object sender, EventArgs e)
        {
            //swInspProc.Reset();
            //swInspProc.Start();
            DoInspection();
            DoInspection2();
            //swInspProc.Stop();
            //lblProcessingTime.Text = swInspProc.ElapsedMilliseconds.ToString();
        }
        private void pictureBox_Paint(object sender, PaintEventArgs e)
        {
            Redraw(e.Graphics);
        }
        private void pictureBox_Resize(object sender, EventArgs e)
        {
            Redraw(pictureBox.CreateGraphics());
        }
        private void btnConfirmMatching_Click(object sender, EventArgs e)
        {
            PatternMatchingLearn();
        }
        private void tsbZoomIn_Click(object sender, EventArgs e)
        {
            pictureBox.Width = (int)(pictureBox.Width + (n_defaultPictureBoxWidth * 0.25));
            pictureBox.Height = (int)(pictureBox.Height + (n_defaultPictureBoxHeight * 0.25));

            float scale = ((float)pictureBox.Height / (float)imgSrc.Height) * 1.00f;
            tstxtZoomRatio.Text = (scale * 100.00f).ToString("0.00");
        }
        private void tsbZoomOut_Click(object sender, EventArgs e)
        {
            pictureBox.Width = (int)(pictureBox.Width - (n_defaultPictureBoxWidth * 0.25));
            pictureBox.Height = (int)(pictureBox.Height - (n_defaultPictureBoxHeight * 0.25));

            float scale = ((float)pictureBox.Height / (float)imgSrc.Height) * 1.00f;
            tstxtZoomRatio.Text = (scale * 100.00f).ToString("0.00");
        }
        private void pictureBox_Move(object sender, EventArgs e)
        {

        }
        private void toolStripTextBox1_KeyDown(object sender, KeyEventArgs e)
        {

            try
            {

                if (e.KeyCode == Keys.Enter)
                {
                    float fRatio = 6.17f;
                    try
                    {
                        fRatio = float.Parse(tstxtZoomRatio.Text.Trim());
                    }
                    catch
                    {
                        MessageBox.Show("수치로만 입력하세요.");
                        tstxtZoomRatio.Text = "6.2";
                        return;
                    }

                    pictureBox.Width = (int)(imgSrc.Width * (fRatio) / 100);
                    pictureBox.Height = (int)(imgSrc.Height * (fRatio) / 100);
                    Redraw(pictureBox.CreateGraphics());
                    tstxtZoomRatio.SelectAll();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void pictureBox_Click(object sender, EventArgs e)
        {

        }
        private void pictureBox_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {

            }

            //if(imgSrc != null)
            //{
            //    picZoom.Location = pictureBox.PointToClient(new Point(Control.MousePosition.X + 10, Control.MousePosition.Y + 10));
            //}
            //lblHoriLine.Location = new Point(lblHoriLine.Location.X, panel1.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y)).Y);
            //lblVertiLine.Location = new Point(panel1.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y)).X, lblVertiLine.Location.Y);

            // 십자선
            int nHoriDefault = 24;
            int nVertiDefault = 0;
            int nGridPitch = 4;

            tsslblAbsPosition.Text = "커서위치 픽셀계좌표 : X [" + pictureBox.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y)).X * (100 / float.Parse(tstxtZoomRatio.Text.Trim())) + "], Y [" + pictureBox.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y)).Y * (100 / float.Parse(tstxtZoomRatio.Text.Trim())) + "]";

            if (float.Parse(tstxtZoomRatio.Text.Trim()) != 100)
            {
                tsslblRelatedPosition.Text = "     커서위치 치수계좌표 : 치수계좌표는 이미지 확대비율이 정확히 100%일 때만 표시가능합니다.";
            }
            else
                tsslblRelatedPosition.Text = "     커서위치 치수계좌표 : X [" + EWorldShape1.SensorToWorld(new EPoint(pictureBox.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y)).X, pictureBox.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y)).Y)).X.ToString() + " mm], Y [" + EWorldShape1.SensorToWorld(new EPoint(pictureBox.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y)).X, pictureBox.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y)).Y)).Y.ToString() + " mm]";
        }
        private void pictureBox_MouseDown(object sender, MouseEventArgs e)
        {
        }
        private void pictureBox_MouseUp(object sender, MouseEventArgs e)
        {
        }
        private void pictureBox_MouseHover(object sender, EventArgs e)
        {
            //picZoom.Visible = true;
            //Cursor = Cursors.Cross;
        }
        private void pictureBox_MouseLeave(object sender, EventArgs e)
        {
            //picZoom.Visible = false;
            //Cursor = Cursors.Arrow;
        }
        private void timerScroll_Tick(object sender, EventArgs e)
        {
            //Point pCurrentPoint = panel1.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y));
            Point pCurrentPoint = (new Point(Control.MousePosition.X, Control.MousePosition.Y));
            try
            {
                //if (pCurrentPoint.X > pPositionOfFirstClickScroll.X)
                //{
                //    panel1.HorizontalScroll.Value += pCurrentPoint.X - (int)(pPositionOfFirstClickScroll.X * (2 * float.Parse(tstxtZoomRatio.Text.Trim()) * 0.01));
                //}
                //if (pCurrentPoint.Y > pPositionOfFirstClickScroll.Y)
                //{
                //    panel1.VerticalScroll.Value += pCurrentPoint.Y - (int)(pPositionOfFirstClickScroll.Y * (2 * float.Parse(tstxtZoomRatio.Text.Trim()) * 0.01));
                //}
                //if (pCurrentPoint.X < pPositionOfFirstClickScroll.X)
                //{
                //    panel1.HorizontalScroll.Value -= pPositionOfFirstClickScroll.X - (int)(pCurrentPoint.X * (2 * float.Parse(tstxtZoomRatio.Text.Trim()) * 0.01));
                //}
                //if (pCurrentPoint.Y < pPositionOfFirstClickScroll.Y)
                //{
                //    panel1.VerticalScroll.Value -= pPositionOfFirstClickScroll.Y - (int)(pCurrentPoint.Y * (2 * float.Parse(tstxtZoomRatio.Text.Trim()) * 0.01));
                //}
            }
            catch (Exception ex)
            {
            }
        }
        private void btnClearFrameCount_Click(object sender, EventArgs e)
        {
            n_FrameCount = 0;
            lblFrameCount.Text = n_FrameCount.ToString();
        }
        private void gridCalibration_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex > 1)
                {
                    if (gridCalibration[e.ColumnIndex, e.RowIndex].Value == null || gridCalibration[e.ColumnIndex, e.RowIndex].Value.ToString().Trim() == "")
                        gridCalibration[e.ColumnIndex, e.RowIndex].Value = "0.00";
                }
            }
            catch (Exception ex)
            {
                SaveExceptionLog(ex.StackTrace);
            }
        }
        private void gridCalibration_CellLeave(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex > 1)
                {
                    float.Parse(gridCalibration[e.ColumnIndex, e.RowIndex].Value.ToString().Trim());
                    //MessageBox.Show(gridToolSet[e.ColumnIndex, e.RowIndex].Value.ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("정확한 값을 입력해주세요.");
                //MessageBox.Show(ex.ToString());
                gridCalibration[e.ColumnIndex, e.RowIndex].Selected = true;
            }
        }
        private void gridCalibration_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            try
            {
                gridCalibration["gridCalibrationNo", e.RowIndex - 1].Value = e.RowIndex.ToString();
            }
            catch (Exception ex)
            {
            }
        }
        private void btnInspection_Click(object sender, EventArgs e)
        {
            DoInspection();
        }
        private void btnResetResult_Click(object sender, EventArgs e)
        {
            UpdateDataGrid();
        }
        private void toolStripButtonAutoInspStart2_Click(object sender, EventArgs e)
        {
            n_FrameCount2 = 0;
            ContinuousShot2();
        }
        private void toolStripButtonOneShot2_Click(object sender, EventArgs e)
        {
            b_isOneShot2 = true;
            OneShot2();
        }
        private void toolStripButtonStop2_Click(object sender, EventArgs e)
        {
            Stop2();
        }
        private void tstxtZoomRatio2_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {

                if (e.KeyCode == Keys.Enter)
                {
                    float fRatio = 6.17f;
                    try
                    {
                        fRatio = float.Parse(tstxtZoomRatio2.Text.Trim());
                    }
                    catch
                    {
                        MessageBox.Show("수치로만 입력하세요.");
                        tstxtZoomRatio2.Text = "6.2";
                        return;
                    }

                    pictureBox2.Width = (int)(imgSrc2.Width * (fRatio) / 100);
                    pictureBox2.Height = (int)(imgSrc2.Height * (fRatio) / 100);
                    Redraw2(pictureBox2.CreateGraphics());
                    tstxtZoomRatio2.SelectAll();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void tsbZoomOut2_Click(object sender, EventArgs e)
        {
            pictureBox2.Width = (int)(pictureBox2.Width - (n_defaultPictureBoxWidth2 * 0.25));
            pictureBox2.Height = (int)(pictureBox2.Height - (n_defaultPictureBoxHeight2 * 0.25));

            float scale = ((float)pictureBox2.Height / (float)imgSrc2.Height) * 1.00f;
            tstxtZoomRatio2.Text = (scale * 100.00f).ToString("0.00");
        }
        private void tsbZoomIn2_Click(object sender, EventArgs e)
        {
            pictureBox2.Width = (int)(pictureBox2.Width + (n_defaultPictureBoxWidth2 * 0.25));
            pictureBox2.Height = (int)(pictureBox2.Height + (n_defaultPictureBoxHeight2 * 0.25));

            float scale = ((float)pictureBox2.Height / (float)imgSrc2.Height) * 1.00f;
            tstxtZoomRatio2.Text = (scale * 100.00f).ToString("0.00");
        }
        private void pictureBox2_Paint(object sender, PaintEventArgs e)
        {
            Redraw2(e.Graphics);
        }
        private void pictureBox2_Resize(object sender, EventArgs e)
        {
            Redraw2(pictureBox2.CreateGraphics());
        }
        private void toolStripLabel9_Click(object sender, EventArgs e)
        {
            if (camera == null)
            {
                try
                {
                    // Create a new camera object.
                    camera = new Camera("24614161");
                    camera.CameraOpened += Configuration.AcquireContinuous;
                    // Register for the events of the image provider needed for proper operation.
                    camera.ConnectionLost += OnConnectionLost;
                    camera.CameraOpened += OnCameraOpened;
                    camera.CameraClosed += OnCameraClosed;
                    camera.StreamGrabber.GrabStarted += OnGrabStarted;
                    camera.StreamGrabber.ImageGrabbed += OnImageGrabbed;
                    camera.StreamGrabber.GrabStopped += OnGrabStopped;
                    camera.Open();
                }
                catch (Exception exception)
                {
                    MessageBox.Show("지정된 카메라 연결에 실패하였습니다. \r\n 카메라 연결상태 혹은 다른 프로그램에서 카메라에 연결되어있는지 확인하세요.");
                    //ShowException(exception);
                }
            }
        }
        private void toolStripLabel10_Click(object sender, EventArgs e)
        {
            if (camera2 == null)
            {
                try
                {
                    // Create a new camera object.
                    camera2 = new Camera("24586038");
                    camera2.CameraOpened += Configuration.AcquireContinuous;
                    // Register for the events of the image provider needed for proper operation.
                    camera2.ConnectionLost += OnConnectionLost2;
                    camera2.CameraOpened += OnCameraOpened2;
                    camera2.CameraClosed += OnCameraClosed2;
                    camera2.StreamGrabber.GrabStarted += OnGrabStarted2;
                    camera2.StreamGrabber.ImageGrabbed += OnImageGrabbed2;
                    camera2.StreamGrabber.GrabStopped += OnGrabStopped2;
                    camera2.Open();
                }
                catch (Exception exception)
                {
                    MessageBox.Show("지정된 카메라 연결에 실패하였습니다. \r\n 카메라 연결상태 혹은 다른 프로그램에서 카메라에 연결되어있는지 확인하세요.");
                    //ShowException(exception);
                }
            }
        }
        #endregion

        #region GDI & Bitmap Support
        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern bool DeleteObject(IntPtr hObject);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern IntPtr GetDC(IntPtr hwnd);

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern IntPtr CreateCompatibleDC(IntPtr hdc);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int ReleaseDC(IntPtr hwnd, IntPtr hdc);

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern int DeleteDC(IntPtr hdc);

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobj);

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern int BitBlt(IntPtr hdcDst, int xDst, int yDst, int w, int h, IntPtr hdcSrc, int xSrc, int ySrc, int rop);
        static int SRCCOPY = 0x00CC0020;

        private void btnApply1_Click(object sender, EventArgs e)
        {
            strMsgSCARA1 = txtMsg1.Text.Trim();
            strMsgSCARA2 = txtMsg1.Text.Trim();
            lstResults.Items.Add("[MSG]Message1(to SCARA1,2) Updated");
        }

        private void btnApply2_Click(object sender, EventArgs e)
        {
            strMsgSCARA3 = txtMsg2.Text.Trim();
            strMsgSCARA4 = txtMsg2.Text.Trim();
            lstResults.Items.Add("[MSG]Message2(to SCARA3,4) Updated");
        }

        private void btnSO1_Click(object sender, EventArgs e)
        {
            ScaraSO1();
        }

        private void btnRN1_Click(object sender, EventArgs e)
        {
            ScaraRN1();
        }

        private void btnRSERR1_Click(object sender, EventArgs e)
        {
            ScaraRSERR1();
        }

        private void btnRSERR2_Click(object sender, EventArgs e)
        {
            ScaraRSERR2();
        }

        private void btnRSERR3_Click(object sender, EventArgs e)
        {
            ScaraRSERR3();
        }

        private void btnRSERR4_Click(object sender, EventArgs e)
        {
            ScaraRSERR4();
        }

        private void btnXOffset_Click(object sender, EventArgs e)
        {
            fScaraXOffset = float.Parse(txtXOffset.Text.Trim());
        }

        private void btnYOffset_Click(object sender, EventArgs e)
        {
            fScaraYOffset = float.Parse(txtYOffset.Text.Trim());
        }

        private void btnZOffset_Click(object sender, EventArgs e)
        {
            fScaraZOffset = float.Parse(txtZOffset.Text.Trim());
        }

        private void lstResults_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSO2_Click(object sender, EventArgs e)
        {
            ScaraSO2();
        }
        private void pictureBox_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void btnRN2_Click(object sender, EventArgs e)
        {
            ScaraRN2();
        }

        private void btnSO3_Click(object sender, EventArgs e)
        {
            ScaraSO3();
        }

        private void btnRN3_Click(object sender, EventArgs e)
        {
            ScaraRN3();
        }

        private void btnSO4_Click(object sender, EventArgs e)
        {
            ScaraSO4();
        }

        private void btnRN4_Click(object sender, EventArgs e)
        {
            ScaraRN4();
        }

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        static extern IntPtr CreateDIBSection(IntPtr hdc, ref BITMAPINFO bmi, uint Usage, out IntPtr bits, IntPtr hSection, uint dwOffset);
        static uint BI_RGB = 0;
        static uint DIB_RGB_COLORS = 0;
        private object converter;

        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
        public struct BITMAPINFO
        {
            public uint biSize;
            public int biWidth, biHeight;
            public short biPlanes, biBitCount;
            public uint biCompression, biSizeImage;
            public int biXPelsPerMeter, biYPelsPerMeter;
            public uint biClrUsed, biClrImportant;

            [System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 256)]
            public uint[] cols;
        }

        static uint MAKERGB(int r, int g, int b)
        {
            return ((uint)(b & 255)) | ((uint)((r & 255) << 8)) | ((uint)((g & 255) << 16));
        }
        static System.Drawing.Bitmap CopyToBpp(System.Drawing.Bitmap b, int bpp)
        {
            if (bpp != 1 && bpp != 8) throw new System.ArgumentException("1 or 8", "bpp");
            
            int w = b.Width, h = b.Height;
            IntPtr hbm = b.GetHbitmap();
            
            BITMAPINFO bmi = new BITMAPINFO();

            bmi.biSize = 40;
            bmi.biWidth = w;
            bmi.biHeight = h;
            bmi.biPlanes = 1;
            bmi.biBitCount = (short)bpp;
            bmi.biCompression = BI_RGB;
            bmi.biSizeImage = (uint)(((w + 7) & 0xFFFFFFF8) * h / 8);
            bmi.biXPelsPerMeter = 1000000;
            bmi.biYPelsPerMeter = 1000000;

            // Now for the colour table.
            uint ncols = (uint)1 << bpp;
            bmi.biClrUsed = ncols;
            bmi.biClrImportant = ncols;
            bmi.cols = new uint[256];
            if (bpp == 1) { bmi.cols[0] = MAKERGB(0, 0, 0); bmi.cols[1] = MAKERGB(255, 255, 255); }
            else { for (int i = 0; i < ncols; i++) bmi.cols[i] = MAKERGB(i, i, i); }

            IntPtr bits0; IntPtr hbm0 = CreateDIBSection(IntPtr.Zero, ref bmi, DIB_RGB_COLORS, out bits0, IntPtr.Zero, 0);
            IntPtr sdc = GetDC(IntPtr.Zero);
            IntPtr hdc = CreateCompatibleDC(sdc); SelectObject(hdc, hbm);
            IntPtr hdc0 = CreateCompatibleDC(sdc); SelectObject(hdc0, hbm0);

            BitBlt(hdc0, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

            System.Drawing.Bitmap b0 = System.Drawing.Bitmap.FromHbitmap(hbm0);

            DeleteDC(hdc);
            DeleteDC(hdc0);
            ReleaseDC(IntPtr.Zero, sdc);
            DeleteObject(hbm);
            DeleteObject(hbm0);
            //

            return b0;
        }
        #endregion
    }
}
